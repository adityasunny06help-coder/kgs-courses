window.batchData = {
  "subjects": [
    {
      "subject_name": "Announcement Section",
      "subject_id": 3430,
      "video_count": 0,
      "note_count": 0,
      "videos": [],
      "notes": []
    },
    {
      "subject_name": "Botany By Krati Chaturvedi  (KC Ma'am)",
      "subject_id": 3423,
      "video_count": 76,
      "note_count": 76,
      "videos": [
        {
          "serial": 1,
          "title": "व्याख्यान- 01 || पुष्पीय  पादपों में लैंगिक प्रजनन - 1",
          "published_date": "12 Sep 2024",
          "video_url": "https://www.youtube.com/embed/T8_RKiH-Bps",
          "hd_video_url": "https://www.youtube.com/embed/T8_RKiH-Bps",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/LOAUJJYE2EFIIL62tutlYcNBNF6iGqBZ8KB3Yz1v.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 01 || पुष्पीय पादपों में लैंगिक प्रजनन - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/921980b6-b186-4a9b-a92d-94adffe65334.pdf"
            }
          ]
        },
        {
          "serial": 2,
          "title": "व्याख्यान- 02 || पुष्पीय पादपों में लैंगिक प्रजनन - 2",
          "published_date": "13 Sep 2024",
          "video_url": "https://www.youtube.com/embed/cPPTM6rHGvw",
          "hd_video_url": "https://www.youtube.com/embed/cPPTM6rHGvw",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/BSP0FcCrHVwbbwIfE35jmx6JJwKVkhHQqohQ5v1t.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 02 || पुष्पीय पादपों में लैंगिक प्रजनन - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ee03a7e8-3f10-45f0-9d9a-d566a2d93b9f.pdf"
            }
          ]
        },
        {
          "serial": 3,
          "title": "व्याख्यान- 03 || पुष्पीय पादपों में लैंगिक प्रजनन - 3",
          "published_date": "14 Sep 2024",
          "video_url": "https://www.youtube.com/embed/APq3o6C__g4",
          "hd_video_url": "https://www.youtube.com/embed/APq3o6C__g4",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/K8mY0qacDPygGYlEl6jDTavyuVJW3qNRunzqzbP7.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 03 || पुष्पीय पादपों में लैंगिक प्रजनन - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3b4fb076-2f96-41e3-b799-8b4536d81409.pdf"
            }
          ]
        },
        {
          "serial": 4,
          "title": "व्याख्यान- 04 || पुष्पीय पादपों में लैंगिक प्रजनन - 4",
          "published_date": "19 Sep 2024",
          "video_url": "https://www.youtube.com/embed/oCMJDY-87ow",
          "hd_video_url": "https://www.youtube.com/embed/oCMJDY-87ow",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/thumb/uploads/r7vFZGdzESQqFySUDpKgVQujjVhzVugoBZ18rOOd.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 04 || पुष्पीय पादपों में लैंगिक प्रजनन - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d3370d32-4eec-451e-a2a2-a2e2aecf159b.pdf"
            }
          ]
        },
        {
          "serial": 5,
          "title": "व्याख्यान- 05 || पुष्पीय पादपों में लैंगिक प्रजनन - 5",
          "published_date": "20 Sep 2024",
          "video_url": "https://www.youtube.com/embed/LfR6dZlxvew",
          "hd_video_url": "https://www.youtube.com/embed/LfR6dZlxvew",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/1NQNi7Gkox5wPzmF6xHhxx9phkoVEUpG6U4c1jAZ.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 05 || पुष्पीय पादपों में लैंगिक प्रजनन - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8e5b319c-88e4-4258-9ef3-ff0dd332fa83.pdf"
            }
          ]
        },
        {
          "serial": 6,
          "title": "व्याख्यान- 06 || पुष्पीय पादपों में लैंगिक प्रजनन - 6",
          "published_date": "21 Sep 2024",
          "video_url": "https://www.youtube.com/embed/pwxDBQx_ah0",
          "hd_video_url": "https://www.youtube.com/embed/pwxDBQx_ah0",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/RfEXWnpdwuqyAwRBrFN6TgakVZFcbdf4h2pDhyq7.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 06 || पुष्पीय पादपों में लैंगिक प्रजनन - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c7b8a954-4625-4947-a00c-d0d4c4179412.pdf"
            }
          ]
        },
        {
          "serial": 7,
          "title": "व्याख्यान- 07 || पुष्पीय पादपों में लैंगिक प्रजनन - 7",
          "published_date": "26 Sep 2024",
          "video_url": "https://www.youtube.com/embed/hQJEPxhioR8",
          "hd_video_url": "https://www.youtube.com/embed/hQJEPxhioR8",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/PgZuT2KoUGJjmzo10AwaKR9kfvA3tVbQ0KWlqFsV.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 07 || पुष्पीय पादपों में लैंगिक प्रजनन - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/066a0834-39e5-4295-b50e-ff78036f4941.pdf"
            }
          ]
        },
        {
          "serial": 8,
          "title": "व्याख्यान- 08 || पुष्पीय पादपों में लैंगिक प्रजनन - 8",
          "published_date": "27 Sep 2024",
          "video_url": "https://www.youtube.com/embed/uSYD9KZBABo",
          "hd_video_url": "https://www.youtube.com/embed/uSYD9KZBABo",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/BVBZwrQfkBiqFV4QaSHq0Z3HbXQYDgnakAPOdmAD.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 08 || पुष्पीय पादपों में लैंगिक प्रजनन - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d15ccff5-fe5e-4f2d-b8c7-1823188d2c30.pdf"
            }
          ]
        },
        {
          "serial": 9,
          "title": "व्याख्यान- 09 || पुष्पीय पादपों में लैंगिक प्रजनन - 9",
          "published_date": "28 Sep 2024",
          "video_url": "https://www.youtube.com/embed/qAoS77URLz4",
          "hd_video_url": "https://www.youtube.com/embed/qAoS77URLz4",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/EmN82L2mghYi0i6t5sR0ZyRXmWQpiBuYVO81FDWv.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 09 || पुष्पीय पादपों में लैंगिक प्रजनन - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/223706de-9f47-422a-a17a-dae7232ba5fe.pdf"
            }
          ]
        },
        {
          "serial": 10,
          "title": "व्याख्यान- 10 || पुष्पीय पादपों में लैंगिक प्रजनन - 10",
          "published_date": "03 Oct 2024",
          "video_url": "https://www.youtube.com/embed/LRFfPnHw_rU",
          "hd_video_url": "https://www.youtube.com/embed/LRFfPnHw_rU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/9naySUbXHz7YmbcgmKuXCZJVCR59mjBACzJ02CfT.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 10 || पुष्पीय पादपों में लैंगिक प्रजनन - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/dab23218-cd2b-4c4c-b1cf-fcab6fb23020.pdf"
            }
          ]
        },
        {
          "serial": 11,
          "title": "व्याख्यान- 11 || पुष्पीय पादपों में लैंगिक प्रजनन - 11",
          "published_date": "04 Oct 2024",
          "video_url": "https://www.youtube.com/embed/Sp6fZ0nUeTU",
          "hd_video_url": "https://www.youtube.com/embed/Sp6fZ0nUeTU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/yMTWbiPdlK8kxBC6mR2TKZlxXdl90Kek5iZbJ0ud.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 11 || पुष्पीय पादपों में लैंगिक प्रजनन - 11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6e9c53b9-1a3a-4e83-89ea-6cbdc48be673.pdf"
            }
          ]
        },
        {
          "serial": 12,
          "title": "व्याख्यान- 12 || वंशागति तथा विविधता के सिद्धांत -1",
          "published_date": "05 Oct 2024",
          "video_url": "https://www.youtube.com/embed/hOt0CSpJQGU",
          "hd_video_url": "https://www.youtube.com/embed/hOt0CSpJQGU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/nuvaXzpHxsVZ3beDAs0MRZNABvGIlxYu6Ri8a6vH.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 12 || वंशानुक्रम एवं विभिन्नता के सिद्धांत -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c196fbd6-de70-42f1-a861-00fe2052a3a2.pdf"
            }
          ]
        },
        {
          "serial": 13,
          "title": "व्याख्यान- 13 || वंशागति तथा विविधता के सिद्धांत -2",
          "published_date": "08 Oct 2024",
          "video_url": "https://www.youtube.com/embed/u2rM9FmjUi0",
          "hd_video_url": "https://www.youtube.com/embed/u2rM9FmjUi0",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/mayVjXCoJ3xuKpKiQVv32TVGcU7XHq03hfxfrVgp.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 13 || वंशानुक्रम एवं विभिन्नता के सिद्धांत -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fc1c1a53-c61a-428f-85d5-e5640067a6b8.pdf"
            }
          ]
        },
        {
          "serial": 14,
          "title": "व्याख्यान- 14 || वंशागति तथा विविधता के सिद्धांत -3",
          "published_date": "09 Oct 2024",
          "video_url": "https://www.youtube.com/embed/iejJyKGCRDg",
          "hd_video_url": "https://www.youtube.com/embed/iejJyKGCRDg",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/2T6hY3ECMda9LESLMTHNjEtw9BjjnWEIqyNWsqwI.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 14 || वंशानुक्रम एवं विभिन्नता के सिद्धांत -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/66ffa2cd-1af5-4edf-9e60-863f5399d802.pdf"
            }
          ]
        },
        {
          "serial": 15,
          "title": "व्याख्यान- 15 || Unit Test- 1 Discussion",
          "published_date": "15 Oct 2024",
          "video_url": "https://www.youtube.com/embed/m7HrRTCsZUQ",
          "hd_video_url": "https://www.youtube.com/embed/m7HrRTCsZUQ",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/nhKViPh2ME6EIKkvldpuknSSQGF8A8DEM88L3lhQ.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 15 || Unit Test- 1 Discussion",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/681de164-4590-423a-b5f5-61ea4949bba7.pdf"
            }
          ]
        },
        {
          "serial": 16,
          "title": "व्याख्यान- 16 || वंशागति तथा विविधता के सिद्धांत -4",
          "published_date": "17 Oct 2024",
          "video_url": "https://www.youtube.com/embed/tVca6rm-i2E",
          "hd_video_url": "https://www.youtube.com/embed/tVca6rm-i2E",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/HUFzJ5wDSVvSQ8FQlPWDM1AAkPewI1sk9Rep2qPK.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 16 || वंशागति तथा विविधता के सिद्धांत -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7cdfcfac-7c86-4fab-a9ba-bf07dee6a3af.pdf"
            }
          ]
        },
        {
          "serial": 17,
          "title": "व्याख्यान- 17 || वंशागति तथा विविधता के सिद्धांत -5",
          "published_date": "18 Oct 2024",
          "video_url": "https://www.youtube.com/embed/MCHUuiG57OI",
          "hd_video_url": "https://www.youtube.com/embed/MCHUuiG57OI",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/I8vnbZSDGF0DBHPjyTFpPEyPXxWiBULH7JXAkliP.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 17 || वंशागति तथा विविधता के सिद्धांत -5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/044d6bd8-121a-497a-b4a7-733c739915b3.pdf"
            }
          ]
        },
        {
          "serial": 18,
          "title": "व्याख्यान- 18 || वंशागति तथा विविधता के सिद्धांत -6",
          "published_date": "19 Oct 2024",
          "video_url": "https://www.youtube.com/embed/ocsAI4T43Kk",
          "hd_video_url": "https://www.youtube.com/embed/ocsAI4T43Kk",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/fxYD0dkVNtR3Nm8MtphYwm9iYBfd0xxeIo4XQQVP.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 18 || वंशागति तथा विविधता के सिद्धांत -6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/734846ad-b3bd-40af-9950-e6d509227714.pdf"
            }
          ]
        },
        {
          "serial": 19,
          "title": "व्याख्यान- 19 || वंशागति तथा विविधता के सिद्धांत -7",
          "published_date": "24 Oct 2024",
          "video_url": "https://www.youtube.com/embed/giJC7srCFIA",
          "hd_video_url": "https://www.youtube.com/embed/giJC7srCFIA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/Z5b7YvYHbEIhPT75FNRSBw66Gjtd2nZkVuOyWqHj.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 19 || वंशागति तथा विविधता के सिद्धांत -7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4e2675dd-cc43-4005-8d1e-9f078d630324.pdf"
            }
          ]
        },
        {
          "serial": 20,
          "title": "व्याख्यान- 20 || वंशागति तथा विविधता के सिद्धांत -8",
          "published_date": "25 Oct 2024",
          "video_url": "https://www.youtube.com/embed/GB25XFPknzw",
          "hd_video_url": "https://www.youtube.com/embed/GB25XFPknzw",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/0yj2CFNnjsQyZqG0e4n3kjS3kn9yxwI4g9Lwa98d.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 20 || वंशागति तथा विविधता के सिद्धांत -8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d0f53385-0db4-4ec9-afee-97c58204ea29.pdf"
            }
          ]
        },
        {
          "serial": 21,
          "title": "व्याख्यान- 21 || वंशागति का आणविक आधार -1",
          "published_date": "26 Oct 2024",
          "video_url": "https://www.youtube.com/embed/A0dshb8A0yU",
          "hd_video_url": "https://www.youtube.com/embed/A0dshb8A0yU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/PZQftaExpqNKYwG8g5n4ZJhyHEgrA9VQZ4bf7rio.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 21 || वंशागति का आणविक आधार -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b43e662b-f55f-46f4-b894-68334b07850e.pdf"
            }
          ]
        },
        {
          "serial": 22,
          "title": "व्याख्यान- 22 || वंशागति का आणविक आधार -2",
          "published_date": "07 Nov 2024",
          "video_url": "https://www.youtube.com/embed/Yufd5wYrNmY",
          "hd_video_url": "https://www.youtube.com/embed/Yufd5wYrNmY",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/0AaI8fYoSa8fEMB8j19AZvdxotWnYrwxGk6linKn.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 22 || वंशागति का आणविक आधार -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b0d525e0-6537-4d19-9b07-ddfa4c08bff3.pdf"
            }
          ]
        },
        {
          "serial": 23,
          "title": "व्याख्यान- 23 || वंशागति का आणविक आधार -3",
          "published_date": "08 Nov 2024",
          "video_url": "https://www.youtube.com/embed/UOEMIz06Vdw",
          "hd_video_url": "https://www.youtube.com/embed/UOEMIz06Vdw",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/thumb/uploads/byjrWjR8U7UWVnBGDM6LsIsLdFcvOfGxSPWkJmWe.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 23 || वंशागति का आणविक आधार -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e49554de-2811-4f9e-b28b-6dd366a627b1.pdf"
            }
          ]
        },
        {
          "serial": 24,
          "title": "व्याख्यान- 24 || वंशागति का आणविक आधार -4",
          "published_date": "09 Nov 2024",
          "video_url": "https://www.youtube.com/embed/Kr-JCYBtexQ",
          "hd_video_url": "https://www.youtube.com/embed/Kr-JCYBtexQ",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/kt5R8YGHwIwiF8vcATZ91JLCR2jqWePtsAuAHsMo.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 24 || वंशागति का आणविक आधार -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6b202019-9239-4ef7-9c60-b5c0ea54e24b.pdf"
            }
          ]
        },
        {
          "serial": 25,
          "title": "व्याख्यान- 25 || Unit Test- 2 Discussion",
          "published_date": "13 Nov 2024",
          "video_url": "https://www.youtube.com/embed/E3h59citoDc",
          "hd_video_url": "https://www.youtube.com/embed/E3h59citoDc",
          "thumbnail": "https://i.ytimg.com/vi/E3h59citoDc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 25 || Unit Test- 2 Discussion",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/efb32612-3403-4cfc-9434-f529596eab77.pdf"
            }
          ]
        },
        {
          "serial": 26,
          "title": "व्याख्यान- 26 || वंशागति का आणविक आधार -5",
          "published_date": "14 Nov 2024",
          "video_url": "https://www.youtube.com/embed/ZAO-aLIlwXg",
          "hd_video_url": "https://www.youtube.com/embed/ZAO-aLIlwXg",
          "thumbnail": "https://i.ytimg.com/vi/ZAO-aLIlwXg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 26 || वंशागति का आणविक आधार -5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0301808c-0877-47b0-9508-383614304685.pdf"
            }
          ]
        },
        {
          "serial": 27,
          "title": "व्याख्यान- 27 || वंशागति का आणविक आधार -6",
          "published_date": "15 Nov 2024",
          "video_url": "https://www.youtube.com/embed/aiAsGdoMhVA",
          "hd_video_url": "https://www.youtube.com/embed/aiAsGdoMhVA",
          "thumbnail": "https://i.ytimg.com/vi/aiAsGdoMhVA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 27|| वंशागति का आणविक आधार -6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f3b55a97-d89d-4e1b-86ea-769c437cd71b.pdf"
            }
          ]
        },
        {
          "serial": 28,
          "title": "व्याख्यान- 28 || वंशागति का आणविक आधार -7",
          "published_date": "16 Nov 2024",
          "video_url": "https://www.youtube.com/embed/btRMjymmoNg",
          "hd_video_url": "https://www.youtube.com/embed/btRMjymmoNg",
          "thumbnail": "https://i.ytimg.com/vi/btRMjymmoNg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 27 || वंशागति का आणविक आधार -7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d3f7636e-ad81-4e47-96ca-fabc3ae0effc.pdf"
            }
          ]
        },
        {
          "serial": 29,
          "title": "व्याख्यान- 29 || वंशागति का आणविक आधार -8",
          "published_date": "21 Nov 2024",
          "video_url": "https://www.youtube.com/embed/QJ_GKNl9gJ4",
          "hd_video_url": "https://www.youtube.com/embed/QJ_GKNl9gJ4",
          "thumbnail": "https://i.ytimg.com/vi/QJ_GKNl9gJ4/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 29 || वंशागति का आणविक आधार -8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/783ccb19-1e0b-4313-b2c4-35e45eb367bd.pdf"
            }
          ]
        },
        {
          "serial": 30,
          "title": "व्याख्यान- 30 || वंशागति का आणविक आधार -9",
          "published_date": "22 Nov 2024",
          "video_url": "https://www.youtube.com/embed/yVNhHRx0Npg",
          "hd_video_url": "https://www.youtube.com/embed/yVNhHRx0Npg",
          "thumbnail": "https://i.ytimg.com/vi/yVNhHRx0Npg/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 30 || वंशागति का आणविक आधार -9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5285f552-2570-4a23-91d7-8e551d47c96c.pdf"
            }
          ]
        },
        {
          "serial": 31,
          "title": "व्याख्यान- 31 || वंशागति का आणविक आधार -10",
          "published_date": "23 Nov 2024",
          "video_url": "https://www.youtube.com/embed/UGbISUuVfe0",
          "hd_video_url": "https://www.youtube.com/embed/UGbISUuVfe0",
          "thumbnail": "https://i.ytimg.com/vi/UGbISUuVfe0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान 31 वंशागति का आणविक आधार 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9fa3ee57-dd2e-47d4-8e8d-53d26665f8e3.pdf"
            }
          ]
        },
        {
          "serial": 32,
          "title": "व्याख्यान- 32 || जीव जगत - 1",
          "published_date": "25 Nov 2024",
          "video_url": "https://www.youtube.com/embed/IoqDodaEg7M",
          "hd_video_url": "https://www.youtube.com/embed/IoqDodaEg7M",
          "thumbnail": "https://i.ytimg.com/vi/IoqDodaEg7M/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 32 || जीव जगत - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/eaa947f0-b99f-442a-bf96-4c9075d96a53.pdf"
            }
          ]
        },
        {
          "serial": 33,
          "title": "व्याख्यान- 33 || जीव जगत - 2",
          "published_date": "26 Nov 2024",
          "video_url": "https://www.youtube.com/embed/maSGZDVyNfI",
          "hd_video_url": "https://www.youtube.com/embed/maSGZDVyNfI",
          "thumbnail": "https://i.ytimg.com/vi/maSGZDVyNfI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 33 || जीव जगत - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f3e086f3-6826-4404-b29d-b5fe573dcd8e.pdf"
            }
          ]
        },
        {
          "serial": 34,
          "title": "व्याख्यान- 34 || जीव जगत का वर्गीकरण - 1",
          "published_date": "27 Nov 2024",
          "video_url": "https://www.youtube.com/embed/8ddwiyXMn2s",
          "hd_video_url": "https://www.youtube.com/embed/8ddwiyXMn2s",
          "thumbnail": "https://i.ytimg.com/vi/8ddwiyXMn2s/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 34 || जीव जगत का वर्गीकरण - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4a5598da-d69c-4ec2-b0c3-135d90033a54.pdf"
            }
          ]
        },
        {
          "serial": 35,
          "title": "व्याख्यान- 35 || वंशागति का आणविक आधार -11",
          "published_date": "29 Nov 2024",
          "video_url": "https://www.youtube.com/embed/6z45ynNIVBY",
          "hd_video_url": "https://www.youtube.com/embed/6z45ynNIVBY",
          "thumbnail": "https://i.ytimg.com/vi/6z45ynNIVBY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान 32 वंशागति का आणविक आधार 11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a3357b41-18ae-4243-a052-1d0aec7ead32.pdf"
            }
          ]
        },
        {
          "serial": 36,
          "title": "व्याख्यान- 36 || जीव और समष्टियाँ - 1",
          "published_date": "30 Nov 2024",
          "video_url": "https://www.youtube.com/embed/LgOq0AKkGcY",
          "hd_video_url": "https://www.youtube.com/embed/LgOq0AKkGcY",
          "thumbnail": "https://i.ytimg.com/vi/LgOq0AKkGcY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 33 || जीव और समष्टियाँ - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/65330e97-df72-487a-8624-2580422cd960.pdf"
            }
          ]
        },
        {
          "serial": 37,
          "title": "व्याख्यान- 37 || जीव जगत का वर्गीकरण - 2",
          "published_date": "02 Dec 2024",
          "video_url": "https://www.youtube.com/embed/FX1hCoxxRXo",
          "hd_video_url": "https://www.youtube.com/embed/FX1hCoxxRXo",
          "thumbnail": "https://i.ytimg.com/vi/FX1hCoxxRXo/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 37 || जीव जगत का वर्गीकरण - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1b47d36d-315b-4c65-bbbd-baec82102e11.pdf"
            }
          ]
        },
        {
          "serial": 38,
          "title": "व्याख्यान- 38 || जीव जगत का वर्गीकरण - 3",
          "published_date": "03 Dec 2024",
          "video_url": "https://www.youtube.com/embed/9IuMywfV0nU",
          "hd_video_url": "https://www.youtube.com/embed/9IuMywfV0nU",
          "thumbnail": "https://i.ytimg.com/vi/9IuMywfV0nU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 38 || जीव जगत का वर्गीकरण - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0f40b262-0999-4e5e-a3c2-7c083798ff4b.pdf"
            }
          ]
        },
        {
          "serial": 39,
          "title": "व्याख्यान- 39 || जीव जगत का वर्गीकरण - 4",
          "published_date": "04 Dec 2024",
          "video_url": "https://www.youtube.com/embed/V03fYU4qDZI",
          "hd_video_url": "https://www.youtube.com/embed/V03fYU4qDZI",
          "thumbnail": "https://i.ytimg.com/vi/V03fYU4qDZI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 39 || जीव जगत का वर्गीकरण - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1a125484-296a-4c9d-b9f2-86cf6306bae1.pdf"
            }
          ]
        },
        {
          "serial": 40,
          "title": "व्याख्यान- 40 || जीव जगत का वर्गीकरण - 5",
          "published_date": "10 Dec 2024",
          "video_url": "https://www.youtube.com/embed/9CD7hWY0vhs",
          "hd_video_url": "https://www.youtube.com/embed/9CD7hWY0vhs",
          "thumbnail": "https://i.ytimg.com/vi/9CD7hWY0vhs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 40 || जीव जगत का वर्गीकरण - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/20034450-a427-431c-85f8-058ca095c443.pdf"
            }
          ]
        },
        {
          "serial": 41,
          "title": "व्याख्यान- 41 || जीव जगत का वर्गीकरण - 6",
          "published_date": "11 Dec 2024",
          "video_url": "https://www.youtube.com/embed/8iw8h3961qo",
          "hd_video_url": "https://www.youtube.com/embed/8iw8h3961qo",
          "thumbnail": "https://i.ytimg.com/vi/8iw8h3961qo/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 41 || जीव जगत का वर्गीकरण - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4eb4ccb6-2891-45aa-aefa-a00f721e46b2.pdf"
            }
          ]
        },
        {
          "serial": 42,
          "title": "व्याख्यान- 42 || Unit Test- 3 Discussion",
          "published_date": "13 Dec 2024",
          "video_url": "https://www.youtube.com/embed/a_xK2j9M3rs",
          "hd_video_url": "https://www.youtube.com/embed/a_xK2j9M3rs",
          "thumbnail": "https://i.ytimg.com/vi/a_xK2j9M3rs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 42 || Unit Test- 3 Discussion",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/73427ebf-f1d2-4077-82cb-93f5b1213bea.pdf"
            }
          ]
        },
        {
          "serial": 43,
          "title": "व्याख्यान- 43 || जीव जगत का वर्गीकरण - 7",
          "published_date": "16 Dec 2024",
          "video_url": "https://www.youtube.com/embed/jcq4A7RgHNQ",
          "hd_video_url": "https://www.youtube.com/embed/jcq4A7RgHNQ",
          "thumbnail": "https://i.ytimg.com/vi/jcq4A7RgHNQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 43 || जीव जगत का वर्गीकरण - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/76015545-accf-4653-9f1c-ad86d8fd7cd3.pdf"
            }
          ]
        },
        {
          "serial": 44,
          "title": "व्याख्यान- 44 || जीव जगत का वर्गीकरण - 8",
          "published_date": "17 Dec 2024",
          "video_url": "https://www.youtube.com/embed/MfNUT2VLoc8",
          "hd_video_url": "https://www.youtube.com/embed/MfNUT2VLoc8",
          "thumbnail": "https://i.ytimg.com/vi/MfNUT2VLoc8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 44 || जीव जगत का वर्गीकरण - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3df431dd-53ae-4e18-a8c9-e63625a48292.pdf"
            }
          ]
        },
        {
          "serial": 45,
          "title": "व्याख्यान- 45 || वनस्पति जगत - 1",
          "published_date": "18 Dec 2024",
          "video_url": "https://www.youtube.com/embed/YxuQmXDQ2Fw",
          "hd_video_url": "https://www.youtube.com/embed/YxuQmXDQ2Fw",
          "thumbnail": "https://i.ytimg.com/vi/YxuQmXDQ2Fw/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 45 || वनस्पति जगत - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2339ecb2-2efc-4bde-8a5b-7463873f0115.pdf"
            }
          ]
        },
        {
          "serial": 46,
          "title": "व्याख्यान- 46 || वनस्पति जगत - 2",
          "published_date": "23 Dec 2024",
          "video_url": "https://www.youtube.com/embed/AIaxmMzzIj0",
          "hd_video_url": "https://www.youtube.com/embed/AIaxmMzzIj0",
          "thumbnail": "https://i.ytimg.com/vi/AIaxmMzzIj0/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 46 || वनस्पति जगत - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/82cf3da0-cb25-4d21-89a7-63851ef8892c.pdf"
            }
          ]
        },
        {
          "serial": 47,
          "title": "व्याख्यान- 47 || वनस्पति जगत - 3",
          "published_date": "24 Dec 2024",
          "video_url": "https://www.youtube.com/embed/wRcKmiHdj1M",
          "hd_video_url": "https://www.youtube.com/embed/wRcKmiHdj1M",
          "thumbnail": "https://i.ytimg.com/vi/wRcKmiHdj1M/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 47 || वनस्पति जगत - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f849bf81-7458-4086-9f4c-0dc5648d9136.pdf"
            }
          ]
        },
        {
          "serial": 48,
          "title": "व्याख्यान- 48 || वनस्पति जगत - 4",
          "published_date": "25 Dec 2024",
          "video_url": "https://www.youtube.com/embed/o3ZUroctWao",
          "hd_video_url": "https://www.youtube.com/embed/o3ZUroctWao",
          "thumbnail": "https://i.ytimg.com/vi/o3ZUroctWao/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 48 || वनस्पति जगत - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/39c90a32-5cac-43bb-9d72-67a590968ff4.pdf"
            }
          ]
        },
        {
          "serial": 49,
          "title": "व्याख्यान- 49 || वनस्पति जगत - 5",
          "published_date": "30 Dec 2024",
          "video_url": "https://www.youtube.com/embed/7jtBZFGhw70",
          "hd_video_url": "https://www.youtube.com/embed/7jtBZFGhw70",
          "thumbnail": "https://i.ytimg.com/vi/7jtBZFGhw70/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 49 || वनस्पति जगत - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6ba8a077-9e69-4eb1-949c-624bf3ac6796.pdf"
            }
          ]
        },
        {
          "serial": 50,
          "title": "व्याख्यान- 50 || वनस्पति जगत - 6",
          "published_date": "31 Dec 2024",
          "video_url": "https://www.youtube.com/embed/TrIvCCw5NU0",
          "hd_video_url": "https://www.youtube.com/embed/TrIvCCw5NU0",
          "thumbnail": "https://i.ytimg.com/vi/TrIvCCw5NU0/default.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 50 || वनस्पति जगत - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4ab8b279-1699-46be-8817-8e2a58bcc870.pdf"
            }
          ]
        },
        {
          "serial": 51,
          "title": "व्याख्यान- 51 || वनस्पति जगत - 7",
          "published_date": "07 Jan 2025",
          "video_url": "https://www.youtube.com/embed/Uq3vgGkVZgU",
          "hd_video_url": "https://www.youtube.com/embed/Uq3vgGkVZgU",
          "thumbnail": "https://i.ytimg.com/vi/Uq3vgGkVZgU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 51 || वनस्पति जगत - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8befcc07-7f98-4a63-894e-a4af434c695b.pdf"
            }
          ]
        },
        {
          "serial": 52,
          "title": "व्याख्यान- 52 || उच्च पादपों में प्रकाश संश्लेषण - 1",
          "published_date": "08 Jan 2025",
          "video_url": "https://www.youtube.com/embed/wedYLOhy3VU",
          "hd_video_url": "https://www.youtube.com/embed/wedYLOhy3VU",
          "thumbnail": "https://i.ytimg.com/vi/wedYLOhy3VU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 52 || उच्च पादपों में प्रकाश संश्लेषण - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ffafef15-797f-4002-bd9c-bbb2e60cb997.pdf"
            }
          ]
        },
        {
          "serial": 53,
          "title": "व्याख्यान- 53 || उच्च पादपों में प्रकाश संश्लेषण - 2",
          "published_date": "14 Jan 2025",
          "video_url": "https://www.youtube.com/embed/g2dhnaroFa8",
          "hd_video_url": "https://www.youtube.com/embed/g2dhnaroFa8",
          "thumbnail": "https://i.ytimg.com/vi/g2dhnaroFa8/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 53 || उच्च पादपों में प्रकाश संश्लेषण - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/825a2864-0a5e-40d4-b66e-6ed30f748f70.pdf"
            }
          ]
        },
        {
          "serial": 54,
          "title": "व्याख्यान- 54 || उच्च पादपों में प्रकाश संश्लेषण - 3",
          "published_date": "15 Jan 2025",
          "video_url": "https://www.youtube.com/embed/PJFC3jnXsMk",
          "hd_video_url": "https://www.youtube.com/embed/PJFC3jnXsMk",
          "thumbnail": "https://i.ytimg.com/vi/PJFC3jnXsMk/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 54 || उच्च पादपों में प्रकाश संश्लेषण - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/05594697-68a7-4550-b560-6eccb23b4d45.pdf"
            }
          ]
        },
        {
          "serial": 55,
          "title": "व्याख्यान- 55 || उच्च पादपों में प्रकाश संश्लेषण - 4",
          "published_date": "18 Jan 2025",
          "video_url": "https://www.youtube.com/embed/w1JYY54G34g",
          "hd_video_url": "https://www.youtube.com/embed/w1JYY54G34g",
          "thumbnail": "https://i.ytimg.com/vi/w1JYY54G34g/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 55 || उच्च पादपों में प्रकाश संश्लेषण - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9fb9b56f-1245-4a1d-88d4-a684aa2b7a40.pdf"
            }
          ]
        },
        {
          "serial": 56,
          "title": "व्याख्यान- 57 || उच्च पादपों में प्रकाश संश्लेषण - 6",
          "published_date": "21 Jan 2025",
          "video_url": "https://www.youtube.com/embed/eid-oE_9Ths",
          "hd_video_url": "https://www.youtube.com/embed/eid-oE_9Ths",
          "thumbnail": "https://i.ytimg.com/vi/eid-oE_9Ths/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 57 || उच्च पादपों में प्रकाश संश्लेषण - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3d6ed1ae-d372-48f5-94ed-5be660cd89cc.pdf"
            }
          ]
        },
        {
          "serial": 57,
          "title": "व्याख्यान- 58 || उच्च पादपों में प्रकाश संश्लेषण - 7",
          "published_date": "22 Jan 2025",
          "video_url": "https://www.youtube.com/embed/_8UoXD3MAnk",
          "hd_video_url": "https://www.youtube.com/embed/_8UoXD3MAnk",
          "thumbnail": "https://i.ytimg.com/vi/_8UoXD3MAnk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 58 || उच्च पादपों में प्रकाश संश्लेषण - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/45d4e7bb-26ac-48a3-8a62-9dd8f998de67.pdf"
            }
          ]
        },
        {
          "serial": 58,
          "title": "व्याख्यान- 59 || उच्च पादपों में प्रकाश संश्लेषण - 8",
          "published_date": "27 Jan 2025",
          "video_url": "https://www.youtube.com/embed/GxxGCP3Ufi0",
          "hd_video_url": "https://www.youtube.com/embed/GxxGCP3Ufi0",
          "thumbnail": "https://i.ytimg.com/vi/GxxGCP3Ufi0/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 59 || उच्च पादपों में प्रकाश संश्लेषण - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c0ae5a8b-362b-40fa-9f30-0927a6a4fed8.pdf"
            }
          ]
        },
        {
          "serial": 59,
          "title": "व्याख्यान- 60 || उच्च पादपों में प्रकाश संश्लेषण - 9",
          "published_date": "28 Jan 2025",
          "video_url": "https://www.youtube.com/embed/2rCQl7KhaaE",
          "hd_video_url": "https://www.youtube.com/embed/2rCQl7KhaaE",
          "thumbnail": "https://i.ytimg.com/vi/2rCQl7KhaaE/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 60 || उच्च पादपों में प्रकाश संश्लेषण - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0e716813-94d6-4621-9187-cacdde4c4a20.pdf"
            }
          ]
        },
        {
          "serial": 60,
          "title": "व्याख्यान- 61 || उच्च पादपों में प्रकाश संश्लेषण - 10",
          "published_date": "29 Jan 2025",
          "video_url": "https://www.youtube.com/embed/F1oiuJV34vo",
          "hd_video_url": "https://www.youtube.com/embed/F1oiuJV34vo",
          "thumbnail": "https://i.ytimg.com/vi/F1oiuJV34vo/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 61 || उच्च पादपों में प्रकाश संश्लेषण - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b4cc3b53-d5e1-4ec8-a1ff-94bd6fd954b7.pdf"
            }
          ]
        },
        {
          "serial": 61,
          "title": "व्याख्यान- 62 || उच्च पादपों में प्रकाश संश्लेषण - 11",
          "published_date": "30 Jan 2025",
          "video_url": "https://www.youtube.com/embed/iKVdpa9Detg",
          "hd_video_url": "https://www.youtube.com/embed/iKVdpa9Detg",
          "thumbnail": "https://i.ytimg.com/vi/iKVdpa9Detg/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 62 || उच्च पादपों में प्रकाश संश्लेषण - 11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ffe7cc3f-298e-4b2f-a6ed-fdbd7074b4cd.pdf"
            }
          ]
        },
        {
          "serial": 62,
          "title": "व्याख्यान- 63 || पादप में श्वसन - 1",
          "published_date": "03 Feb 2025",
          "video_url": "https://www.youtube.com/embed/fFywtgr6hro",
          "hd_video_url": "https://www.youtube.com/embed/fFywtgr6hro",
          "thumbnail": "https://i.ytimg.com/vi/fFywtgr6hro/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान - 120 || पादप में श्वसन -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/feb0d135-941f-49a2-83f6-2bd263cfb9b4.pdf"
            }
          ]
        },
        {
          "serial": 63,
          "title": "व्याख्यान- 64 || पादप में श्वसन - 2",
          "published_date": "04 Feb 2025",
          "video_url": "https://www.youtube.com/embed/lP5nADZcZh0",
          "hd_video_url": "https://www.youtube.com/embed/lP5nADZcZh0",
          "thumbnail": "https://i.ytimg.com/vi/lP5nADZcZh0/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 64 || पादप में श्वसन - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b521ce9e-1d33-41e2-9cd3-1311e6ba862b.pdf"
            }
          ]
        },
        {
          "serial": 64,
          "title": "व्याख्यान- 65 || पादप में श्वसन - 3",
          "published_date": "05 Feb 2025",
          "video_url": "https://www.youtube.com/embed/sECRnk7RoeE",
          "hd_video_url": "https://www.youtube.com/embed/sECRnk7RoeE",
          "thumbnail": "https://i.ytimg.com/vi/sECRnk7RoeE/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान - 122 || पादप में श्वसन-3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0997f2b1-c8ad-4b11-8a4f-c581a29d2909.pdf"
            }
          ]
        },
        {
          "serial": 65,
          "title": "व्याख्यान- 66 || पादप में श्वसन - 4",
          "published_date": "10 Feb 2025",
          "video_url": "https://www.youtube.com/embed/GXxI9WeILIc",
          "hd_video_url": "https://www.youtube.com/embed/GXxI9WeILIc",
          "thumbnail": "https://i.ytimg.com/vi/GXxI9WeILIc/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 66 || पादप में श्वसन - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7d1584d8-8936-47a4-8f9b-1d6f99656ab6.pdf"
            }
          ]
        },
        {
          "serial": 66,
          "title": "व्याख्यान- 67 || पादप में श्वसन - 5",
          "published_date": "14 Feb 2025",
          "video_url": "https://www.youtube.com/embed/IdxjQLdWJdA",
          "hd_video_url": "https://www.youtube.com/embed/IdxjQLdWJdA",
          "thumbnail": "https://i.ytimg.com/vi/IdxjQLdWJdA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 67 || पादप में श्वसन - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/47a63bd9-236f-4a52-9806-6d7a402d3e94.pdf"
            }
          ]
        },
        {
          "serial": 67,
          "title": "व्याख्यान- 68 || पादप में श्वसन - 6",
          "published_date": "17 Feb 2025",
          "video_url": "https://www.youtube.com/embed/hejfE9h5n5k",
          "hd_video_url": "https://www.youtube.com/embed/hejfE9h5n5k",
          "thumbnail": "https://i.ytimg.com/vi/hejfE9h5n5k/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 68 || पादप में श्वसन - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a30af2dd-7d13-4cf1-9ab7-9de62edd4683.pdf"
            }
          ]
        },
        {
          "serial": 68,
          "title": "व्याख्यान- 69 || पादप वृद्धि एवं परिवर्धन -1",
          "published_date": "18 Feb 2025",
          "video_url": "https://www.youtube.com/embed/1vSUIWgAKws",
          "hd_video_url": "https://www.youtube.com/embed/1vSUIWgAKws",
          "thumbnail": "https://i.ytimg.com/vi/1vSUIWgAKws/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 69 || पादप वृद्धि एवं परिवर्धन -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c7095884-e2f8-48e9-81dd-c2ec7e00cf48.pdf"
            }
          ]
        },
        {
          "serial": 69,
          "title": "व्याख्यान- 70 || पादप वृद्धि एवं परिवर्धन -2",
          "published_date": "19 Feb 2025",
          "video_url": "https://www.youtube.com/embed/2SJ20JO9NqE",
          "hd_video_url": "https://www.youtube.com/embed/2SJ20JO9NqE",
          "thumbnail": "https://i.ytimg.com/vi/2SJ20JO9NqE/default.jpg",
          "notes": [
            {
              "title": "Class Notes- व्याख्यान- 70 || पादप वृद्धि एवं परिवर्धन -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/43bddaea-ac7c-4a30-b2eb-da64d5eb0760.pdf"
            }
          ]
        },
        {
          "serial": 70,
          "title": "व्याख्यान- 71 || पादप वृद्धि एवं परिवर्धन -3",
          "published_date": "22 Feb 2025",
          "video_url": "https://www.youtube.com/embed/yQK1J2WqL5k",
          "hd_video_url": "https://www.youtube.com/embed/yQK1J2WqL5k",
          "thumbnail": "https://i.ytimg.com/vi/yQK1J2WqL5k/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 71 || पादप वृद्धि एवं परिवर्धन -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4da0454f-34d4-4404-aeab-d05c4c002232.pdf"
            }
          ]
        },
        {
          "serial": 71,
          "title": "व्याख्यान- 72 || पादप वृद्धि एवं परिवर्धन -4",
          "published_date": "24 Feb 2025",
          "video_url": "https://www.youtube.com/embed/OpTSfDwPx_s",
          "hd_video_url": "https://www.youtube.com/embed/OpTSfDwPx_s",
          "thumbnail": "https://i.ytimg.com/vi/OpTSfDwPx_s/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 72 || पादप वृद्धि एवं परिवर्धन -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6ea00fe1-fc27-43cc-b3e4-ea8f8d93b80b.pdf"
            }
          ]
        },
        {
          "serial": 72,
          "title": "व्याख्यान- 73 || पुष्पी पादपों का शारीर - 1",
          "published_date": "25 Feb 2025",
          "video_url": "https://www.youtube.com/embed/O37khDL4794",
          "hd_video_url": "https://www.youtube.com/embed/O37khDL4794",
          "thumbnail": "https://i.ytimg.com/vi/O37khDL4794/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 73 || पुष्पी पादपों का शारीर - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7e47159b-7453-4d5e-8820-3c929a0ee431.pdf"
            }
          ]
        },
        {
          "serial": 73,
          "title": "व्याख्यान- 74 || पुष्पी पादपों का शारीर - 2",
          "published_date": "03 Mar 2025",
          "video_url": "https://www.youtube.com/embed/ACWIady_YsM",
          "hd_video_url": "https://www.youtube.com/embed/ACWIady_YsM",
          "thumbnail": "https://i.ytimg.com/vi/ACWIady_YsM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 74 || पुष्पी पादपों का शारीर - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/92e0bfe4-57b1-4a46-aae5-5d641821fcda.pdf"
            }
          ]
        },
        {
          "serial": 74,
          "title": "व्याख्यान- 75 || पुष्पी पादपों का शरीर -3 & पुष्पी पादपों की आकारिकी - 1",
          "published_date": "04 Mar 2025",
          "video_url": "https://www.youtube.com/embed/qIlcea3DwwI",
          "hd_video_url": "https://www.youtube.com/embed/qIlcea3DwwI",
          "thumbnail": "https://i.ytimg.com/vi/qIlcea3DwwI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 75 || पुष्पी पादपों का शरीर -3 & पुष्पी पादपों की आकारिकी - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/756abf28-66a8-4f72-b0e1-0e9147eb899e.pdf"
            }
          ]
        },
        {
          "serial": 75,
          "title": "व्याख्यान- 76 ||  पुष्पी पादपों की आकारिकी - 2",
          "published_date": "05 Mar 2025",
          "video_url": "https://www.youtube.com/embed/FxLHIyLIDMw",
          "hd_video_url": "https://www.youtube.com/embed/FxLHIyLIDMw",
          "thumbnail": "https://i.ytimg.com/vi/FxLHIyLIDMw/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 76 ||  पुष्पी पादपों की आकारिकी - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9e1e651e-9c75-4158-aece-d2ab6723f71e.pdf"
            }
          ]
        },
        {
          "serial": 76,
          "title": "व्याख्यान- 77 || पुष्पी पादपों की आकारिकी - 3",
          "published_date": "08 Mar 2025",
          "video_url": "https://www.youtube.com/embed/vdcz_BMc6po",
          "hd_video_url": "https://www.youtube.com/embed/vdcz_BMc6po",
          "thumbnail": "https://i.ytimg.com/vi/vdcz_BMc6po/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 77 || पुष्पी पादपों की आकारिकी - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/31cd2adc-b21e-4547-bd7d-d7afd4d8749c.pdf"
            }
          ]
        }
      ],
      "notes": []
    },
    {
      "subject_name": "Botany Supporting Material",
      "subject_id": 3428,
      "video_count": 1,
      "note_count": 1,
      "videos": [
        {
          "serial": 1,
          "title": "DPP Discussion || पुष्पीय पादपों में लैंगिक प्रजनन -01",
          "published_date": "04 Oct 2024",
          "video_url": "https://www.youtube.com/embed/Sp6fZ0nUeTU",
          "hd_video_url": "https://www.youtube.com/embed/Sp6fZ0nUeTU",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - DPP Discussion || पुष्पीय पादपों में लैंगिक प्रजनन -01",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6e9c53b9-1a3a-4e83-89ea-6cbdc48be673.pdf"
            }
          ]
        }
      ],
      "notes": []
    },
    {
      "subject_name": "Chemistry By Gogi sir",
      "subject_id": 3906,
      "video_count": 118,
      "note_count": 115,
      "videos": [
        {
          "serial": 1,
          "title": "व्याख्यान- 01 || IUPAC नामकरण - 1",
          "published_date": "18 Oct 2024",
          "video_url": "https://www.youtube.com/embed/poci4cWWVhA",
          "hd_video_url": "https://www.youtube.com/embed/poci4cWWVhA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/SzqAvEGT1ueWddGqtsX97sgSOOL6omMVbqXbQ30Z.jpg",
          "notes": []
        },
        {
          "serial": 2,
          "title": "व्याख्यान- 02 || IUPAC नामकरण - 2",
          "published_date": "19 Oct 2024",
          "video_url": "https://www.youtube.com/embed/hqBi6vvczSs",
          "hd_video_url": "https://www.youtube.com/embed/hqBi6vvczSs",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/fyFCUQKyhvAhzylD4GWybu0t00vNLQzVQVwqUAQZ.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 02 || IUPAC नामकरण - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/952062d3-fc54-4f64-bf5f-d23a1e6eedf4.pdf"
            }
          ]
        },
        {
          "serial": 3,
          "title": "व्याख्यान- 03 || समावयवता - 1",
          "published_date": "21 Oct 2024",
          "video_url": "https://www.youtube.com/embed/d5wyJJDXTEk",
          "hd_video_url": "https://www.youtube.com/embed/d5wyJJDXTEk",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/kck55z8BOzBlspbMe2KhigX11fCdV9Iaaw1MxJzq.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 03 || समावयवता - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1a96be25-6e6b-4976-b16c-4729c9cd046d.pdf"
            }
          ]
        },
        {
          "serial": 4,
          "title": "व्याख्यान- 04 || समावयवता - 2",
          "published_date": "22 Oct 2024",
          "video_url": "https://www.youtube.com/embed/J1sO-b7aG6U",
          "hd_video_url": "https://www.youtube.com/embed/J1sO-b7aG6U",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/nO9pTiUsjy6DPHLbWD0OcddGn5IX6lQCBM5i83SG.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 04 || समावयवता - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/78e42fd9-9e52-4292-847c-f29729d37eba.pdf"
            }
          ]
        },
        {
          "serial": 5,
          "title": "व्याख्यान- 05 || समावयवता - 3",
          "published_date": "23 Oct 2024",
          "video_url": "https://www.youtube.com/embed/DXTAT0SkVvg",
          "hd_video_url": "https://www.youtube.com/embed/DXTAT0SkVvg",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/v5IGAyGZtN6ECJT566IoFS9EiYoHf8QGemzzNW6l.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 05 || समावयवता - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c9751bbe-ed0e-43f2-b576-b1c456663cc2.pdf"
            }
          ]
        },
        {
          "serial": 6,
          "title": "व्याख्यान- 06 || समावयवता - 4",
          "published_date": "24 Oct 2024",
          "video_url": "https://www.youtube.com/embed/0mANdIONu1M",
          "hd_video_url": "https://www.youtube.com/embed/0mANdIONu1M",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/suYR3CAcrS45dMOnLFR2zRIOqXJMcuyC0WeJ6ctp.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 06 || समावयवता - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/705e4361-731d-4778-b90c-54a540aeb8c7.pdf"
            }
          ]
        },
        {
          "serial": 7,
          "title": "व्याख्यान- 07 || समावयवता - 5",
          "published_date": "25 Oct 2024",
          "video_url": "https://www.youtube.com/embed/Aut2uRWLV1w",
          "hd_video_url": "https://www.youtube.com/embed/Aut2uRWLV1w",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/wL0gCPSDKT8NdybPttRfnxkdELg5tz66CBXicy9r.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 07 || समावयवता - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ea6b6bc5-3516-4eee-b0e1-13ef7d05d843.pdf"
            }
          ]
        },
        {
          "serial": 8,
          "title": "व्याख्यान- 08 || समावयवता - 6",
          "published_date": "26 Oct 2024",
          "video_url": "https://www.youtube.com/embed/Be8nc_bfRAQ",
          "hd_video_url": "https://www.youtube.com/embed/Be8nc_bfRAQ",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/Fdkuvaee2WXPMTDcyPP57kplz1FdBFn204HeVSsL.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 08 || समावयवता - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e299a37f-6fe2-4d7f-9c1e-fa648b9e9792.pdf"
            }
          ]
        },
        {
          "serial": 9,
          "title": "व्याख्यान- 09 || समावयवता - 7",
          "published_date": "28 Oct 2024",
          "video_url": "https://www.youtube.com/embed/X0l7PBtu9JM",
          "hd_video_url": "https://www.youtube.com/embed/X0l7PBtu9JM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/7mZaDycsj1t6zcchl3PFLYrgcI4Tg3gbtfPcr0Hu.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 09 || समावयवता - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b93e8e94-5be2-4855-8438-6c8ad6f2f0d5.pdf"
            }
          ]
        },
        {
          "serial": 10,
          "title": "व्याख्यान- 10 || समावयवता - 8",
          "published_date": "04 Nov 2024",
          "video_url": "https://www.youtube.com/embed/FnNlBy5leRU",
          "hd_video_url": "https://www.youtube.com/embed/FnNlBy5leRU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/mdsEtm8wEKVR60jM22Z3gM7NhiyjJbJQHo1GncBg.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 10 || समावयवता - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/37591ef8-ef49-480c-94d7-b9884468b0c0.pdf"
            }
          ]
        },
        {
          "serial": 11,
          "title": "व्याख्यान- 11 || समावयवता - 9",
          "published_date": "06 Nov 2024",
          "video_url": "https://www.youtube.com/embed/O-P1s8ErDU4",
          "hd_video_url": "https://www.youtube.com/embed/O-P1s8ErDU4",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/J1MneJZDAZQIvDeiayKYwXUvl0r5GzsXSjMLyzfz.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 11 || समावयवता - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f6e264bb-a50f-4f9d-95d9-277df0c3d8d8.pdf"
            }
          ]
        },
        {
          "serial": 12,
          "title": "व्याख्यान- 12 || समावयवता - 10",
          "published_date": "07 Nov 2024",
          "video_url": "https://www.youtube.com/embed/RHjU6UevCWo",
          "hd_video_url": "https://www.youtube.com/embed/RHjU6UevCWo",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/6FUl768MDDOCUMogk0jnXn8HaMUeuyEFGN7baB18.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 12 || समावयवता - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8fcdbbb3-fb69-4f09-beb5-3e1e66a117e4.pdf"
            }
          ]
        },
        {
          "serial": 13,
          "title": "व्याख्यान- 13 || समावयवता - 11",
          "published_date": "08 Nov 2024",
          "video_url": "https://www.youtube.com/embed/0fq49UJwLO8",
          "hd_video_url": "https://www.youtube.com/embed/0fq49UJwLO8",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/qgeAwNCUgafeRM933WxiybkB9yvuDa1YmdmvcU24.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 13 || समावयवता - 11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/808e9c2d-ccfa-482d-be3d-581b400b70e6.pdf"
            }
          ]
        },
        {
          "serial": 14,
          "title": "व्याख्यान- 14 || सामान्य कार्बनिक रसायन -1",
          "published_date": "09 Nov 2024",
          "video_url": "https://www.youtube.com/embed/B_9zDYFd-c0",
          "hd_video_url": "https://www.youtube.com/embed/B_9zDYFd-c0",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/T303yNtZygvlVLcNrq8o26V7QZlPiVSubWmfKNbI.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 14 || सामान्य कार्बनिक रसायन -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/816ad5e1-d788-4de3-b8c8-c60ca1489834.pdf"
            }
          ]
        },
        {
          "serial": 15,
          "title": "व्याख्यान- 15 || सामान्य कार्बनिक रसायन -2",
          "published_date": "11 Nov 2024",
          "video_url": "https://www.youtube.com/embed/_QAYFS8huNk",
          "hd_video_url": "https://www.youtube.com/embed/_QAYFS8huNk",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/CWCxlXK5SW2jM9YxgE7gob3y6xbl6x4VvZIqHN7l.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 15 || सामान्य कार्बनिक रसायन -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/631a9a79-81b7-4433-8759-5f7321da737e.pdf"
            }
          ]
        },
        {
          "serial": 16,
          "title": "व्याख्यान- 16 || सामान्य कार्बनिक रसायन -3",
          "published_date": "12 Nov 2024",
          "video_url": "https://www.youtube.com/embed/mY2Ue4rsxOU",
          "hd_video_url": "https://www.youtube.com/embed/mY2Ue4rsxOU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/am1aqbV9MZlJxJpYPDEBRkuYLmlP1ebDyu9FK9Or.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 16 || सामान्य कार्बनिक रसायन -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d5667f65-ebe0-44a0-a20d-08c223daabc1.pdf"
            }
          ]
        },
        {
          "serial": 17,
          "title": "व्याख्यान- 17 || Unit test Discussion",
          "published_date": "15 Nov 2024",
          "video_url": "https://www.youtube.com/embed/vwZkmOnz46o",
          "hd_video_url": "https://www.youtube.com/embed/vwZkmOnz46o",
          "thumbnail": "https://i.ytimg.com/vi/vwZkmOnz46o/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 17 || Unit test Discussion",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/27e6a0bf-18eb-470b-a80b-b967492901d2.pdf"
            }
          ]
        },
        {
          "serial": 18,
          "title": "व्याख्यान- 18 || सामान्य कार्बनिक रसायन -4",
          "published_date": "16 Nov 2024",
          "video_url": "https://www.youtube.com/embed/THFCmLs89VA",
          "hd_video_url": "https://www.youtube.com/embed/THFCmLs89VA",
          "thumbnail": "https://i.ytimg.com/vi/THFCmLs89VA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 18 || सामान्य कार्बनिक रसायन -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ea9d3924-0f7a-4a85-b71d-e4b14f2dd62d.pdf"
            }
          ]
        },
        {
          "serial": 19,
          "title": "व्याख्यान- 19 || सामान्य कार्बनिक रसायन -5",
          "published_date": "18 Nov 2024",
          "video_url": "https://www.youtube.com/embed/vK93CPsVTDs",
          "hd_video_url": "https://www.youtube.com/embed/vK93CPsVTDs",
          "thumbnail": "https://i.ytimg.com/vi/vK93CPsVTDs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 19 || सामान्य कार्बनिक रसायन -5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/654cd971-dff2-4105-80fa-9c698409f726.pdf"
            }
          ]
        },
        {
          "serial": 20,
          "title": "व्याख्यान- 20 || सामान्य कार्बनिक रसायन -6",
          "published_date": "19 Nov 2024",
          "video_url": "https://www.youtube.com/embed/6WB33CZFyNA",
          "hd_video_url": "https://www.youtube.com/embed/6WB33CZFyNA",
          "thumbnail": "https://i.ytimg.com/vi/6WB33CZFyNA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 20 || सामान्य कार्बनिक रसायन -6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9613f573-6039-45c2-b133-7e93ed82647b.pdf"
            }
          ]
        },
        {
          "serial": 21,
          "title": "व्याख्यान- 21 || सामान्य कार्बनिक रसायन -7",
          "published_date": "20 Nov 2024",
          "video_url": "https://www.youtube.com/embed/FbrfviA2_pU",
          "hd_video_url": "https://www.youtube.com/embed/FbrfviA2_pU",
          "thumbnail": "https://i.ytimg.com/vi/FbrfviA2_pU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 21 || सामान्य कार्बनिक रसायन -7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fd818d96-0386-4f27-b4f4-3bfb32319997.pdf"
            }
          ]
        },
        {
          "serial": 22,
          "title": "व्याख्यान- 22 || सामान्य कार्बनिक रसायन -8",
          "published_date": "21 Nov 2024",
          "video_url": "https://www.youtube.com/embed/xGZ1ggNFpfw",
          "hd_video_url": "https://www.youtube.com/embed/xGZ1ggNFpfw",
          "thumbnail": "https://i.ytimg.com/vi/xGZ1ggNFpfw/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 22 || सामान्य कार्बनिक रसायन -8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6b7a7073-b8d9-42e3-8484-e4ebba71d615.pdf"
            }
          ]
        },
        {
          "serial": 23,
          "title": "व्याख्यान- 23 || सामान्य कार्बनिक रसायन -9",
          "published_date": "22 Nov 2024",
          "video_url": "https://www.youtube.com/embed/P_ECIfJ1r9Y",
          "hd_video_url": "https://www.youtube.com/embed/P_ECIfJ1r9Y",
          "thumbnail": "https://i.ytimg.com/vi/P_ECIfJ1r9Y/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 23 || सामान्य कार्बनिक रसायन -9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f4533354-cc93-4bed-b9bd-a1875debb91a.pdf"
            }
          ]
        },
        {
          "serial": 24,
          "title": "व्याख्यान- 24 || सामान्य कार्बनिक रसायन -10",
          "published_date": "23 Nov 2024",
          "video_url": "https://www.youtube.com/embed/YKkv_MXg1Uo",
          "hd_video_url": "https://www.youtube.com/embed/YKkv_MXg1Uo",
          "thumbnail": "https://i.ytimg.com/vi/YKkv_MXg1Uo/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 24 || सामान्य कार्बनिक रसायन -10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/24a5e0bc-2b7e-4086-aa66-a48540862628.pdf"
            }
          ]
        },
        {
          "serial": 25,
          "title": "व्याख्यान- 25 || सामान्य कार्बनिक रसायन -11",
          "published_date": "25 Nov 2024",
          "video_url": "https://www.youtube.com/embed/2wpIAsJdSFA",
          "hd_video_url": "https://www.youtube.com/embed/2wpIAsJdSFA",
          "thumbnail": "https://i.ytimg.com/vi/2wpIAsJdSFA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 25 || सामान्य कार्बनिक रसायन -11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/dcbc18be-d368-475e-a8ca-aed792217488.pdf"
            }
          ]
        },
        {
          "serial": 26,
          "title": "व्याख्यान- 26 || सामान्य कार्बनिक रसायन -12",
          "published_date": "26 Nov 2024",
          "video_url": "https://www.youtube.com/embed/peVT9SyACGU",
          "hd_video_url": "https://www.youtube.com/embed/peVT9SyACGU",
          "thumbnail": "https://i.ytimg.com/vi/peVT9SyACGU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 26 || सामान्य कार्बनिक रसायन -12",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fcdc2a5a-587d-4305-b245-9bc7393b4e75.pdf"
            }
          ]
        },
        {
          "serial": 27,
          "title": "व्याख्यान- 27 || सामान्य कार्बनिक रसायन -13",
          "published_date": "27 Nov 2024",
          "video_url": "https://www.youtube.com/embed/JTGpfyev5dA",
          "hd_video_url": "https://www.youtube.com/embed/JTGpfyev5dA",
          "thumbnail": "https://i.ytimg.com/vi/JTGpfyev5dA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 27 || सामान्य कार्बनिक रसायन -13",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/75c8ac60-9698-472b-8673-9cc0f28ebe1e.pdf"
            }
          ]
        },
        {
          "serial": 28,
          "title": "व्याख्यान- 28 || सामान्य कार्बनिक रसायन -14",
          "published_date": "28 Nov 2024",
          "video_url": "https://www.youtube.com/embed/kYN8Si6odyE",
          "hd_video_url": "https://www.youtube.com/embed/kYN8Si6odyE",
          "thumbnail": "https://i.ytimg.com/vi/kYN8Si6odyE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 28 || सामान्य कार्बनिक रसायन -14",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9e92e83a-b0b1-4ef1-9267-0ae0715d8c11.pdf"
            }
          ]
        },
        {
          "serial": 29,
          "title": "व्याख्यान- 29 || हाइड्रोकार्बन - 1",
          "published_date": "29 Nov 2024",
          "video_url": "https://www.youtube.com/embed/Z4a3eFLnM6U",
          "hd_video_url": "https://www.youtube.com/embed/Z4a3eFLnM6U",
          "thumbnail": "https://i.ytimg.com/vi/Z4a3eFLnM6U/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 29 || हाइड्रोकार्बन - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/864d8b6c-e36b-43a4-9ba1-373743173f79.pdf"
            }
          ]
        },
        {
          "serial": 30,
          "title": "व्याख्यान- 30 || हाइड्रोकार्बन - 2",
          "published_date": "30 Nov 2024",
          "video_url": "https://www.youtube.com/embed/7y2eBifuunU",
          "hd_video_url": "https://www.youtube.com/embed/7y2eBifuunU",
          "thumbnail": "https://i.ytimg.com/vi/7y2eBifuunU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 30 || हाइड्रोकार्बन - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/03d383ae-eac3-446e-a252-1e659e12182a.pdf"
            }
          ]
        },
        {
          "serial": 31,
          "title": "व्याख्यान- 31 || हाइड्रोकार्बन - 3",
          "published_date": "02 Dec 2024",
          "video_url": "https://www.youtube.com/embed/5W5aViOqME8",
          "hd_video_url": "https://www.youtube.com/embed/5W5aViOqME8",
          "thumbnail": "https://i.ytimg.com/vi/5W5aViOqME8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 31 || हाइड्रोकार्बन - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/51da116b-3eae-43ec-9a31-fc535bde8b77.pdf"
            }
          ]
        },
        {
          "serial": 32,
          "title": "व्याख्यान- 32 || हाइड्रोकार्बन - 4",
          "published_date": "04 Dec 2024",
          "video_url": "https://www.youtube.com/embed/fJzm2ajmuEA",
          "hd_video_url": "https://www.youtube.com/embed/fJzm2ajmuEA",
          "thumbnail": "https://i.ytimg.com/vi/fJzm2ajmuEA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 32 || हाइड्रोकार्बन - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/25d7034a-c819-4c94-91b5-c71cdd39e7ae.pdf"
            }
          ]
        },
        {
          "serial": 33,
          "title": "व्याख्यान- 33 || हाइड्रोकार्बन - 5",
          "published_date": "05 Dec 2024",
          "video_url": "https://www.youtube.com/embed/C0AcpzlieqM",
          "hd_video_url": "https://www.youtube.com/embed/C0AcpzlieqM",
          "thumbnail": "https://i.ytimg.com/vi/C0AcpzlieqM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 33 || हाइड्रोकार्बन - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ec614307-8d52-4983-ac79-d9effba77394.pdf"
            }
          ]
        },
        {
          "serial": 34,
          "title": "व्याख्यान- 34 || हाइड्रोकार्बन - 6",
          "published_date": "06 Dec 2024",
          "video_url": "https://www.youtube.com/embed/lCVBwUTg-jk",
          "hd_video_url": "https://www.youtube.com/embed/lCVBwUTg-jk",
          "thumbnail": "https://i.ytimg.com/vi/lCVBwUTg-jk/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 34  हाइड्रोकार्बन - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6bc3c64a-d6cf-4151-aa9e-6e8d283fab84.pdf"
            }
          ]
        },
        {
          "serial": 35,
          "title": "व्याख्यान- 35 || हाइड्रोकार्बन - 7",
          "published_date": "07 Dec 2024",
          "video_url": "https://www.youtube.com/embed/cd9RcawJYy8",
          "hd_video_url": "https://www.youtube.com/embed/cd9RcawJYy8",
          "thumbnail": "https://i.ytimg.com/vi/cd9RcawJYy8/default.jpg",
          "notes": []
        },
        {
          "serial": 36,
          "title": "व्याख्यान- 36 || हाइड्रोकार्बन - 8",
          "published_date": "09 Dec 2024",
          "video_url": "https://www.youtube.com/embed/SyTYjsE6zfQ",
          "hd_video_url": "https://www.youtube.com/embed/SyTYjsE6zfQ",
          "thumbnail": "https://i.ytimg.com/vi/SyTYjsE6zfQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 36 || हाइड्रोकार्बन - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/91dc73b9-e620-4352-b738-5b2a7aef6529.pdf"
            }
          ]
        },
        {
          "serial": 37,
          "title": "व्याख्यान- 37 ||  हाइड्रोकार्बन - 9",
          "published_date": "10 Dec 2024",
          "video_url": "https://www.youtube.com/embed/kr40SXMgc_0",
          "hd_video_url": "https://www.youtube.com/embed/kr40SXMgc_0",
          "thumbnail": "https://i.ytimg.com/vi/kr40SXMgc_0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 37 ||  हाइड्रोकार्बन - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/dff5fd7d-b744-4d01-be15-5f752284d1dc.pdf"
            }
          ]
        },
        {
          "serial": 38,
          "title": "व्याख्यान- 38 || Unit test Discussion",
          "published_date": "11 Dec 2024",
          "video_url": "https://www.youtube.com/embed/1nnrg96fpRE",
          "hd_video_url": "https://www.youtube.com/embed/1nnrg96fpRE",
          "thumbnail": "https://i.ytimg.com/vi/1nnrg96fpRE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 38 || Unit test Discussion",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/462f3ecf-f6b2-4fd0-98ca-1393b7d995d7.pdf"
            }
          ]
        },
        {
          "serial": 39,
          "title": "व्याख्यान- 39 || हाइड्रोकार्बन - 10",
          "published_date": "12 Dec 2024",
          "video_url": "https://www.youtube.com/embed/3_NdS0QJWRw",
          "hd_video_url": "https://www.youtube.com/embed/3_NdS0QJWRw",
          "thumbnail": "https://i.ytimg.com/vi/3_NdS0QJWRw/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 39 || हाइड्रोकार्बन - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/00e8a163-1108-43d1-9952-11b24c106983.pdf"
            }
          ]
        },
        {
          "serial": 40,
          "title": "व्याख्यान- 38 || हेलोऐल्केन और हेलोएरीन - 1",
          "published_date": "17 Dec 2024",
          "video_url": "https://www.youtube.com/embed/vDNWh6ADxCk",
          "hd_video_url": "https://www.youtube.com/embed/vDNWh6ADxCk",
          "thumbnail": "https://i.ytimg.com/vi/vDNWh6ADxCk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 38 || हेलोऐल्केन और हेलोएरीन - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/404b4bd0-ee9d-476a-8fa4-a098c8b2e1fc.pdf"
            }
          ]
        },
        {
          "serial": 41,
          "title": "व्याख्यान- 39 || हेलोऐल्केन और हेलोएरीन - 2",
          "published_date": "18 Dec 2024",
          "video_url": "https://www.youtube.com/embed/EO69IjMbz98",
          "hd_video_url": "https://www.youtube.com/embed/EO69IjMbz98",
          "thumbnail": "https://i.ytimg.com/vi/EO69IjMbz98/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 39 || हेलोऐल्केन और हेलोएरीन - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8e1a0083-4bea-48a5-a044-830a632a6850.pdf"
            }
          ]
        },
        {
          "serial": 42,
          "title": "व्याख्यान- 40 || हेलोऐल्केन और हेलोएरीन - 3",
          "published_date": "19 Dec 2024",
          "video_url": "https://www.youtube.com/embed/6Rwjraoamyk",
          "hd_video_url": "https://www.youtube.com/embed/6Rwjraoamyk",
          "thumbnail": "https://i.ytimg.com/vi/6Rwjraoamyk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 40 || हेलोऐल्केन और हेलोएरीन - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/180126cd-4183-4b9e-92c6-4457235a61e4.pdf"
            }
          ]
        },
        {
          "serial": 43,
          "title": "व्याख्यान- 41 || हेलोऐल्केन और हेलोएरीन - 4",
          "published_date": "20 Dec 2024",
          "video_url": "https://www.youtube.com/embed/S-3LLeMbruM",
          "hd_video_url": "https://www.youtube.com/embed/S-3LLeMbruM",
          "thumbnail": "https://i.ytimg.com/vi/S-3LLeMbruM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 41 || हेलोऐल्केन और हेलोएरीन - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9d398cb1-2f8f-4a8f-aaa2-bd11528738fd.pdf"
            }
          ]
        },
        {
          "serial": 44,
          "title": "व्याख्यान- 42 || हेलोऐल्केन और हेलोएरीन - 5",
          "published_date": "21 Dec 2024",
          "video_url": "https://www.youtube.com/embed/q1Mk6BzSvYs",
          "hd_video_url": "https://www.youtube.com/embed/q1Mk6BzSvYs",
          "thumbnail": "https://i.ytimg.com/vi/q1Mk6BzSvYs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 42 || हेलोऐल्केन और हेलोएरीन - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0385c026-2424-4c36-85ef-82443f45d3d7.pdf"
            }
          ]
        },
        {
          "serial": 45,
          "title": "व्याख्यान- 43 || हेलोऐल्केन और हेलोएरीन - 6",
          "published_date": "23 Dec 2024",
          "video_url": "https://www.youtube.com/embed/ifni_yvQTyA",
          "hd_video_url": "https://www.youtube.com/embed/ifni_yvQTyA",
          "thumbnail": "https://i.ytimg.com/vi/ifni_yvQTyA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 43 || हेलोऐल्केन और हेलोएरीन - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/bdb9110d-b5f9-4db0-887d-3f7abf60fde9.pdf"
            }
          ]
        },
        {
          "serial": 46,
          "title": "व्याख्यान- 44 || हेलोऐल्केन और हेलोएरीन - 7",
          "published_date": "24 Dec 2024",
          "video_url": "https://www.youtube.com/embed/5awT_h4GSnY",
          "hd_video_url": "https://www.youtube.com/embed/5awT_h4GSnY",
          "thumbnail": "https://i.ytimg.com/vi/5awT_h4GSnY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 44 || हेलोऐल्केन और हेलोएरीन - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/13d6e112-902e-4e15-862b-0c20d3b3eee0.pdf"
            }
          ]
        },
        {
          "serial": 47,
          "title": "व्याख्यान- 45 || हेलोऐल्केन और हेलोएरीन - 8",
          "published_date": "25 Dec 2024",
          "video_url": "https://www.youtube.com/embed/4QkYrdO12no",
          "hd_video_url": "https://www.youtube.com/embed/4QkYrdO12no",
          "thumbnail": "https://i.ytimg.com/vi/4QkYrdO12no/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 45 || हेलोऐल्केन और हेलोएरीन - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/654f418f-eecb-4dee-813f-6ad7831d4339.pdf"
            }
          ]
        },
        {
          "serial": 48,
          "title": "व्याख्यान- 46 || अल्कोहल, फिनोल और ईथर-1",
          "published_date": "26 Dec 2024",
          "video_url": "https://www.youtube.com/embed/iIHr7OT22IQ",
          "hd_video_url": "https://www.youtube.com/embed/iIHr7OT22IQ",
          "thumbnail": "https://i.ytimg.com/vi/iIHr7OT22IQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 46 || अल्कोहल, फिनोल और ईथर-1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/75e65777-642b-4b59-be0d-eac7fe7ddbb2.pdf"
            }
          ]
        },
        {
          "serial": 49,
          "title": "व्याख्यान- 47 || अल्कोहल, फिनोल और ईथर-2",
          "published_date": "27 Dec 2024",
          "video_url": "https://www.youtube.com/embed/0joVzCqi3Do",
          "hd_video_url": "https://www.youtube.com/embed/0joVzCqi3Do",
          "thumbnail": "https://i.ytimg.com/vi/0joVzCqi3Do/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 47 || अल्कोहल, फिनोल और ईथर-2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/89d7ba5c-6c92-471e-a600-c8ebf6f702a8.pdf"
            }
          ]
        },
        {
          "serial": 50,
          "title": "व्याख्यान- 48 || अल्कोहल, फिनोल और ईथर-3",
          "published_date": "02 Jan 2025",
          "video_url": "https://www.youtube.com/embed/QTA56WFhyNY",
          "hd_video_url": "https://www.youtube.com/embed/QTA56WFhyNY",
          "thumbnail": "https://i.ytimg.com/vi/QTA56WFhyNY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 48 || अल्कोहल, फिनोल और ईथर-3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e3ab3f6e-5536-4b9f-b60a-138d7454baf1.pdf"
            }
          ]
        },
        {
          "serial": 51,
          "title": "व्याख्यान- 49 || अल्कोहल, फिनोल और ईथर-4",
          "published_date": "03 Jan 2025",
          "video_url": "https://www.youtube.com/embed/x5COkLucXME",
          "hd_video_url": "https://www.youtube.com/embed/x5COkLucXME",
          "thumbnail": "https://i.ytimg.com/vi/x5COkLucXME/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 49 || अल्कोहल, फिनोल और ईथर-4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7c484baf-dd6e-442c-b6f9-cac8a62595d7.pdf"
            }
          ]
        },
        {
          "serial": 52,
          "title": "व्याख्यान- 50 || अल्कोहल, फिनोल और ईथर-5",
          "published_date": "04 Jan 2025",
          "video_url": "https://www.youtube.com/embed/dlxc0uVZWec",
          "hd_video_url": "https://www.youtube.com/embed/dlxc0uVZWec",
          "thumbnail": "https://i.ytimg.com/vi/dlxc0uVZWec/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 50 || अल्कोहल, फिनोल और ईथर-5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/aec80471-35fa-4cec-b50f-a4119e019794.pdf"
            }
          ]
        },
        {
          "serial": 53,
          "title": "व्याख्यान- 51 || अल्कोहल, फिनोल और ईथर-6",
          "published_date": "06 Jan 2025",
          "video_url": "https://www.youtube.com/embed/xwW0ygyvTSY",
          "hd_video_url": "https://www.youtube.com/embed/xwW0ygyvTSY",
          "thumbnail": "https://i.ytimg.com/vi/xwW0ygyvTSY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 51 || अल्कोहल, फिनोल और ईथर-6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/60799564-304e-4793-947e-706c7527e4f1.pdf"
            }
          ]
        },
        {
          "serial": 54,
          "title": "व्याख्यान - 52 || अल्कोहल, फिनोल और ईथर-7",
          "published_date": "07 Jan 2025",
          "video_url": "https://www.youtube.com/embed/21kMClDbN50",
          "hd_video_url": "https://www.youtube.com/embed/21kMClDbN50",
          "thumbnail": "https://i.ytimg.com/vi/21kMClDbN50/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 52 || अल्कोहल, फिनोल और ईथर-7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/616667ab-82d3-45e7-9ccb-6379b5e11215.pdf"
            }
          ]
        },
        {
          "serial": 55,
          "title": "व्याख्यान - 53 || Unit Test Solution",
          "published_date": "08 Jan 2025",
          "video_url": "https://www.youtube.com/embed/B3EPHWoV5O0",
          "hd_video_url": "https://www.youtube.com/embed/B3EPHWoV5O0",
          "thumbnail": "https://i.ytimg.com/vi/B3EPHWoV5O0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 59 || Unit Test Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9a7dcca3-15ef-4d7e-a9da-4201ae4ecacb.pdf"
            }
          ]
        },
        {
          "serial": 56,
          "title": "व्याख्यान - 54 || अल्कोहल, फिनोल और ईथर-8",
          "published_date": "09 Jan 2025",
          "video_url": "https://www.youtube.com/embed/Vn523pwRhso",
          "hd_video_url": "https://www.youtube.com/embed/Vn523pwRhso",
          "thumbnail": "https://i.ytimg.com/vi/Vn523pwRhso/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 54 || अल्कोहल, फिनोल और ईथर-8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d99534de-d76d-4d9f-b17f-a1ed7a4972f7.pdf"
            }
          ]
        },
        {
          "serial": 57,
          "title": "व्याख्यान - 55 || एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 1",
          "published_date": "10 Jan 2025",
          "video_url": "https://www.youtube.com/embed/2Kyr15Bx0e8",
          "hd_video_url": "https://www.youtube.com/embed/2Kyr15Bx0e8",
          "thumbnail": "https://i.ytimg.com/vi/2Kyr15Bx0e8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 55 || एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e8b010cb-a444-41f9-b187-32e8aff43666.pdf"
            }
          ]
        },
        {
          "serial": 58,
          "title": "व्याख्यान - 56 || एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 2",
          "published_date": "11 Jan 2025",
          "video_url": "https://www.youtube.com/embed/CKnFuSaXTkQ",
          "hd_video_url": "https://www.youtube.com/embed/CKnFuSaXTkQ",
          "thumbnail": "https://i.ytimg.com/vi/CKnFuSaXTkQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 56 || एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8349ce62-68e7-4a9f-a33f-94842623aa4b.pdf"
            }
          ]
        },
        {
          "serial": 59,
          "title": "व्याख्यान - 57 || एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 3",
          "published_date": "13 Jan 2025",
          "video_url": "https://www.youtube.com/embed/dFO5ketXhiY",
          "hd_video_url": "https://www.youtube.com/embed/dFO5ketXhiY",
          "thumbnail": "https://i.ytimg.com/vi/dFO5ketXhiY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 57 || एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/07af85cc-d433-4115-9ab9-85205dc2c66f.pdf"
            }
          ]
        },
        {
          "serial": 60,
          "title": "व्याख्यान - 58 || Test Discussion",
          "published_date": "14 Jan 2025",
          "video_url": "https://www.youtube.com/embed/_J_vjFlIZ30",
          "hd_video_url": "https://www.youtube.com/embed/_J_vjFlIZ30",
          "thumbnail": "https://i.ytimg.com/vi/_J_vjFlIZ30/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान - 58  Test Discussion",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/135fb719-dee9-4ca8-8f77-8ade7a159724.pdf"
            }
          ]
        },
        {
          "serial": 61,
          "title": "व्याख्यान - 58 || एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 4",
          "published_date": "15 Jan 2025",
          "video_url": "https://www.youtube.com/embed/y6CMpyDkDzE",
          "hd_video_url": "https://www.youtube.com/embed/y6CMpyDkDzE",
          "thumbnail": "https://i.ytimg.com/vi/y6CMpyDkDzE/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान - 58  एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/82d2dace-4620-4208-8897-c01c2e006c08.pdf"
            }
          ]
        },
        {
          "serial": 62,
          "title": "व्याख्यान - 59 || एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 5",
          "published_date": "16 Jan 2025",
          "video_url": "https://www.youtube.com/embed/JcKAEUKP2NU",
          "hd_video_url": "https://www.youtube.com/embed/JcKAEUKP2NU",
          "thumbnail": "https://i.ytimg.com/vi/JcKAEUKP2NU/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान - 59  एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3cde0ada-e4e0-498c-86cb-8358b4e63535.pdf"
            }
          ]
        },
        {
          "serial": 63,
          "title": "व्याख्यान - 60 || एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 6",
          "published_date": "17 Jan 2025",
          "video_url": "https://www.youtube.com/embed/biP0AVTYpu0",
          "hd_video_url": "https://www.youtube.com/embed/biP0AVTYpu0",
          "thumbnail": "https://i.ytimg.com/vi/biP0AVTYpu0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 60 || एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2ac62138-91f2-4935-8247-27e03126e940.pdf"
            }
          ]
        },
        {
          "serial": 64,
          "title": "व्याख्यान - 61 || एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 7",
          "published_date": "20 Jan 2025",
          "video_url": "https://www.youtube.com/embed/nCcb3hKBmO8",
          "hd_video_url": "https://www.youtube.com/embed/nCcb3hKBmO8",
          "thumbnail": "https://i.ytimg.com/vi/nCcb3hKBmO8/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान - 61  एल्डिहाइड, केटोन्स और कार्बोक्जिलिक एसिड - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/15db28a0-a9c7-498b-8e7b-3fe98b9ee7c5.pdf"
            }
          ]
        },
        {
          "serial": 65,
          "title": "व्याख्यान - 62 || Unit Test Discussion",
          "published_date": "21 Jan 2025",
          "video_url": "https://www.youtube.com/embed/Rumnrj-J3DA",
          "hd_video_url": "https://www.youtube.com/embed/Rumnrj-J3DA",
          "thumbnail": "https://i.ytimg.com/vi/Rumnrj-J3DA/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान - 62  Unit Test Discussion",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/dcf12a1f-45d2-4385-90e4-18b840d23030.pdf"
            }
          ]
        },
        {
          "serial": 66,
          "title": "व्याख्यान - 63 || नाइट्रोजन युक्त कार्बनिक यौगिक - 1",
          "published_date": "22 Jan 2025",
          "video_url": "https://www.youtube.com/embed/2XhpjAYJVQg",
          "hd_video_url": "https://www.youtube.com/embed/2XhpjAYJVQg",
          "thumbnail": "https://i.ytimg.com/vi/2XhpjAYJVQg/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान - 63  नाइट्रोजन युक्त कार्बनिक यौगिक - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5da29875-ae26-4b0d-be6b-6282f1b66ecd.pdf"
            }
          ]
        },
        {
          "serial": 67,
          "title": "व्याख्यान - 64 || नाइट्रोजन युक्त कार्बनिक यौगिक - 2",
          "published_date": "23 Jan 2025",
          "video_url": "https://www.youtube.com/embed/9BdABU7i670",
          "hd_video_url": "https://www.youtube.com/embed/9BdABU7i670",
          "thumbnail": "https://i.ytimg.com/vi/9BdABU7i670/default.jpg",
          "notes": []
        },
        {
          "serial": 68,
          "title": "व्याख्यान - 65 || नाइट्रोजन युक्त कार्बनिक यौगिक - 3",
          "published_date": "24 Jan 2025",
          "video_url": "https://www.youtube.com/embed/JIs0qKQlRGo",
          "hd_video_url": "https://www.youtube.com/embed/JIs0qKQlRGo",
          "thumbnail": "https://i.ytimg.com/vi/JIs0qKQlRGo/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान - 65  नाइट्रोजन युक्त कार्बनिक यौगिक - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1b4fc717-71b8-4f21-b189-43a38decd3af.pdf"
            }
          ]
        },
        {
          "serial": 69,
          "title": "व्याख्यान - 66 || नाइट्रोजन युक्त कार्बनिक यौगिक - 4",
          "published_date": "25 Jan 2025",
          "video_url": "https://www.youtube.com/embed/tz7DYIKzA_s",
          "hd_video_url": "https://www.youtube.com/embed/tz7DYIKzA_s",
          "thumbnail": "https://i.ytimg.com/vi/tz7DYIKzA_s/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 66 || नाइट्रोजन युक्त कार्बनिक यौगिक - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c4cc0163-58e2-4ffa-bf8f-57e0029780f8.pdf"
            }
          ]
        },
        {
          "serial": 70,
          "title": "व्याख्यान - 67 || उपसहसंयोजन यौगिक - 1",
          "published_date": "27 Jan 2025",
          "video_url": "https://www.youtube.com/embed/shzyITlFFmg",
          "hd_video_url": "https://www.youtube.com/embed/shzyITlFFmg",
          "thumbnail": "https://i.ytimg.com/vi/shzyITlFFmg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 67 || उपसहसंयोजन यौगिक - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fb432914-13ea-4d97-bdca-17d5f66e4c6e.pdf"
            }
          ]
        },
        {
          "serial": 71,
          "title": "व्याख्यान - 68 || उपसहसंयोजन यौगिक - 2",
          "published_date": "28 Jan 2025",
          "video_url": "https://www.youtube.com/embed/6TxXl6c2uoA",
          "hd_video_url": "https://www.youtube.com/embed/6TxXl6c2uoA",
          "thumbnail": "https://i.ytimg.com/vi/6TxXl6c2uoA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 68 || उपसहसंयोजन यौगिक - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e5111d93-51f5-4bfc-9aa9-50b5ce920144.pdf"
            }
          ]
        },
        {
          "serial": 72,
          "title": "व्याख्यान - 69 || उपसहसंयोजन यौगिक - 3",
          "published_date": "29 Jan 2025",
          "video_url": "https://www.youtube.com/embed/uGLYiB9gMEw",
          "hd_video_url": "https://www.youtube.com/embed/uGLYiB9gMEw",
          "thumbnail": "https://i.ytimg.com/vi/uGLYiB9gMEw/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 69 || उपसहसंयोजन यौगिक - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b77703a5-45a2-4f62-82ae-a8d420324071.pdf"
            }
          ]
        },
        {
          "serial": 73,
          "title": "व्याख्यान - 70 || उपसहसंयोजन यौगिक - 4",
          "published_date": "30 Jan 2025",
          "video_url": "https://www.youtube.com/embed/xH1JhsCwqc4",
          "hd_video_url": "https://www.youtube.com/embed/xH1JhsCwqc4",
          "thumbnail": "https://i.ytimg.com/vi/xH1JhsCwqc4/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 70 || उपसहसंयोजन यौगिक - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9611bc9e-b945-46d6-bc7b-de1ab4901d53.pdf"
            }
          ]
        },
        {
          "serial": 74,
          "title": "व्याख्यान - 71 || उपसहसंयोजन यौगिक - 5",
          "published_date": "31 Jan 2025",
          "video_url": "https://www.youtube.com/embed/CtQGBw1bNkM",
          "hd_video_url": "https://www.youtube.com/embed/CtQGBw1bNkM",
          "thumbnail": "https://i.ytimg.com/vi/CtQGBw1bNkM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 71 || उपसहसंयोजन यौगिक - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1af9af25-a71e-438c-9b88-928cc5da28b8.pdf"
            }
          ]
        },
        {
          "serial": 75,
          "title": "व्याख्यान - 72 || उपसहसंयोजन यौगिक - 6",
          "published_date": "03 Feb 2025",
          "video_url": "https://www.youtube.com/embed/i9HxHrDl9us",
          "hd_video_url": "https://www.youtube.com/embed/i9HxHrDl9us",
          "thumbnail": "https://i.ytimg.com/vi/i9HxHrDl9us/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 72 || उपसहसंयोजन यौगिक - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8d7f7334-92ec-4f05-aaec-ad9758d803b4.pdf"
            }
          ]
        },
        {
          "serial": 76,
          "title": "व्याख्यान - 73 || उपसहसंयोजन यौगिक - 7",
          "published_date": "04 Feb 2025",
          "video_url": "https://www.youtube.com/embed/w311dxVI3EU",
          "hd_video_url": "https://www.youtube.com/embed/w311dxVI3EU",
          "thumbnail": "https://i.ytimg.com/vi/w311dxVI3EU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 73 || उपसहसंयोजन यौगिक - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9a1b156c-3a11-41fb-9e09-4985aa20ba31.pdf"
            }
          ]
        },
        {
          "serial": 77,
          "title": "व्याख्यान - 74 || उपसहसंयोजन यौगिक - 8",
          "published_date": "05 Feb 2025",
          "video_url": "https://www.youtube.com/embed/YimCChvqWiQ",
          "hd_video_url": "https://www.youtube.com/embed/YimCChvqWiQ",
          "thumbnail": "https://i.ytimg.com/vi/YimCChvqWiQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 74 || उपसहसंयोजन यौगिक - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7cc9435d-71e9-448a-93d3-dd68be6c92bb.pdf"
            }
          ]
        },
        {
          "serial": 78,
          "title": "व्याख्यान - 75 || उपसहसंयोजन यौगिक - 9",
          "published_date": "06 Feb 2025",
          "video_url": "https://www.youtube.com/embed/XPv80u7XPX0",
          "hd_video_url": "https://www.youtube.com/embed/XPv80u7XPX0",
          "thumbnail": "https://i.ytimg.com/vi/XPv80u7XPX0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 75 || उपसहसंयोजन यौगिक - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9bdf047a-e274-4dc2-9190-52caf09aa6b8.pdf"
            }
          ]
        },
        {
          "serial": 79,
          "title": "व्याख्यान - 76 || उपसहसंयोजन यौगिक - 10",
          "published_date": "07 Feb 2025",
          "video_url": "https://www.youtube.com/embed/KIbo34i1XP4",
          "hd_video_url": "https://www.youtube.com/embed/KIbo34i1XP4",
          "thumbnail": "https://i.ytimg.com/vi/KIbo34i1XP4/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 76 || उपसहसंयोजन यौगिक - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f130aa2a-0e8b-4d13-a788-5c2126cf7df9.pdf"
            }
          ]
        },
        {
          "serial": 80,
          "title": "व्याख्यान - 77 || P-ब्लॉक तत्व  - 1",
          "published_date": "08 Feb 2025",
          "video_url": "https://www.youtube.com/embed/LsS7xhNa0-Y",
          "hd_video_url": "https://www.youtube.com/embed/LsS7xhNa0-Y",
          "thumbnail": "https://i.ytimg.com/vi/LsS7xhNa0-Y/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 77 || P-ब्लॉक तत्व  - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2c2cd7d6-100e-4158-b36e-8f653ec41aa5.pdf"
            }
          ]
        },
        {
          "serial": 81,
          "title": "व्याख्यान - 78 || P-ब्लॉक तत्व - 2",
          "published_date": "10 Feb 2025",
          "video_url": "https://www.youtube.com/embed/zlOz8MHU_Ew",
          "hd_video_url": "https://www.youtube.com/embed/zlOz8MHU_Ew",
          "thumbnail": "https://i.ytimg.com/vi/zlOz8MHU_Ew/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 78 || P-ब्लॉक तत्व - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/00bf56bf-ed65-4b15-a7eb-23b27c3628d7.pdf"
            }
          ]
        },
        {
          "serial": 82,
          "title": "व्याख्यान - 79 || P-ब्लॉक तत्व - 3",
          "published_date": "11 Feb 2025",
          "video_url": "https://www.youtube.com/embed/ndNw_F_QXmk",
          "hd_video_url": "https://www.youtube.com/embed/ndNw_F_QXmk",
          "thumbnail": "https://i.ytimg.com/vi/ndNw_F_QXmk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 79 || P-ब्लॉक तत्व - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2b204d4f-cc06-4da4-afc8-c3f4cda8992d.pdf"
            }
          ]
        },
        {
          "serial": 83,
          "title": "व्याख्यान - 80 || Test Discussion",
          "published_date": "12 Feb 2025",
          "video_url": "https://www.youtube.com/embed/cBizmL9Xfwg",
          "hd_video_url": "https://www.youtube.com/embed/cBizmL9Xfwg",
          "thumbnail": "https://i.ytimg.com/vi/cBizmL9Xfwg/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान - 80 || Test Discussion",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0c7bec1c-0b40-4419-973f-abfbd651c279.pdf"
            }
          ]
        },
        {
          "serial": 84,
          "title": "व्याख्यान - 81 || P-ब्लॉक तत्व - 4",
          "published_date": "13 Feb 2025",
          "video_url": "https://www.youtube.com/embed/L107UyP1HfY",
          "hd_video_url": "https://www.youtube.com/embed/L107UyP1HfY",
          "thumbnail": "https://i.ytimg.com/vi/L107UyP1HfY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 81 || P-ब्लॉक तत्व - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/76d206f3-1f8d-4357-885d-863360d82129.pdf"
            }
          ]
        },
        {
          "serial": 85,
          "title": "व्याख्यान - 82 || P-ब्लॉक तत्व - 5",
          "published_date": "13 Feb 2025",
          "video_url": "https://www.youtube.com/embed/DqibzixDD8I",
          "hd_video_url": "https://www.youtube.com/embed/DqibzixDD8I",
          "thumbnail": "https://i.ytimg.com/vi/DqibzixDD8I/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 82 || P-ब्लॉक तत्व - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c43e8842-54bf-4725-895a-7ef6aa97b0f6.pdf"
            }
          ]
        },
        {
          "serial": 86,
          "title": "व्याख्यान - 83 || P-ब्लॉक तत्व - 6",
          "published_date": "17 Feb 2025",
          "video_url": "https://www.youtube.com/embed/wZRw7uOiQ3I",
          "hd_video_url": "https://www.youtube.com/embed/wZRw7uOiQ3I",
          "thumbnail": "https://i.ytimg.com/vi/wZRw7uOiQ3I/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 83 || P-ब्लॉक तत्व - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/772eb772-249a-4f13-a515-f1021563ccfa.pdf"
            }
          ]
        },
        {
          "serial": 87,
          "title": "व्याख्यान - 84 || P-ब्लॉक तत्व - 7",
          "published_date": "17 Feb 2025",
          "video_url": "https://www.youtube.com/embed/Ly9gx8pPUe8",
          "hd_video_url": "https://www.youtube.com/embed/Ly9gx8pPUe8",
          "thumbnail": "https://i.ytimg.com/vi/Ly9gx8pPUe8/default.jpg",
          "notes": [
            {
              "title": "Class notes - व्याख्यान - 84 || P-ब्लॉक तत्व - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ed6dc63f-e4f3-47e6-85a8-5fca9030fb6f.pdf"
            }
          ]
        },
        {
          "serial": 88,
          "title": "व्याख्यान - 85 || P-ब्लॉक तत्व - 8",
          "published_date": "18 Feb 2025",
          "video_url": "https://www.youtube.com/embed/jKnIT5rnTJs",
          "hd_video_url": "https://www.youtube.com/embed/jKnIT5rnTJs",
          "thumbnail": "https://i.ytimg.com/vi/jKnIT5rnTJs/default.jpg",
          "notes": [
            {
              "title": "Class notes - व्याख्यान - 85 || P-ब्लॉक तत्व - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ed6dc63f-e4f3-47e6-85a8-5fca9030fb6f.pdf"
            }
          ]
        },
        {
          "serial": 89,
          "title": "व्याख्यान - 86 || P-ब्लॉक तत्व - 9",
          "published_date": "19 Feb 2025",
          "video_url": "https://www.youtube.com/embed/xwr5ZJLd9yU",
          "hd_video_url": "https://www.youtube.com/embed/xwr5ZJLd9yU",
          "thumbnail": "https://i.ytimg.com/vi/xwr5ZJLd9yU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 86 || P-ब्लॉक तत्व - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/924af91f-b7ca-46c6-8e0d-06cf2b2590f5.pdf"
            }
          ]
        },
        {
          "serial": 90,
          "title": "व्याख्यान - 87 || जैव अणु (रसायन विज्ञान) - 1",
          "published_date": "20 Feb 2025",
          "video_url": "https://www.youtube.com/embed/UuBYOMBSWkM",
          "hd_video_url": "https://www.youtube.com/embed/UuBYOMBSWkM",
          "thumbnail": "https://i.ytimg.com/vi/UuBYOMBSWkM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 87 || जैव अणु (रसायन विज्ञान) - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/937f6995-6b31-41a0-9afa-737e7d21a958.pdf"
            }
          ]
        },
        {
          "serial": 91,
          "title": "व्याख्यान - 88 || जैव अणु (रसायन विज्ञान) - 2",
          "published_date": "20 Feb 2025",
          "video_url": "https://www.youtube.com/embed/xtsqwh4rEoc",
          "hd_video_url": "https://www.youtube.com/embed/xtsqwh4rEoc",
          "thumbnail": "https://i.ytimg.com/vi/xtsqwh4rEoc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 88 || जैव अणु (रसायन विज्ञान) - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/12291b01-ec2f-4bdb-8012-4db4f1135a91.pdf"
            }
          ]
        },
        {
          "serial": 92,
          "title": "व्याख्यान - 89 || जैव अणु (रसायन विज्ञान) - 3",
          "published_date": "21 Feb 2025",
          "video_url": "https://www.youtube.com/embed/H-gdF6kHlAY",
          "hd_video_url": "https://www.youtube.com/embed/H-gdF6kHlAY",
          "thumbnail": "https://i.ytimg.com/vi/H-gdF6kHlAY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 89 || जैव अणु (रसायन विज्ञान) - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9eb0a0f8-a7e6-4a42-974d-776dd6d30e05.pdf"
            }
          ]
        },
        {
          "serial": 93,
          "title": "व्याख्यान - 90 || जैव अणु (रसायन विज्ञान) - 4",
          "published_date": "22 Feb 2025",
          "video_url": "https://www.youtube.com/embed/iAVX8pEmVAc",
          "hd_video_url": "https://www.youtube.com/embed/iAVX8pEmVAc",
          "thumbnail": "https://i.ytimg.com/vi/iAVX8pEmVAc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 90 || जैव अणु (रसायन विज्ञान) - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/68373e80-c75e-4bb9-a5e6-1eed5f6f80a1.pdf"
            }
          ]
        },
        {
          "serial": 94,
          "title": "व्याख्यान - 91 || d & f - ब्लॉक तत्व -1",
          "published_date": "24 Feb 2025",
          "video_url": "https://www.youtube.com/embed/E3ZNJHkwTqo",
          "hd_video_url": "https://www.youtube.com/embed/E3ZNJHkwTqo",
          "thumbnail": "https://i.ytimg.com/vi/E3ZNJHkwTqo/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 91 || d & f - ब्लॉक तत्व -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/38226130-9519-4d9c-acb4-1c016a68d6b1.pdf"
            }
          ]
        },
        {
          "serial": 95,
          "title": "व्याख्यान - 92 || d & f - ब्लॉक तत्व -2",
          "published_date": "25 Feb 2025",
          "video_url": "https://www.youtube.com/embed/NQwB76sya2Q",
          "hd_video_url": "https://www.youtube.com/embed/NQwB76sya2Q",
          "thumbnail": "https://i.ytimg.com/vi/NQwB76sya2Q/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 92 || d & f - ब्लॉक तत्व -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fdf26fb9-ec93-49ec-8aa3-4847fc3e4045.pdf"
            }
          ]
        },
        {
          "serial": 96,
          "title": "व्याख्यान - 93 || d & f - ब्लॉक तत्व -3",
          "published_date": "25 Feb 2025",
          "video_url": "https://www.youtube.com/embed/GvcjMGCUTmI",
          "hd_video_url": "https://www.youtube.com/embed/GvcjMGCUTmI",
          "thumbnail": "https://i.ytimg.com/vi/GvcjMGCUTmI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 93 || d & f - ब्लॉक तत्व -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/05f3ae7f-1968-4909-9885-bcecb468763a.pdf"
            }
          ]
        },
        {
          "serial": 97,
          "title": "व्याख्यान - 94 || d & f - ब्लॉक तत्व -4",
          "published_date": "27 Feb 2025",
          "video_url": "https://www.youtube.com/embed/rp4vgRRKPQE",
          "hd_video_url": "https://www.youtube.com/embed/rp4vgRRKPQE",
          "thumbnail": "https://i.ytimg.com/vi/rp4vgRRKPQE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 94 || d & f - ब्लॉक तत्व -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fdfad763-8ddb-42c4-bf7b-3b005b4fdd8c.pdf"
            }
          ]
        },
        {
          "serial": 98,
          "title": "व्याख्यान - 95 || d & f - ब्लॉक तत्व -5",
          "published_date": "28 Feb 2025",
          "video_url": "https://www.youtube.com/embed/BuaI2loxX7o",
          "hd_video_url": "https://www.youtube.com/embed/BuaI2loxX7o",
          "thumbnail": "https://i.ytimg.com/vi/BuaI2loxX7o/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 95 || d & f - ब्लॉक तत्व -5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/86356044-319a-4da8-b49f-059dbdf8e06f.pdf"
            }
          ]
        },
        {
          "serial": 99,
          "title": "व्याख्यान - 96 || कार्बनिक यौगिकों का शुद्धिकरण, मात्रात्मक और गुणात्मक विश्लेषण - 1",
          "published_date": "28 Feb 2025",
          "video_url": "https://www.youtube.com/embed/2aC-40nMyG8",
          "hd_video_url": "https://www.youtube.com/embed/2aC-40nMyG8",
          "thumbnail": "https://i.ytimg.com/vi/2aC-40nMyG8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 96 || कार्बनिक यौगिकों का शुद्धिकरण, मात्रात्मक और गुणात्मक विश्लेषण - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1afa9b2a-043d-4387-b9af-69406f0da12b.pdf"
            }
          ]
        },
        {
          "serial": 100,
          "title": "व्याख्यान - 97 || प्रायोगिक रसायन  विज्ञान(लवण विश्लेषण ) - 1",
          "published_date": "01 Mar 2025",
          "video_url": "https://www.youtube.com/embed/ZFvl-XtmR-U",
          "hd_video_url": "https://www.youtube.com/embed/ZFvl-XtmR-U",
          "thumbnail": "https://i.ytimg.com/vi/ZFvl-XtmR-U/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 97 || प्रायोगिक रसायन  विज्ञान(लवण विश्लेषण ) - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/71488890-e4fd-4a93-bb69-9fb1e07ff778.pdf"
            }
          ]
        },
        {
          "serial": 101,
          "title": "व्याख्यान - 98 || आवर्त सारणी  - 1",
          "published_date": "03 Mar 2025",
          "video_url": "https://www.youtube.com/embed/KpSEO5E_8YI",
          "hd_video_url": "https://www.youtube.com/embed/KpSEO5E_8YI",
          "thumbnail": "https://i.ytimg.com/vi/KpSEO5E_8YI/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान - 98 || आवर्त सारणी  - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b675a735-91d3-484c-9cee-091fb32e561e.pdf"
            }
          ]
        },
        {
          "serial": 102,
          "title": "व्याख्यान - 99 || आवर्त सारणी - 2",
          "published_date": "03 Mar 2025",
          "video_url": "https://www.youtube.com/embed/AI9JUW3gsMo",
          "hd_video_url": "https://www.youtube.com/embed/AI9JUW3gsMo",
          "thumbnail": "https://i.ytimg.com/vi/AI9JUW3gsMo/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान - 99 || आवर्त सारणी - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8588a556-aca5-491d-8cc1-d50c7a0573d1.pdf"
            }
          ]
        },
        {
          "serial": 103,
          "title": "व्याख्यान - 100 || आवर्त सारणी - 3",
          "published_date": "05 Mar 2025",
          "video_url": "https://www.youtube.com/embed/9WMxu_Qmw2k",
          "hd_video_url": "https://www.youtube.com/embed/9WMxu_Qmw2k",
          "thumbnail": "https://i.ytimg.com/vi/9WMxu_Qmw2k/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 100 || आवर्त सारणी - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c7824980-ed79-4775-9c5b-557ebe019bff.pdf"
            }
          ]
        },
        {
          "serial": 104,
          "title": "व्याख्यान - 101 || आवर्त सारणी - 4",
          "published_date": "06 Mar 2025",
          "video_url": "https://www.youtube.com/embed/qXsXsr6P4lI",
          "hd_video_url": "https://www.youtube.com/embed/qXsXsr6P4lI",
          "thumbnail": "https://i.ytimg.com/vi/qXsXsr6P4lI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 101 || आवर्त सारणी - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/73e88c3f-1316-4fd0-b8fc-9be32046a013.pdf"
            }
          ]
        },
        {
          "serial": 105,
          "title": "व्याख्यान - 102 || आवर्त सारणी - 5",
          "published_date": "07 Mar 2025",
          "video_url": "https://www.youtube.com/embed/oxfegiVIb_k",
          "hd_video_url": "https://www.youtube.com/embed/oxfegiVIb_k",
          "thumbnail": "https://i.ytimg.com/vi/oxfegiVIb_k/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 102 || आवर्त सारणी - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/98f2fe8a-407c-4e37-abd3-8ba188a746af.pdf"
            }
          ]
        },
        {
          "serial": 106,
          "title": "व्याख्यान - 103 || आवर्त सारणी - 6",
          "published_date": "07 Mar 2025",
          "video_url": "https://www.youtube.com/embed/g3BN60CJ3lo",
          "hd_video_url": "https://www.youtube.com/embed/g3BN60CJ3lo",
          "thumbnail": "https://i.ytimg.com/vi/g3BN60CJ3lo/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 103 || आवर्त सारणी - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/35210c3d-13c5-4d50-9610-6eca4c15d954.pdf"
            }
          ]
        },
        {
          "serial": 107,
          "title": "व्याख्यान - 104 || आवर्त सारणी - 7",
          "published_date": "08 Mar 2025",
          "video_url": "https://www.youtube.com/embed/F1bUdtEt5B4",
          "hd_video_url": "https://www.youtube.com/embed/F1bUdtEt5B4",
          "thumbnail": "https://i.ytimg.com/vi/F1bUdtEt5B4/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 104 || आवर्त सारणी - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e1bbf293-9ac0-4f82-9709-c0905a558060.pdf"
            }
          ]
        },
        {
          "serial": 108,
          "title": "व्याख्यान - 105 || साम्यावस्था - 1",
          "published_date": "10 Mar 2025",
          "video_url": "https://www.youtube.com/embed/WbxlfOIlFWQ",
          "hd_video_url": "https://www.youtube.com/embed/WbxlfOIlFWQ",
          "thumbnail": "https://i.ytimg.com/vi/WbxlfOIlFWQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 105 || साम्यावस्था - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f9bcce93-09b6-4325-90fa-fd28096b7291.pdf"
            }
          ]
        },
        {
          "serial": 109,
          "title": "व्याख्यान - 106 || साम्यावस्था - 2",
          "published_date": "10 Mar 2025",
          "video_url": "https://www.youtube.com/embed/cyLk8zRgFX4",
          "hd_video_url": "https://www.youtube.com/embed/cyLk8zRgFX4",
          "thumbnail": "https://i.ytimg.com/vi/cyLk8zRgFX4/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 106 || साम्यावस्था - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f6a0efc7-c98d-401b-9fb2-718c6dfb8631.pdf"
            }
          ]
        },
        {
          "serial": 110,
          "title": "व्याख्यान - 107 || साम्यावस्था - 3",
          "published_date": "11 Mar 2025",
          "video_url": "https://www.youtube.com/embed/si_xD1PI66Q",
          "hd_video_url": "https://www.youtube.com/embed/si_xD1PI66Q",
          "thumbnail": "https://i.ytimg.com/vi/si_xD1PI66Q/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 107 || साम्यावस्था - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4ee6241d-7675-4986-98cd-961d1d2c284d.pdf"
            }
          ]
        },
        {
          "serial": 111,
          "title": "व्याख्यान - 108 || साम्यावस्था - 4",
          "published_date": "12 Mar 2025",
          "video_url": "https://www.youtube.com/embed/vfru7M7k6dk",
          "hd_video_url": "https://www.youtube.com/embed/vfru7M7k6dk",
          "thumbnail": "https://i.ytimg.com/vi/vfru7M7k6dk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 108 || साम्यावस्था - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fb9317a1-2f18-4644-a6bb-701b56455eba.pdf"
            }
          ]
        },
        {
          "serial": 112,
          "title": "व्याख्यान - 109 || ऊष्मागतिकी -1",
          "published_date": "18 Mar 2025",
          "video_url": "https://www.youtube.com/embed/Z8pXwTy60gU",
          "hd_video_url": "https://www.youtube.com/embed/Z8pXwTy60gU",
          "thumbnail": "https://i.ytimg.com/vi/Z8pXwTy60gU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 109 || ऊष्मागतिकी -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/39926eb8-e0ba-4ba6-816b-76b717297607.pdf"
            }
          ]
        },
        {
          "serial": 113,
          "title": "व्याख्यान - 110 || ऊष्मागतिकी -2",
          "published_date": "19 Mar 2025",
          "video_url": "https://www.youtube.com/embed/krV75gTd2FU",
          "hd_video_url": "https://www.youtube.com/embed/krV75gTd2FU",
          "thumbnail": "https://i.ytimg.com/vi/krV75gTd2FU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 110 || ऊष्मागतिकी -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0180092c-c7ab-4fc8-b363-67dce81d42aa.pdf"
            }
          ]
        },
        {
          "serial": 114,
          "title": "व्याख्यान - 111 || ऊष्मागतिकी -3",
          "published_date": "20 Mar 2025",
          "video_url": "https://www.youtube.com/embed/-_mYgzljHdo",
          "hd_video_url": "https://www.youtube.com/embed/-_mYgzljHdo",
          "thumbnail": "https://i.ytimg.com/vi/-_mYgzljHdo/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 111 || ऊष्मागतिकी -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/cfb23d13-6005-47e1-8570-704ae1831c77.pdf"
            }
          ]
        },
        {
          "serial": 115,
          "title": "व्याख्यान - 112 || ऊष्मागतिकी -4",
          "published_date": "22 Mar 2025",
          "video_url": "https://www.youtube.com/embed/oAs6Z4jkY5o",
          "hd_video_url": "https://www.youtube.com/embed/oAs6Z4jkY5o",
          "thumbnail": "https://i.ytimg.com/vi/oAs6Z4jkY5o/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 112 || ऊष्मागतिकी -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a46b71da-534f-4cfc-a68b-5ccb6ccc82bb.pdf"
            }
          ]
        },
        {
          "serial": 116,
          "title": "व्याख्यान - 113 ||  Revision -1",
          "published_date": "02 Apr 2025",
          "video_url": "https://www.youtube.com/embed/d4aqHfxtmE0",
          "hd_video_url": "https://www.youtube.com/embed/d4aqHfxtmE0",
          "thumbnail": "https://i.ytimg.com/vi/d4aqHfxtmE0/default.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान - 113 || Revision -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/daccf012-2740-496b-9ee6-b316ba906dc8.pdf"
            }
          ]
        },
        {
          "serial": 117,
          "title": "व्याख्यान - 114 || Revision -2",
          "published_date": "03 Apr 2025",
          "video_url": "https://www.youtube.com/embed/d9-TWpt4MqA",
          "hd_video_url": "https://www.youtube.com/embed/d9-TWpt4MqA",
          "thumbnail": "https://i.ytimg.com/vi/d9-TWpt4MqA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 114 || Revision -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ed57d97c-f815-42f1-88b2-3f76f5a2efa0.pdf"
            }
          ]
        },
        {
          "serial": 118,
          "title": "व्याख्यान - 115 || Revision -3",
          "published_date": "04 Apr 2025",
          "video_url": "https://www.youtube.com/embed/73rUAhLn3kE",
          "hd_video_url": "https://www.youtube.com/embed/73rUAhLn3kE",
          "thumbnail": "https://i.ytimg.com/vi/73rUAhLn3kE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान - 115 || Revision -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/74dbef7c-b6e3-4583-bc2a-b018f68e26ef.pdf"
            }
          ]
        }
      ],
      "notes": []
    },
    {
      "subject_name": "Chemistry By Shekhar Sati (SS Sir)",
      "subject_id": 3422,
      "video_count": 81,
      "note_count": 81,
      "videos": [
        {
          "serial": 1,
          "title": "व्याख्यान- 01 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 1",
          "published_date": "09 Sep 2024",
          "video_url": "https://www.youtube.com/embed/rs_aXUPQbGk",
          "hd_video_url": "https://www.youtube.com/embed/rs_aXUPQbGk",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 01 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/92276194-90ff-4814-af51-63862fc8aaf9.pdf"
            }
          ]
        },
        {
          "serial": 2,
          "title": "व्याख्यान- 02 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 2",
          "published_date": "10 Sep 2024",
          "video_url": "https://www.youtube.com/embed/xTHQs_yIFec",
          "hd_video_url": "https://www.youtube.com/embed/xTHQs_yIFec",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/C6l8AGhwHpmoVIlEoKigjTKtuWI4vCdmZXCBZF3J.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 02 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/21736faa-7854-4cbc-81d3-bfd04e778c45.pdf"
            }
          ]
        },
        {
          "serial": 3,
          "title": "व्याख्यान- 03 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 3",
          "published_date": "11 Sep 2024",
          "video_url": "https://www.youtube.com/embed/XXY1u3DVPdA",
          "hd_video_url": "https://www.youtube.com/embed/XXY1u3DVPdA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/9Ew2OulgkiT1wlaTw81vPfr91dWGAkurvjQOZjyA.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 03 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5536628f-1807-4f1d-8139-448f1625e1b6.pdf"
            }
          ]
        },
        {
          "serial": 4,
          "title": "व्याख्यान- 04 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 4",
          "published_date": "12 Sep 2024",
          "video_url": "https://www.youtube.com/embed/otSzTcX6Hxw",
          "hd_video_url": "https://www.youtube.com/embed/otSzTcX6Hxw",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/aDv7ukz4CdhqmeiQY84rzIM0c5F3P4T0vCrBOrgO.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 04 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/75de063d-f127-4532-9147-eddc8b9d3788.pdf"
            }
          ]
        },
        {
          "serial": 5,
          "title": "व्याख्यान- 05 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 5",
          "published_date": "13 Sep 2024",
          "video_url": "https://www.youtube.com/embed/XXpV0QROBdM",
          "hd_video_url": "https://www.youtube.com/embed/XXpV0QROBdM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/VQmwgbUiFC8tXHmMYBo4GAEicW3P3CbDJodfKVIM.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 05 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/67cee3e7-2a54-4e51-ae46-332dc91d86b6.pdf"
            }
          ]
        },
        {
          "serial": 6,
          "title": "व्याख्यान- 06 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 6",
          "published_date": "14 Sep 2024",
          "video_url": "https://www.youtube.com/embed/G09vYhrja4I",
          "hd_video_url": "https://www.youtube.com/embed/G09vYhrja4I",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/iGvtYnwhgxnRLf705C4Nlv39jhsjc5wvfPOxh5uu.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 06 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/179b251a-48a4-4f38-8c16-307f00f5478b.pdf"
            }
          ]
        },
        {
          "serial": 7,
          "title": "व्याख्यान- 07 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 7",
          "published_date": "16 Sep 2024",
          "video_url": "https://www.youtube.com/embed/i-DAybWVAZk",
          "hd_video_url": "https://www.youtube.com/embed/i-DAybWVAZk",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/xKEqYY4X1MVF3vV07LZ0H4lDsR5GCVfpj94pXU02.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 07 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1afc675d-6481-42bb-b3d9-3572a74bf4be.pdf"
            }
          ]
        },
        {
          "serial": 8,
          "title": "व्याख्यान- 08 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 8",
          "published_date": "17 Sep 2024",
          "video_url": "https://www.youtube.com/embed/C_WZMYEAPn4",
          "hd_video_url": "https://www.youtube.com/embed/C_WZMYEAPn4",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/LXuVnkQJhlP7GqOwEtebW3axPeTUqSVYbFCaNfaT.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 08 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/856db4ef-133a-4d5a-9a53-9d864582419c.pdf"
            }
          ]
        },
        {
          "serial": 9,
          "title": "व्याख्यान- 09 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 9",
          "published_date": "18 Sep 2024",
          "video_url": "https://www.youtube.com/embed/Qc_0pXSD6_E",
          "hd_video_url": "https://www.youtube.com/embed/Qc_0pXSD6_E",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/fS9xqvvnkGhvJoJr40TZWL9l5120fFt614icno4e.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 09 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3be55540-0aac-4f5a-9cd8-2bfba57f4715.pdf"
            }
          ]
        },
        {
          "serial": 10,
          "title": "व्याख्यान- 10 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 10",
          "published_date": "19 Sep 2024",
          "video_url": "https://www.youtube.com/embed/vymBAgjYZ6k",
          "hd_video_url": "https://www.youtube.com/embed/vymBAgjYZ6k",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/z8YHV6qgrp0P3A4Legg364m9cvhqDxqmTLplmfAQ.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 10 || रसायन विज्ञान की कुछ बुनियादी अवधारणाएँ - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8aca138b-cea7-415e-92fe-95e316f978ec.pdf"
            }
          ]
        },
        {
          "serial": 11,
          "title": "व्याख्यान- 11 || विलयन - 1",
          "published_date": "20 Sep 2024",
          "video_url": "https://www.youtube.com/embed/DszlNURTGKw",
          "hd_video_url": "https://www.youtube.com/embed/DszlNURTGKw",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/F17kYoMRwIga212Ks7ZL7NjnNAawScbOd1HZzBhN.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 11 || विलयन - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3003f48c-3179-4f51-8665-169263cede58.pdf"
            }
          ]
        },
        {
          "serial": 12,
          "title": "व्याख्यान- 12 || विलयन - 2",
          "published_date": "21 Sep 2024",
          "video_url": "https://www.youtube.com/embed/gnFIj83xkY4",
          "hd_video_url": "https://www.youtube.com/embed/gnFIj83xkY4",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/S3wl6rn9IHfSwLmEdG9d7hHV9vAxHftJNLpvZAMv.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 12 || विलयन - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9faf02bf-c629-421d-af8e-c17707683231.pdf"
            }
          ]
        },
        {
          "serial": 13,
          "title": "व्याख्यान- 13 || विलयन - 3",
          "published_date": "23 Sep 2024",
          "video_url": "https://www.youtube.com/embed/4NMLhIm6Rsw",
          "hd_video_url": "https://www.youtube.com/embed/4NMLhIm6Rsw",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/fJYkGK3VOjoAqxMmHCuaQqcv0i5cDqsM5ZCpWHsY.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 13 || विलयन - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5f488a4c-acdb-4bdd-8b57-f515bcb9bd40.pdf"
            }
          ]
        },
        {
          "serial": 14,
          "title": "व्याख्यान- 14 || विलयन - 4",
          "published_date": "24 Sep 2024",
          "video_url": "https://www.youtube.com/embed/Jl7JBDsgMEc",
          "hd_video_url": "https://www.youtube.com/embed/Jl7JBDsgMEc",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/E15TKOmAaglL7RgG6fkLdcwTdQodKZS1tXFRdVLp.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 14 || विलयन - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a0ed4457-d2aa-4bcb-88fd-7021c884049f.pdf"
            }
          ]
        },
        {
          "serial": 15,
          "title": "व्याख्यान- 15 || विलयन - 5",
          "published_date": "25 Sep 2024",
          "video_url": "https://www.youtube.com/embed/YkNF1gQQwys",
          "hd_video_url": "https://www.youtube.com/embed/YkNF1gQQwys",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/lLsLpmw0ra3E8qKr3D1b7lhQPUtwufinCkyYzFIA.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 15 || विलयन - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f8f3d388-cb43-471d-93b8-975420460e68.pdf"
            }
          ]
        },
        {
          "serial": 16,
          "title": "व्याख्यान- 16 || विलयन - 6",
          "published_date": "26 Sep 2024",
          "video_url": "https://www.youtube.com/embed/-12m8hFQkoo",
          "hd_video_url": "https://www.youtube.com/embed/-12m8hFQkoo",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/1vmcjE6m6zCvysC7Pjn37Ym4CQcyk4vjlOEBTr34.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 16 || विलयन - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8d1eccaa-155d-4587-b32d-0b9a4cc3b7d8.pdf"
            }
          ]
        },
        {
          "serial": 17,
          "title": "व्याख्यान- 17 || विलयन - 7",
          "published_date": "27 Sep 2024",
          "video_url": "https://www.youtube.com/embed/pLjsEEv6zVg",
          "hd_video_url": "https://www.youtube.com/embed/pLjsEEv6zVg",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/0YPMKZ50BLjyLAZqo3eI5iTaceO5eJ0pZFEuGpII.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 17 || विलयन - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3ae56b70-7a67-48ad-a0a2-afad17b43f91.pdf"
            }
          ]
        },
        {
          "serial": 18,
          "title": "व्याख्यान- 18 || विलयन - 8",
          "published_date": "28 Sep 2024",
          "video_url": "https://www.youtube.com/embed/rb2G9FkZ8VA",
          "hd_video_url": "https://www.youtube.com/embed/rb2G9FkZ8VA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/qpactlnpRI4T9XDEEEOSYmrMdDUcdGiMuiEh2YUd.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 18 || विलयन - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/78609086-a6bf-49e7-bcd7-25f38aef186d.pdf"
            }
          ]
        },
        {
          "serial": 19,
          "title": "व्याख्यान- 19 || परमाणु संरचना -1",
          "published_date": "03 Oct 2024",
          "video_url": "https://www.youtube.com/embed/KXcBAjG81u0",
          "hd_video_url": "https://www.youtube.com/embed/KXcBAjG81u0",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/sRHhPy1cuP8BP3KeW8FCpGSs0OyEvdqYd9g8rlFl.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 19 || परमाणु संरचना -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3280bf47-0a4f-4e38-8613-e9e6fca36ae1.pdf"
            }
          ]
        },
        {
          "serial": 20,
          "title": "व्याख्यान- 20 || परमाणु संरचना -2",
          "published_date": "04 Oct 2024",
          "video_url": "https://www.youtube.com/embed/WY0-CYZyKLI",
          "hd_video_url": "https://www.youtube.com/embed/WY0-CYZyKLI",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/EQ29Sr0AyIAjneNkz9MnWoGPlvH8lh8FHlUfb69L.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 20 || परमाणु संरचना -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b30220a9-8ccf-4259-918c-58745634832b.pdf"
            }
          ]
        },
        {
          "serial": 21,
          "title": "व्याख्यान- 21 || परमाणु संरचना -3",
          "published_date": "05 Oct 2024",
          "video_url": "https://www.youtube.com/embed/VPlrUb65S4g",
          "hd_video_url": "https://www.youtube.com/embed/VPlrUb65S4g",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/I1U2MbqkDarEOxPUs3CiJh8JlK8CCi7xUYXNpBMJ.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 21 || परमाणु संरचना -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/febb6694-6840-4ddd-96c7-3f78898e494b.pdf"
            }
          ]
        },
        {
          "serial": 22,
          "title": "व्याख्यान- 22 || परमाणु संरचना - 4",
          "published_date": "07 Oct 2024",
          "video_url": "https://www.youtube.com/embed/VUafF1IaGJU",
          "hd_video_url": "https://www.youtube.com/embed/VUafF1IaGJU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/b6goKUUREcPocOl1KWR3wKVHtCdj8CijeyRBXnAC.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 22 || परमाणु संरचना - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/54c1ae97-9d57-4fec-b1e2-42f85189cac4.pdf"
            }
          ]
        },
        {
          "serial": 23,
          "title": "व्याख्यान- 23 || परमाणु संरचना - 5",
          "published_date": "10 Oct 2024",
          "video_url": "https://www.youtube.com/embed/zzueL2SE5cY",
          "hd_video_url": "https://www.youtube.com/embed/zzueL2SE5cY",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/HQog58vMnIi5KSilmCQxJdu6jdLTOMCCUsTIfdvC.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 23 || परमाणु संरचना - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a528ce3e-ab64-4cf0-89f6-46810dfff62f.pdf"
            }
          ]
        },
        {
          "serial": 24,
          "title": "व्याख्यान- 24 || परमाणु संरचना - 6",
          "published_date": "11 Oct 2024",
          "video_url": "https://www.youtube.com/embed/U5HR6villxk",
          "hd_video_url": "https://www.youtube.com/embed/U5HR6villxk",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/m1qenfjqg1MuRrFc4adrlhz3O1szf7z5gEP2pDse.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 24 || परमाणु संरचना - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/77bdb355-def0-4f1b-a57d-6c87b4450cc2.pdf"
            }
          ]
        },
        {
          "serial": 25,
          "title": "व्याख्यान- 25 || परमाणु संरचना - 7",
          "published_date": "14 Oct 2024",
          "video_url": "https://www.youtube.com/embed/qVoffI-RTiM",
          "hd_video_url": "https://www.youtube.com/embed/qVoffI-RTiM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/5DSUXOQwZVs8tmSSX2PCbEeRpscSstDLZhqgXqbL.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 25 || परमाणु संरचना - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3295fcba-06d6-4675-b4f4-0a7b335bc4be.pdf"
            }
          ]
        },
        {
          "serial": 26,
          "title": "व्याख्यान- 26 || परमाणु संरचना - 8",
          "published_date": "15 Oct 2024",
          "video_url": "https://www.youtube.com/embed/KiwgpXgxeGY",
          "hd_video_url": "https://www.youtube.com/embed/KiwgpXgxeGY",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/txiHVO91t19l9p4eGHD7QD5Cki83vmT7pWzQzJsp.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 26 || परमाणु संरचना - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0d4ccdb2-e2e5-48cb-ad1e-a9b0ff5a9fa4.pdf"
            }
          ]
        },
        {
          "serial": 27,
          "title": "व्याख्यान- 27 || परमाणु संरचना - 9",
          "published_date": "16 Oct 2024",
          "video_url": "https://www.youtube.com/embed/bpRTa2uxghs",
          "hd_video_url": "https://www.youtube.com/embed/bpRTa2uxghs",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/7kabdgvUhsfv4PTAxC2Bxgf16zNjOKb6owHhIU8A.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 27  परमाणु संरचना - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/268b74b3-ef48-44c6-b70c-8518809cc97b.pdf"
            }
          ]
        },
        {
          "serial": 28,
          "title": "व्याख्यान- 28 || परमाणु संरचना - 10",
          "published_date": "17 Oct 2024",
          "video_url": "https://www.youtube.com/embed/YVSsvGOle94",
          "hd_video_url": "https://www.youtube.com/embed/YVSsvGOle94",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/nTcWDS2Jo5t8sXsyo658KmaTpa3qqQd1hsgFaMiO.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 28 || परमाणु संरचना - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/bcc7d156-efed-4aa9-a492-a9dbafa91b3f.pdf"
            }
          ]
        },
        {
          "serial": 29,
          "title": "व्याख्यान- 29 || परमाणु संरचना - 11",
          "published_date": "21 Oct 2024",
          "video_url": "https://www.youtube.com/embed/-n0wm7GXhq0",
          "hd_video_url": "https://www.youtube.com/embed/-n0wm7GXhq0",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/SxjXnIdJPb36BGDNRPwB8ezzYaQJiQgFbM40209N.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 29 || परमाणु संरचना - 11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/eeef5f84-a414-4d99-b00c-9e7e4a919e5f.pdf"
            }
          ]
        },
        {
          "serial": 30,
          "title": "व्याख्यान- 30 || परमाणु संरचना - 12",
          "published_date": "23 Oct 2024",
          "video_url": "https://www.youtube.com/embed/h2DZur3Fv6M",
          "hd_video_url": "https://www.youtube.com/embed/h2DZur3Fv6M",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/PoDji1nSQwUh5C5iuGSNzglfGWbSeG00dih8QnIB.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 30 || परमाणु संरचना - 12",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/02e52952-0454-43ca-9c34-9f0316591c3e.pdf"
            }
          ]
        },
        {
          "serial": 31,
          "title": "व्याख्यान- 31 || परमाणु संरचना - 13",
          "published_date": "28 Oct 2024",
          "video_url": "https://www.youtube.com/embed/1Zf8Cnni-zY",
          "hd_video_url": "https://www.youtube.com/embed/1Zf8Cnni-zY",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/SxI468R051LkpqvmtwhjT2gqQM0iKd7NA1k11lam.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 31 || परमाणु संरचना - 13",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2998bcd7-e629-437c-91d0-73cb402f273b.pdf"
            }
          ]
        },
        {
          "serial": 32,
          "title": "व्याख्यान- 32 || परमाणु संरचना - 14",
          "published_date": "06 Nov 2024",
          "video_url": "https://www.youtube.com/embed/JsGEXL45N1s",
          "hd_video_url": "https://www.youtube.com/embed/JsGEXL45N1s",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/UT8qYIONdeKBUQQUpPunPHTjY9i2FmiFQdf2qiV6.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 32 || परमाणु संरचना - 14",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/cf0e2e72-638d-4efc-abd0-dc03f84b8e1c.pdf"
            }
          ]
        },
        {
          "serial": 33,
          "title": "व्याख्यान- 33 || परमाणु संरचना - 15",
          "published_date": "08 Nov 2024",
          "video_url": "https://www.youtube.com/embed/NIgIicw1pdk",
          "hd_video_url": "https://www.youtube.com/embed/NIgIicw1pdk",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/J5brf9h1j4BSJxcy9Msru7ICYNwU5zgc0wp4Vhm6.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 33 || परमाणु संरचना - 15",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5f55ef68-4d2b-4462-a327-28fdf1373a59.pdf"
            }
          ]
        },
        {
          "serial": 34,
          "title": "व्याख्यान- 34 || परमाणु संरचना - 16",
          "published_date": "09 Nov 2024",
          "video_url": "https://www.youtube.com/embed/ooAig3erDKI",
          "hd_video_url": "https://www.youtube.com/embed/ooAig3erDKI",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/MnpplzMJjQl71MobfoGXYw4z3W3ax7thDpmRYvXH.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 34 || परमाणु संरचना - 16",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7c33a18f-5165-4114-be56-977089d8366e.pdf"
            }
          ]
        },
        {
          "serial": 35,
          "title": "व्याख्यान- 35 || रासायनिक बंधन तथा आण्विक संरचना - 1",
          "published_date": "11 Nov 2024",
          "video_url": "https://www.youtube.com/embed/HM_Beb-i37o",
          "hd_video_url": "https://www.youtube.com/embed/HM_Beb-i37o",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/sKnMnZsejYphgowwZwPgiyAFAGyJePdwBVq2auuP.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 35 || रासायनिक बंधन तथा आण्विक संरचना - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b475102f-bab1-4b9c-a414-06a9fe3d68bd.pdf"
            }
          ]
        },
        {
          "serial": 36,
          "title": "व्याख्यान- 36 || रासायनिक बंधन तथा आण्विक संरचना - 2",
          "published_date": "13 Nov 2024",
          "video_url": "https://www.youtube.com/embed/JsuAN-58iXU",
          "hd_video_url": "https://www.youtube.com/embed/JsuAN-58iXU",
          "thumbnail": "https://i.ytimg.com/vi/JsuAN-58iXU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 36 || रासायनिक बंधन तथा आण्विक संरचना - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1f65ad0a-8818-49e7-b73c-10d04a464a09.pdf"
            }
          ]
        },
        {
          "serial": 37,
          "title": "व्याख्यान- 37 || रासायनिक बंधन तथा आण्विक संरचना - 3",
          "published_date": "15 Nov 2024",
          "video_url": "https://www.youtube.com/embed/aa_0zoeEw_A",
          "hd_video_url": "https://www.youtube.com/embed/aa_0zoeEw_A",
          "thumbnail": "https://i.ytimg.com/vi/aa_0zoeEw_A/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 37 || रासायनिक बंधन तथा आण्विक संरचना - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7b5bd515-fbef-410e-8c3d-73ce53d5efa1.pdf"
            }
          ]
        },
        {
          "serial": 38,
          "title": "व्याख्यान- 38 || रासायनिक बंधन तथा आण्विक संरचना - 4",
          "published_date": "18 Nov 2024",
          "video_url": "https://www.youtube.com/embed/Clf78hqYazk",
          "hd_video_url": "https://www.youtube.com/embed/Clf78hqYazk",
          "thumbnail": "https://i.ytimg.com/vi/Clf78hqYazk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 38 || रासायनिक बंधन तथा आण्विक संरचना - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/61bb205a-6ca6-4d37-831b-58a54af39784.pdf"
            }
          ]
        },
        {
          "serial": 39,
          "title": "व्याख्यान- 39 || रासायनिक बंधन तथा आण्विक संरचना - 5",
          "published_date": "20 Nov 2024",
          "video_url": "https://www.youtube.com/embed/uSEtCZp5Vxs",
          "hd_video_url": "https://www.youtube.com/embed/uSEtCZp5Vxs",
          "thumbnail": "https://i.ytimg.com/vi/uSEtCZp5Vxs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 39 || रासायनिक बंधन तथा आण्विक संरचना - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f5d820fd-91fe-4dd7-b3c4-e6ac369d4bf7.pdf"
            }
          ]
        },
        {
          "serial": 40,
          "title": "व्याख्यान- 40 || रासायनिक बंधन तथा आण्विक संरचना - 6",
          "published_date": "22 Nov 2024",
          "video_url": "https://www.youtube.com/embed/-kCMNmhCUB4",
          "hd_video_url": "https://www.youtube.com/embed/-kCMNmhCUB4",
          "thumbnail": "https://i.ytimg.com/vi/-kCMNmhCUB4/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 40 || रासायनिक बंधन तथा आण्विक संरचना - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/facd8966-48c7-42e9-a383-e7cecf2fe591.pdf"
            }
          ]
        },
        {
          "serial": 41,
          "title": "व्याख्यान- 41 || रासायनिक बंधन तथा आण्विक संरचना - 7",
          "published_date": "27 Nov 2024",
          "video_url": "https://www.youtube.com/embed/yXgNrWW1vFI",
          "hd_video_url": "https://www.youtube.com/embed/yXgNrWW1vFI",
          "thumbnail": "https://i.ytimg.com/vi/yXgNrWW1vFI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 41 || रासायनिक बंधन तथा आण्विक संरचना - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ea728a9d-7993-459a-a453-393cd28d12e9.pdf"
            }
          ]
        },
        {
          "serial": 42,
          "title": "व्याख्यान- 42 || रासायनिक बंधन तथा आण्विक संरचना - 8",
          "published_date": "02 Dec 2024",
          "video_url": "https://www.youtube.com/embed/vehnry-E59M",
          "hd_video_url": "https://www.youtube.com/embed/vehnry-E59M",
          "thumbnail": "https://i.ytimg.com/vi/vehnry-E59M/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 42 || रासायनिक बंधन तथा आण्विक संरचना - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/aaf0bf35-eb05-410b-9425-ff083efe5450.pdf"
            }
          ]
        },
        {
          "serial": 43,
          "title": "व्याख्यान- 43 || रासायनिक बंधन तथा आण्विक संरचना - 9",
          "published_date": "04 Dec 2024",
          "video_url": "https://www.youtube.com/embed/W_4KjkztGJ0",
          "hd_video_url": "https://www.youtube.com/embed/W_4KjkztGJ0",
          "thumbnail": "https://i.ytimg.com/vi/W_4KjkztGJ0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 43 || रासायनिक बंधन तथा आण्विक संरचना - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/97c4d4eb-51ad-4463-a7bc-c6cd7c87ed76.pdf"
            }
          ]
        },
        {
          "serial": 44,
          "title": "व्याख्यान- 44 || रासायनिक बंधन तथा आण्विक संरचना - 10",
          "published_date": "05 Dec 2024",
          "video_url": "https://www.youtube.com/embed/cFY98WFd31o",
          "hd_video_url": "https://www.youtube.com/embed/cFY98WFd31o",
          "thumbnail": "https://i.ytimg.com/vi/cFY98WFd31o/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 44 || रासायनिक बंधन तथा आण्विक संरचना - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fe72b305-a05a-4d18-8a21-72817ba98fdb.pdf"
            }
          ]
        },
        {
          "serial": 45,
          "title": "व्याख्यान- 45 || रासायनिक बंधन तथा आण्विक संरचना - 11",
          "published_date": "10 Dec 2024",
          "video_url": "https://www.youtube.com/embed/8KgfpBk_yFA",
          "hd_video_url": "https://www.youtube.com/embed/8KgfpBk_yFA",
          "thumbnail": "https://i.ytimg.com/vi/8KgfpBk_yFA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 45 || रासायनिक बंधन तथा आण्विक संरचना - 11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/faaf4eef-b7e3-4367-88a0-a943efda7de0.pdf"
            }
          ]
        },
        {
          "serial": 46,
          "title": "व्याख्यान- 46 || रासायनिक बंधन तथा आण्विक संरचना - 12",
          "published_date": "11 Dec 2024",
          "video_url": "https://www.youtube.com/embed/CKE7flJX6gE",
          "hd_video_url": "https://www.youtube.com/embed/CKE7flJX6gE",
          "thumbnail": "https://i.ytimg.com/vi/CKE7flJX6gE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 46 || रासायनिक बंधन तथा आण्विक संरचना - 12",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/cd6ae8ff-36fa-48c1-9ee6-ef4294df5955.pdf"
            }
          ]
        },
        {
          "serial": 47,
          "title": "व्याख्यान- 47 || रासायनिक बंधन तथा आण्विक संरचना - 13",
          "published_date": "13 Dec 2024",
          "video_url": "https://www.youtube.com/embed/SOZuISJXUEA",
          "hd_video_url": "https://www.youtube.com/embed/SOZuISJXUEA",
          "thumbnail": "https://i.ytimg.com/vi/SOZuISJXUEA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 47 || रासायनिक बंधन तथा आण्विक संरचना - 13",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c0e2e5cd-f61f-4145-a8ab-55f42b0f1538.pdf"
            }
          ]
        },
        {
          "serial": 48,
          "title": "व्याख्यान- 48 || रासायनिक बंधन तथा आण्विक संरचना - 14",
          "published_date": "16 Dec 2024",
          "video_url": "https://www.youtube.com/embed/jZV3gm98wTU",
          "hd_video_url": "https://www.youtube.com/embed/jZV3gm98wTU",
          "thumbnail": "https://i.ytimg.com/vi/jZV3gm98wTU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 48 || रासायनिक बंधन तथा आण्विक संरचना - 14",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/34248d76-6d72-492e-8026-a3fb5c4f8ac1.pdf"
            }
          ]
        },
        {
          "serial": 49,
          "title": "व्याख्यान- 49 ||  रासायनिक बंधन तथा आण्विक संरचना - 15",
          "published_date": "18 Dec 2024",
          "video_url": "https://www.youtube.com/embed/IgsujuF2K5I",
          "hd_video_url": "https://www.youtube.com/embed/IgsujuF2K5I",
          "thumbnail": "https://i.ytimg.com/vi/IgsujuF2K5I/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 49 ||  रासायनिक बंधन तथा आण्विक संरचना - 15",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e24aa253-7540-4c99-9424-7af465ba1ff3.pdf"
            }
          ]
        },
        {
          "serial": 50,
          "title": "व्याख्यान- 50 || रेडॉक्स अभिक्रिया - 1",
          "published_date": "20 Dec 2024",
          "video_url": "https://www.youtube.com/embed/mHn61pkUvQg",
          "hd_video_url": "https://www.youtube.com/embed/mHn61pkUvQg",
          "thumbnail": "https://i.ytimg.com/vi/mHn61pkUvQg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 50 || रेडॉक्स अभिक्रिया - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/306eda7a-786a-4165-aaa2-0312395e74f2.pdf"
            }
          ]
        },
        {
          "serial": 51,
          "title": "व्याख्यान- 51 || रेडॉक्स अभिक्रिया - 2",
          "published_date": "23 Dec 2024",
          "video_url": "https://www.youtube.com/embed/JuJv5UmAu_I",
          "hd_video_url": "https://www.youtube.com/embed/JuJv5UmAu_I",
          "thumbnail": "https://i.ytimg.com/vi/JuJv5UmAu_I/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 51 || रेडॉक्स अभिक्रिया - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/af65d561-6b00-47c2-a80f-98559fc878c5.pdf"
            }
          ]
        },
        {
          "serial": 52,
          "title": "व्याख्यान- 52 || रेडॉक्स अभिक्रिया - 3",
          "published_date": "25 Dec 2024",
          "video_url": "https://www.youtube.com/embed/aOQv4tuhmA8",
          "hd_video_url": "https://www.youtube.com/embed/aOQv4tuhmA8",
          "thumbnail": "https://i.ytimg.com/vi/aOQv4tuhmA8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 52 || रेडॉक्स अभिक्रिया - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a74fcc69-cd70-41a5-888d-4d564ad3b228.pdf"
            }
          ]
        },
        {
          "serial": 53,
          "title": "व्याख्यान- 53 || रेडॉक्स अभिक्रिया - 4",
          "published_date": "27 Dec 2024",
          "video_url": "https://www.youtube.com/embed/omf8JDxjnWw",
          "hd_video_url": "https://www.youtube.com/embed/omf8JDxjnWw",
          "thumbnail": "https://i.ytimg.com/vi/omf8JDxjnWw/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 53 || रेडॉक्स अभिक्रिया - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c0489325-93aa-4cbe-afa5-0f7d0909c644.pdf"
            }
          ]
        },
        {
          "serial": 54,
          "title": "व्याख्यान- 54 || रेडॉक्स अभिक्रिया - 5",
          "published_date": "30 Dec 2024",
          "video_url": "https://www.youtube.com/embed/u3cBEEGQ45w",
          "hd_video_url": "https://www.youtube.com/embed/u3cBEEGQ45w",
          "thumbnail": "https://i.ytimg.com/vi/u3cBEEGQ45w/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 54 || रेडॉक्स अभिक्रिया - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e0f6142d-0b7f-4e4d-9b20-29959f16baf1.pdf"
            }
          ]
        },
        {
          "serial": 55,
          "title": "व्याख्यान- 55|| रेडॉक्स अभिक्रिया - 6",
          "published_date": "03 Jan 2025",
          "video_url": "https://www.youtube.com/embed/usuwuhQdPqw",
          "hd_video_url": "https://www.youtube.com/embed/usuwuhQdPqw",
          "thumbnail": "https://i.ytimg.com/vi/usuwuhQdPqw/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 55|| रेडॉक्स अभिक्रिया - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d85a9db7-ccdd-478a-86bb-7f363f16f152.pdf"
            }
          ]
        },
        {
          "serial": 56,
          "title": "व्याख्यान- 56 || रेडॉक्स अभिक्रिया - 7",
          "published_date": "06 Jan 2025",
          "video_url": "https://www.youtube.com/embed/_mx4JlLoTYs",
          "hd_video_url": "https://www.youtube.com/embed/_mx4JlLoTYs",
          "thumbnail": "https://i.ytimg.com/vi/_mx4JlLoTYs/default.jpg",
          "notes": [
            {
              "title": "Class Notes -  व्याख्यान- 56 रेडॉक्स अभिक्रिया - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4d30a9bf-0d53-4c4f-8289-045fcaede777.pdf"
            }
          ]
        },
        {
          "serial": 57,
          "title": "व्याख्यान- 57 || रेडॉक्स अभिक्रिया - 8",
          "published_date": "08 Jan 2025",
          "video_url": "https://www.youtube.com/embed/7Shc405sZuc",
          "hd_video_url": "https://www.youtube.com/embed/7Shc405sZuc",
          "thumbnail": "https://i.ytimg.com/vi/7Shc405sZuc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 57 || रेडॉक्स अभिक्रिया - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/dcaf021a-18c3-4fe9-b6bd-2571a0f52cf4.pdf"
            }
          ]
        },
        {
          "serial": 58,
          "title": "व्याख्यान- 58 || रेडॉक्स अभिक्रिया - 9",
          "published_date": "10 Jan 2025",
          "video_url": "https://www.youtube.com/embed/VuJlbr0rQVk",
          "hd_video_url": "https://www.youtube.com/embed/VuJlbr0rQVk",
          "thumbnail": "https://i.ytimg.com/vi/VuJlbr0rQVk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 58 || रेडॉक्स अभिक्रिया - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/dca3c014-bc86-4afb-9bc2-734c90ac2b09.pdf"
            }
          ]
        },
        {
          "serial": 59,
          "title": "व्याख्यान- 59 || विद्युत रसायन -1",
          "published_date": "13 Jan 2025",
          "video_url": "https://www.youtube.com/embed/I-w9VCALEfQ",
          "hd_video_url": "https://www.youtube.com/embed/I-w9VCALEfQ",
          "thumbnail": "https://i.ytimg.com/vi/I-w9VCALEfQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 59 || विद्युत रसायन -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/df83a2f4-4b6e-46f9-8238-e5b2eeb6e80b.pdf"
            }
          ]
        },
        {
          "serial": 60,
          "title": "व्याख्यान- 60 || विद्युत रसायन -2",
          "published_date": "15 Jan 2025",
          "video_url": "https://www.youtube.com/embed/QmOnNR6l9Nc",
          "hd_video_url": "https://www.youtube.com/embed/QmOnNR6l9Nc",
          "thumbnail": "https://i.ytimg.com/vi/QmOnNR6l9Nc/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 60  विद्युत रसायन -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4b0aa7c2-f43e-41a1-a0ee-f6ea375baa8d.pdf"
            }
          ]
        },
        {
          "serial": 61,
          "title": "व्याख्यान- 61 || विद्युत रसायन -3",
          "published_date": "17 Jan 2025",
          "video_url": "https://www.youtube.com/embed/qB6lepLg8Ks",
          "hd_video_url": "https://www.youtube.com/embed/qB6lepLg8Ks",
          "thumbnail": "https://i.ytimg.com/vi/qB6lepLg8Ks/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 61 || विद्युत रसायन -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d10e213e-e3a1-4a5a-879e-0731b57072f7.pdf"
            }
          ]
        },
        {
          "serial": 62,
          "title": "व्याख्यान- 62 || विद्युत रसायन -4",
          "published_date": "20 Jan 2025",
          "video_url": "https://www.youtube.com/embed/MOoEdozExo0",
          "hd_video_url": "https://www.youtube.com/embed/MOoEdozExo0",
          "thumbnail": "https://i.ytimg.com/vi/MOoEdozExo0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 62 || विद्युत रसायन -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/cfb68c88-2eaa-4e09-9bb1-0d0634d77c20.pdf"
            }
          ]
        },
        {
          "serial": 63,
          "title": "व्याख्यान- 63 || विद्युत रसायन -5",
          "published_date": "24 Jan 2025",
          "video_url": "https://www.youtube.com/embed/sUJIy2alC44",
          "hd_video_url": "https://www.youtube.com/embed/sUJIy2alC44",
          "thumbnail": "https://i.ytimg.com/vi/sUJIy2alC44/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 64  विद्युत रसायन -6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/30ef1acf-0ec9-4aa5-81b2-c3c3ffe21804.pdf"
            }
          ]
        },
        {
          "serial": 64,
          "title": "व्याख्यान- 64 || विद्युत रसायन -6",
          "published_date": "27 Jan 2025",
          "video_url": "https://www.youtube.com/embed/CDY-rVUTrqA",
          "hd_video_url": "https://www.youtube.com/embed/CDY-rVUTrqA",
          "thumbnail": "https://i.ytimg.com/vi/CDY-rVUTrqA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 65 || विद्युत रसायन -7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c40f4201-d5c8-40cb-a97b-1bfbc61fdb04.pdf"
            }
          ]
        },
        {
          "serial": 65,
          "title": "व्याख्यान- 65 || विद्युत रसायन -7",
          "published_date": "29 Jan 2025",
          "video_url": "https://www.youtube.com/embed/voUqDqXPT5s",
          "hd_video_url": "https://www.youtube.com/embed/voUqDqXPT5s",
          "thumbnail": "https://i.ytimg.com/vi/voUqDqXPT5s/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 65 || विद्युत रसायन -7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/540f245c-44be-4481-865c-7c549fd11a6c.pdf"
            }
          ]
        },
        {
          "serial": 66,
          "title": "व्याख्यान- 66 || विद्युत रसायन -8",
          "published_date": "31 Jan 2025",
          "video_url": "https://www.youtube.com/embed/25HAQ8z9xAo",
          "hd_video_url": "https://www.youtube.com/embed/25HAQ8z9xAo",
          "thumbnail": "https://i.ytimg.com/vi/25HAQ8z9xAo/default.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 66 || विद्युत रसायन -8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3016b1a1-e4a4-4eaa-92ed-da7b51c84f63.pdf"
            }
          ]
        },
        {
          "serial": 67,
          "title": "व्याख्यान- 67 || विद्युत रसायन -9",
          "published_date": "03 Feb 2025",
          "video_url": "https://www.youtube.com/embed/WVSdcSYkVAk",
          "hd_video_url": "https://www.youtube.com/embed/WVSdcSYkVAk",
          "thumbnail": "https://i.ytimg.com/vi/WVSdcSYkVAk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 67 || विद्युत रसायन -9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/59c7f23e-a650-4a27-bace-b96da311453b.pdf"
            }
          ]
        },
        {
          "serial": 68,
          "title": "व्याख्यान- 68 || विद्युत रसायन -10",
          "published_date": "08 Feb 2025",
          "video_url": "https://www.youtube.com/embed/S9Y-TYi97Bc",
          "hd_video_url": "https://www.youtube.com/embed/S9Y-TYi97Bc",
          "thumbnail": "https://i.ytimg.com/vi/S9Y-TYi97Bc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 68 || विद्युत रसायन -10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3c5ece62-3693-47c6-88ec-df743992fa93.pdf"
            }
          ]
        },
        {
          "serial": 69,
          "title": "व्याख्यान- 69 || विद्युत रसायन -11",
          "published_date": "10 Feb 2025",
          "video_url": "https://www.youtube.com/embed/PdjVHihTL-s",
          "hd_video_url": "https://www.youtube.com/embed/PdjVHihTL-s",
          "thumbnail": "https://i.ytimg.com/vi/PdjVHihTL-s/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 69 || विद्युत रसायन -11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/dc03662a-3091-4ba4-b8a8-cc813fbcde21.pdf"
            }
          ]
        },
        {
          "serial": 70,
          "title": "व्याख्यान- 70 || विद्युत रसायन -12",
          "published_date": "11 Feb 2025",
          "video_url": "https://www.youtube.com/embed/RGHsRO8mB1c",
          "hd_video_url": "https://www.youtube.com/embed/RGHsRO8mB1c",
          "thumbnail": "https://i.ytimg.com/vi/RGHsRO8mB1c/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 70 || विद्युत रसायन -12",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/48ea6eb2-73f0-4a3c-bab6-114670d371ee.pdf"
            }
          ]
        },
        {
          "serial": 71,
          "title": "व्याख्यान- 71 || विद्युत रसायन -13",
          "published_date": "12 Feb 2025",
          "video_url": "https://www.youtube.com/embed/p4azYARoyJc",
          "hd_video_url": "https://www.youtube.com/embed/p4azYARoyJc",
          "thumbnail": "https://i.ytimg.com/vi/p4azYARoyJc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 71 || विद्युत रसायन -13",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/dcd7d8e3-6f32-4a7f-9997-9e8ca551c874.pdf"
            }
          ]
        },
        {
          "serial": 72,
          "title": "व्याख्यान- 72 || विद्युत रसायन -14",
          "published_date": "14 Feb 2025",
          "video_url": "https://www.youtube.com/embed/ybruBonc-JM",
          "hd_video_url": "https://www.youtube.com/embed/ybruBonc-JM",
          "thumbnail": "https://i.ytimg.com/vi/ybruBonc-JM/default.jpg",
          "notes": [
            {
              "title": "Class Notes- व्याख्यान- 72 || विद्युत रसायन -14",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ce26a774-2ddc-4404-b237-aee441410eb3.pdf"
            }
          ]
        },
        {
          "serial": 73,
          "title": "व्याख्यान- 73 || रासायनिक बलगतिकी - 1",
          "published_date": "18 Feb 2025",
          "video_url": "https://www.youtube.com/embed/G6vJd8QeGU8",
          "hd_video_url": "https://www.youtube.com/embed/G6vJd8QeGU8",
          "thumbnail": "https://i.ytimg.com/vi/G6vJd8QeGU8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 73 || रासायनिक बलगतिकी - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e083a87b-f237-4d27-a8cf-458987dc6814.pdf"
            }
          ]
        },
        {
          "serial": 74,
          "title": "व्याख्यान- 74 || रासायनिक बलगतिकी - 2",
          "published_date": "19 Feb 2025",
          "video_url": "https://www.youtube.com/embed/JDKU3wpsFtw",
          "hd_video_url": "https://www.youtube.com/embed/JDKU3wpsFtw",
          "thumbnail": "https://i.ytimg.com/vi/JDKU3wpsFtw/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 74 || रासायनिक बलगतिकी - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/97adeb55-26e1-4752-90a8-4116de1572e7.pdf"
            }
          ]
        },
        {
          "serial": 75,
          "title": "व्याख्यान- 75 || रासायनिक बलगतिकी - 3",
          "published_date": "21 Feb 2025",
          "video_url": "https://www.youtube.com/embed/Xfg2dmoOf_I",
          "hd_video_url": "https://www.youtube.com/embed/Xfg2dmoOf_I",
          "thumbnail": "https://i.ytimg.com/vi/Xfg2dmoOf_I/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 75 || रासायनिक बलगतिकी - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ec769064-4595-40ca-8492-a9b1d222d279.pdf"
            }
          ]
        },
        {
          "serial": 76,
          "title": "व्याख्यान- 76 || रासायनिक बलगतिकी - 4",
          "published_date": "24 Feb 2025",
          "video_url": "https://www.youtube.com/embed/Ui3wHK4wJCI",
          "hd_video_url": "https://www.youtube.com/embed/Ui3wHK4wJCI",
          "thumbnail": "https://i.ytimg.com/vi/Ui3wHK4wJCI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 76 || रासायनिक बलगतिकी - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a88e980f-866a-48b5-b9b5-0d4fa79452a1.pdf"
            }
          ]
        },
        {
          "serial": 77,
          "title": "व्याख्यान- 77 || रासायनिक बलगतिकी - 5",
          "published_date": "27 Feb 2025",
          "video_url": "https://www.youtube.com/embed/DxlSzfUjVmU",
          "hd_video_url": "https://www.youtube.com/embed/DxlSzfUjVmU",
          "thumbnail": "https://i.ytimg.com/vi/DxlSzfUjVmU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 77 || रासायनिक बलगतिकी - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f558e7a9-2943-45d8-80ea-85140926066e.pdf"
            }
          ]
        },
        {
          "serial": 78,
          "title": "व्याख्यान- 78 || रासायनिक बलगतिकी - 6",
          "published_date": "03 Mar 2025",
          "video_url": "https://www.youtube.com/embed/_m61CzOi11A",
          "hd_video_url": "https://www.youtube.com/embed/_m61CzOi11A",
          "thumbnail": "https://i.ytimg.com/vi/_m61CzOi11A/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 78 || रासायनिक बलगतिकी - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ae62351a-b01b-4541-9c12-93498a18691f.pdf"
            }
          ]
        },
        {
          "serial": 79,
          "title": "व्याख्यान- 79 || रासायनिक बलगतिकी - 7",
          "published_date": "05 Mar 2025",
          "video_url": "https://www.youtube.com/embed/En2YfGYNjQU",
          "hd_video_url": "https://www.youtube.com/embed/En2YfGYNjQU",
          "thumbnail": "https://i.ytimg.com/vi/En2YfGYNjQU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 79 || रासायनिक बलगतिकी - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f7a17e9c-4a43-4754-91f8-f7bba5f1fcfd.pdf"
            }
          ]
        },
        {
          "serial": 80,
          "title": "व्याख्यान- 80 || रासायनिक बलगतिकी - 8",
          "published_date": "10 Mar 2025",
          "video_url": "https://www.youtube.com/embed/mV8kUid6Ffs",
          "hd_video_url": "https://www.youtube.com/embed/mV8kUid6Ffs",
          "thumbnail": "https://i.ytimg.com/vi/mV8kUid6Ffs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 80 || रासायनिक बलगतिकी - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e1590469-5314-403f-9eed-64968aef1ca9.pdf"
            }
          ]
        },
        {
          "serial": 81,
          "title": "व्याख्यान- 81 || रासायनिक बलगतिकी - 9",
          "published_date": "28 Mar 2025",
          "video_url": "https://www.youtube.com/embed/HKjTgIsGemQ",
          "hd_video_url": "https://www.youtube.com/embed/HKjTgIsGemQ",
          "thumbnail": "https://i.ytimg.com/vi/HKjTgIsGemQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 81 || रासायनिक बलगतिकी - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ccf8f5a8-31c0-4cbc-94dd-a20d564169f9.pdf"
            }
          ]
        }
      ],
      "notes": []
    },
    {
      "subject_name": "Chemistry Supporting Material",
      "subject_id": 3427,
      "video_count": 0,
      "note_count": 0,
      "videos": [],
      "notes": []
    },
    {
      "subject_name": "Diwali Assignment",
      "subject_id": 4559,
      "video_count": 0,
      "note_count": 0,
      "videos": [],
      "notes": []
    },
    {
      "subject_name": "Introduction Section",
      "subject_id": 3388,
      "video_count": 3,
      "note_count": 0,
      "videos": [
        {
          "serial": 1,
          "title": "NEET 2025 Students Orientation Session By Shekhar Sir",
          "published_date": "05 Sep 2024",
          "video_url": "https://www.youtube.com/embed/6V-UMl_kKaQ",
          "hd_video_url": "https://www.youtube.com/embed/6V-UMl_kKaQ",
          "thumbnail": "",
          "notes": []
        },
        {
          "serial": 2,
          "title": "How to Use Your Application",
          "published_date": "07 Sep 2024",
          "video_url": "https://www.youtube.com/embed/17pEf-lKGMM",
          "hd_video_url": "https://www.youtube.com/embed/17pEf-lKGMM",
          "thumbnail": "",
          "notes": []
        },
        {
          "serial": 3,
          "title": "How to attempt your test on KGS Website",
          "published_date": "09 Oct 2024",
          "video_url": "https://www.youtube.com/embed/xTLV8f8x_RU",
          "hd_video_url": "https://www.youtube.com/embed/xTLV8f8x_RU",
          "thumbnail": "",
          "notes": []
        }
      ],
      "notes": []
    },
    {
      "subject_name": "Physics  by Jitesh Parashar Sir",
      "subject_id": 5881,
      "video_count": 5,
      "note_count": 5,
      "videos": [
        {
          "serial": 1,
          "title": "व्याख्यान- 1 || तरल पदार्थों के यांत्रिक गुण - 1",
          "published_date": "24 Mar 2025",
          "video_url": "https://www.youtube.com/embed/hAC4m0JSxZQ",
          "hd_video_url": "https://www.youtube.com/embed/hAC4m0JSxZQ",
          "thumbnail": "https://i.ytimg.com/vi/hAC4m0JSxZQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 1 || तरल पदार्थों के यांत्रिक गुण - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/419f5fdf-edaf-4c71-b94e-b8bd8b1fc9d1.pdf"
            }
          ]
        },
        {
          "serial": 2,
          "title": "व्याख्यान- 2 || तरल पदार्थों के यांत्रिक गुण - 2",
          "published_date": "25 Mar 2025",
          "video_url": "https://www.youtube.com/embed/jtB65LHUjIk",
          "hd_video_url": "https://www.youtube.com/embed/jtB65LHUjIk",
          "thumbnail": "https://i.ytimg.com/vi/jtB65LHUjIk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 2 || तरल पदार्थों के यांत्रिक गुण - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/169acf45-4765-41d3-b510-5d78f11b59dc.pdf"
            }
          ]
        },
        {
          "serial": 3,
          "title": "व्याख्यान- 3 || तरल पदार्थों के यांत्रिक गुण - 3",
          "published_date": "27 Mar 2025",
          "video_url": "https://www.youtube.com/embed/fvj6UgSv730",
          "hd_video_url": "https://www.youtube.com/embed/fvj6UgSv730",
          "thumbnail": "https://i.ytimg.com/vi/fvj6UgSv730/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 3 || तरल पदार्थों के यांत्रिक गुण - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/533c8ecc-5723-4a5f-a239-b9a6a52acd02.pdf"
            }
          ]
        },
        {
          "serial": 4,
          "title": "व्याख्यान- 4 || तरल पदार्थों के यांत्रिक गुण - 4",
          "published_date": "28 Mar 2025",
          "video_url": "https://www.youtube.com/embed/kL3_J4uiX4A",
          "hd_video_url": "https://www.youtube.com/embed/kL3_J4uiX4A",
          "thumbnail": "https://i.ytimg.com/vi/kL3_J4uiX4A/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 4 || तरल पदार्थों के यांत्रिक गुण - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6d1231d3-cb1c-49e0-9567-2ad9ae3d6445.pdf"
            }
          ]
        },
        {
          "serial": 5,
          "title": "व्याख्यान- 5 || तरल पदार्थों के यांत्रिक गुण - 5",
          "published_date": "29 Mar 2025",
          "video_url": "https://www.youtube.com/embed/L66x4IEiLiI",
          "hd_video_url": "https://www.youtube.com/embed/L66x4IEiLiI",
          "thumbnail": "https://i.ytimg.com/vi/L66x4IEiLiI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 5 || तरल पदार्थों के यांत्रिक गुण - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8531c7f8-c0e7-4e4e-a009-4387fc47d30c.pdf"
            }
          ]
        }
      ],
      "notes": []
    },
    {
      "subject_name": "Physics By Mohit Agrawal (MA Sir)",
      "subject_id": 3391,
      "video_count": 214,
      "note_count": 214,
      "videos": [
        {
          "serial": 1,
          "title": "व्याख्यान- 01 || एकदम Basic से: ZERO Lecture मुलभूत गणित by MA Sir | KGS NEET",
          "published_date": "05 Sep 2024",
          "video_url": "https://www.youtube.com/embed/DXEjoNYXJRY",
          "hd_video_url": "https://www.youtube.com/embed/DXEjoNYXJRY",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes एकदम Basic से: ZERO Lecture मुलभूत गणित by MA Sir | KGS NEET",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ec224bd0-20a9-4ab3-9266-1ebc95592b8a.pdf"
            }
          ]
        },
        {
          "serial": 2,
          "title": "व्याख्यान- 02 || एकदम Basic से: ZERO Lecture मुलभूत गणित Part 2",
          "published_date": "06 Sep 2024",
          "video_url": "https://www.youtube.com/embed/Gch0q40wVQk",
          "hd_video_url": "https://www.youtube.com/embed/Gch0q40wVQk",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes || एकदम Basic से: ZERO Lecture मुलभूत गणित Part 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6b7931ee-fa63-4624-9eb0-1147dd4ce13d.pdf"
            }
          ]
        },
        {
          "serial": 3,
          "title": "व्याख्यान- 03 || एकदम Basic से: ZERO Lecture मुलभूत गणित Part 3 by MA Sir",
          "published_date": "08 Sep 2024",
          "video_url": "https://www.youtube.com/embed/XwJm0KRByfQ",
          "hd_video_url": "https://www.youtube.com/embed/XwJm0KRByfQ",
          "thumbnail": "",
          "notes": [
            {
              "title": "एकदम Basic से: ZERO Lecture मुलभूत गणित Part 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/15995b4c-02df-4bce-a142-fcdc7b198427.pdf"
            }
          ]
        },
        {
          "serial": 4,
          "title": "व्याख्यान- 04 || मूलभूत गणित - 1",
          "published_date": "09 Sep 2024",
          "video_url": "https://www.youtube.com/embed/zzRXD39ZqMw",
          "hd_video_url": "https://www.youtube.com/embed/zzRXD39ZqMw",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 01 || मूलभूत गणित - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/18758ff3-5d2d-4c6b-8abe-3bcaa70398a4.pdf"
            }
          ]
        },
        {
          "serial": 5,
          "title": "व्याख्यान- 05 || मूलभूत गणित - 2",
          "published_date": "10 Sep 2024",
          "video_url": "https://www.youtube.com/embed/AnVeTK3_CHg",
          "hd_video_url": "https://www.youtube.com/embed/AnVeTK3_CHg",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 02 || मूलभूत गणित - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7927e7ac-6595-4c64-9b96-25a49f2519ec.pdf"
            }
          ]
        },
        {
          "serial": 6,
          "title": "व्याख्यान- 06 || मूलभूत गणित - 3",
          "published_date": "11 Sep 2024",
          "video_url": "https://www.youtube.com/embed/UZc2-BKPikA",
          "hd_video_url": "https://www.youtube.com/embed/UZc2-BKPikA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/thumb/uploads/RYL4gEnvnyXBCsbvpq70HNHfZEfY7ogEvkTCpquq.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 03 || मूलभूत गणित - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b5c8d449-84d8-4ecf-978d-9f7d1e71e13d.pdf"
            }
          ]
        },
        {
          "serial": 7,
          "title": "व्याख्यान- 07 || मूलभूत गणित - 4",
          "published_date": "12 Sep 2024",
          "video_url": "https://www.youtube.com/embed/hxGqZCCwbx0",
          "hd_video_url": "https://www.youtube.com/embed/hxGqZCCwbx0",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/IZagSF2ERBzV2qO74UKuG7dq3gY8LGjkSHPeOx80.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 04 || मूलभूत गणित - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7181f4d8-7977-4d8f-9aae-98492f75fcef.pdf"
            }
          ]
        },
        {
          "serial": 8,
          "title": "व्याख्यान- 08 || मूलभूत गणित - 5",
          "published_date": "13 Sep 2024",
          "video_url": "https://www.youtube.com/embed/RB3Je_4xvjM",
          "hd_video_url": "https://www.youtube.com/embed/RB3Je_4xvjM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/pUZyabuf5Bwx6NtBv845QZwomUt6cKAIKzBvYuk1.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 05 || मूलभूत गणित - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/84821a02-3491-4ed3-ab52-82c325f3d71e.pdf"
            }
          ]
        },
        {
          "serial": 9,
          "title": "व्याख्यान- 09 || मूलभूत गणित - 6",
          "published_date": "14 Sep 2024",
          "video_url": "https://www.youtube.com/embed/pnYptjQVbbo",
          "hd_video_url": "https://www.youtube.com/embed/pnYptjQVbbo",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/VEibteaVaRV2IL7uC90SqGx06RZPj0esirBAc9Zp.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 06 || मूलभूत गणित - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b3a7721b-c23e-4a6a-b341-7366f49aa3f1.pdf"
            }
          ]
        },
        {
          "serial": 10,
          "title": "व्याख्यान- 10|| मूलभूत गणित - 7",
          "published_date": "14 Sep 2024",
          "video_url": "https://www.youtube.com/embed/qifflhGNcGM",
          "hd_video_url": "https://www.youtube.com/embed/qifflhGNcGM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/14lVf10FDoXox7r77EskIatWzBA3KWBzB1YrE1uA.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 10|| मूलभूत गणित - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/091d6c1c-94c5-481b-a37c-eaf6c90148e6.pdf"
            }
          ]
        },
        {
          "serial": 11,
          "title": "व्याख्यान- 11 || सदिश राशि - 1",
          "published_date": "15 Sep 2024",
          "video_url": "https://www.youtube.com/embed/CUW2WA-zA8Y",
          "hd_video_url": "https://www.youtube.com/embed/CUW2WA-zA8Y",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/mHBxkrFigtMwF10lZe9CauDAGfgQPHCougshPn1n.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 11 || सदिश राशि - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c79eb005-7889-448e-a64b-9c98becbf5ca.pdf"
            }
          ]
        },
        {
          "serial": 12,
          "title": "व्याख्यान- 12 || सदिश राशि - 2",
          "published_date": "16 Sep 2024",
          "video_url": "https://www.youtube.com/embed/mB8se6Xg_ag",
          "hd_video_url": "https://www.youtube.com/embed/mB8se6Xg_ag",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/nIAcJQkPRWCXn3at5td4Cc7q5X4ZXOFAy0No24H9.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 12 || सदिश राशि - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a70f09a4-c8eb-4c60-8c1c-89351a8bc140.pdf"
            }
          ]
        },
        {
          "serial": 13,
          "title": "व्याख्यान- 13 || सदिश राशि - 3.",
          "published_date": "17 Sep 2024",
          "video_url": "https://www.youtube.com/embed/FqrdTmSO-uI",
          "hd_video_url": "https://www.youtube.com/embed/FqrdTmSO-uI",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/ZKNgUDpMgZwTAA0SEEvRI7Tv3rRTglgSCAePdBl2.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 13 || सदिश राशि - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c1b92804-edce-4cc4-8755-99ebf61a931b.pdf"
            }
          ]
        },
        {
          "serial": 14,
          "title": "व्याख्यान- 14 || सदिश राशि - 4",
          "published_date": "18 Sep 2024",
          "video_url": "https://www.youtube.com/embed/ub0TXKHnJcA",
          "hd_video_url": "https://www.youtube.com/embed/ub0TXKHnJcA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/23cEJAqmbq5csURG8kkN0CUs0HmLAiNg9K5xluK9.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 14 || सदिश राशि - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c7db2029-39c4-4505-9395-78a1d0f71f9c.pdf"
            }
          ]
        },
        {
          "serial": 15,
          "title": "व्याख्यान- 15 || सदिश राशि - 5",
          "published_date": "19 Sep 2024",
          "video_url": "https://www.youtube.com/embed/-Tjc_94xu6o",
          "hd_video_url": "https://www.youtube.com/embed/-Tjc_94xu6o",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/thumb/uploads/ErdsZcJZOIAPThkp8pIKgDIcMIQHqk4ZfsS1wLTX.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 15 || सदिश राशि - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/99d345a1-c0b5-4926-bb26-acc3f2641b59.pdf"
            }
          ]
        },
        {
          "serial": 16,
          "title": "व्याख्यान- 16 || सदिश राशि - 6",
          "published_date": "20 Sep 2024",
          "video_url": "https://www.youtube.com/embed/lvIRk6wUo0U",
          "hd_video_url": "https://www.youtube.com/embed/lvIRk6wUo0U",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/O1lp4zKs0gNz3L5CRCEXxT8LrYHyS2vrxGHiXJB6.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 16 || सदिश राशि - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d77ea42c-5c29-4f3e-b8fc-074065a935e3.pdf"
            }
          ]
        },
        {
          "serial": 17,
          "title": "व्याख्यान- 17 || सरल रेखा में गति -1",
          "published_date": "21 Sep 2024",
          "video_url": "https://www.youtube.com/embed/doOKnbEmsR8",
          "hd_video_url": "https://www.youtube.com/embed/doOKnbEmsR8",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/1E523j9em6UmDfcBTNhLa0lpbkFZPgTFr4YuSUyz.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 17 || सरल रेखा में गति -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fa27139c-f320-42e3-8a0e-664d51924506.pdf"
            }
          ]
        },
        {
          "serial": 18,
          "title": "व्याख्यान- 18 || सरल रेखा में गति -2",
          "published_date": "22 Sep 2024",
          "video_url": "https://www.youtube.com/embed/UyXfcfUjllg",
          "hd_video_url": "https://www.youtube.com/embed/UyXfcfUjllg",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/f1FMsv1KVrRv0cvqwH9DLHuZF6jr43qtJvHJDPSC.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 18 || सरल रेखा में गति -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5ce0ad17-4aff-4c64-b490-37a691706d8b.pdf"
            }
          ]
        },
        {
          "serial": 19,
          "title": "व्याख्यान- 19 || सरल रेखा में गति -3",
          "published_date": "23 Sep 2024",
          "video_url": "https://www.youtube.com/embed/XfmJltDSDqQ",
          "hd_video_url": "https://www.youtube.com/embed/XfmJltDSDqQ",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/xFhvFJxKSf5GRc58izI20jH7q2LPqwqRsBIQykoM.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 19 || सरल रेखा में गति -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/528bf91e-ed2b-42de-b749-3f153cb72c4c.pdf"
            }
          ]
        },
        {
          "serial": 20,
          "title": "व्याख्यान- 20 || सरल रेखा में गति -4",
          "published_date": "24 Sep 2024",
          "video_url": "https://www.youtube.com/embed/3RBSSLpfCMM",
          "hd_video_url": "https://www.youtube.com/embed/3RBSSLpfCMM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/n9pEvYrYwf9HwJ8p7EJZ0HBxggnzU1XZYhX4pRUu.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 20 || सरल रेखा में गति -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9e0997a8-a6d7-4685-a431-12d4c8bb60f5.pdf"
            }
          ]
        },
        {
          "serial": 21,
          "title": "व्याख्यान- 21 || सरल रेखा में गति -5",
          "published_date": "25 Sep 2024",
          "video_url": "https://www.youtube.com/embed/r8b_ATaLcoU",
          "hd_video_url": "https://www.youtube.com/embed/r8b_ATaLcoU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/fJ0GpmREMRvCFL4xbXR7ENH4SeH6vTGZA1ZDSl0w.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 21 || सरल रेखा में गति -5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3c6a3660-7951-4860-aee4-918043f3f5ce.pdf"
            }
          ]
        },
        {
          "serial": 22,
          "title": "व्याख्यान- 22 || सरल रेखा में गति -6",
          "published_date": "25 Sep 2024",
          "video_url": "https://www.youtube.com/embed/amZOehoG3xw",
          "hd_video_url": "https://www.youtube.com/embed/amZOehoG3xw",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/D1yJYji1H10VXzB0c9rIE4DI2Hsdfdf8y2rhKAms.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 22 || सरल रेखा में गति -6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/805e4679-5ca0-47a6-8d4b-64ea63c72e05.pdf"
            }
          ]
        },
        {
          "serial": 23,
          "title": "व्याख्यान- 23 || सरल रेखा में गति -7",
          "published_date": "26 Sep 2024",
          "video_url": "https://www.youtube.com/embed/aQKN7xq16dM",
          "hd_video_url": "https://www.youtube.com/embed/aQKN7xq16dM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/piKothVeYxgohOnSNV7VoILitFIKe18RuWeRT4iy.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 23 || सरल रेखा में गति -7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9ea1f0f5-38b8-4441-b3b9-12b8ecacbdbe.pdf"
            }
          ]
        },
        {
          "serial": 24,
          "title": "व्याख्यान- 24 || सरल रेखा में गति -8",
          "published_date": "30 Sep 2024",
          "video_url": "https://www.youtube.com/embed/3PmlI_-giFU",
          "hd_video_url": "https://www.youtube.com/embed/3PmlI_-giFU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/jKRgKfxZuOfttZZQW9Ll6N7cH2Xw5u09bp3A6KFb.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 24 || सरल रेखा में गति -8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a57cba22-dea3-4908-b60a-96faa952320a.pdf"
            }
          ]
        },
        {
          "serial": 25,
          "title": "व्याख्यान- 25 || सरल रेखा में गति -9",
          "published_date": "01 Oct 2024",
          "video_url": "https://www.youtube.com/embed/E0GQkl6MwIY",
          "hd_video_url": "https://www.youtube.com/embed/E0GQkl6MwIY",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/lIOniCNNuuhdcE5biOtq0TaJvQ6MJyrXI0WEQnHp.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 25 || सरल रेखा में गति -9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ff308d7a-2332-4203-a7b9-726eb71ccafb.pdf"
            }
          ]
        },
        {
          "serial": 26,
          "title": "व्याख्यान- 26 || समतल में गति -01",
          "published_date": "01 Oct 2024",
          "video_url": "https://www.youtube.com/embed/ykyDZtvXMTM",
          "hd_video_url": "https://www.youtube.com/embed/ykyDZtvXMTM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/ezVPRUQCq3eE8GU9hZWVSOkMi1ZmFaDulLHf3WeB.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 26 || समतल में गति -01",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e5ed33e5-0e40-4f4b-b9d7-2870e63e899b.pdf"
            }
          ]
        },
        {
          "serial": 27,
          "title": "व्याख्यान- 27 || समतल में गति - 02",
          "published_date": "03 Oct 2024",
          "video_url": "https://www.youtube.com/embed/vh1iJCtBnvE",
          "hd_video_url": "https://www.youtube.com/embed/vh1iJCtBnvE",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/LWnNtpn5EzDdhdURCbROIWmofaLKKVyFl0s4bH8C.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 27 || समतल में गति - 02",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/cc009d5a-ac7a-4c9a-8efa-37b2602a0f0a.pdf"
            }
          ]
        },
        {
          "serial": 28,
          "title": "व्याख्यान- 28 || समतल में गति - 03",
          "published_date": "03 Oct 2024",
          "video_url": "https://www.youtube.com/embed/Hax_hvkhw-8",
          "hd_video_url": "https://www.youtube.com/embed/Hax_hvkhw-8",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/puCPP7cK59NYn9S0rp1z5cFclvJIiuMIm90yp153.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 28 || समतल में गति - 03",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5594f71c-12b7-4572-a218-19c5fefd3cd0.pdf"
            }
          ]
        },
        {
          "serial": 29,
          "title": "व्याख्यान- 29 || समतल में गति - 04",
          "published_date": "04 Oct 2024",
          "video_url": "https://www.youtube.com/embed/S6NaAoOPxps",
          "hd_video_url": "https://www.youtube.com/embed/S6NaAoOPxps",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/KoOfuYTThoJyZ8qSgcP57KBnujjVPj7YfiKUycor.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 29 || समतल में गति - 04",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3836b9b1-6b75-45f0-be4d-2c52cabeb857.pdf"
            }
          ]
        },
        {
          "serial": 30,
          "title": "व्याख्यान- 30  || समतल में गति - 05",
          "published_date": "05 Oct 2024",
          "video_url": "https://www.youtube.com/embed/TOdKRCq_S-A",
          "hd_video_url": "https://www.youtube.com/embed/TOdKRCq_S-A",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/M77oeD0AY5GCsKTD0b5sDrb4PHRe9KolKyJTBrDS.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 30 || समतल में गति - 05",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4fc6dbe5-05ae-4c00-8703-22b0cda4aaff.pdf"
            }
          ]
        },
        {
          "serial": 31,
          "title": "व्याख्यान- 31 || वृत्ताकार गति - 1",
          "published_date": "07 Oct 2024",
          "video_url": "https://www.youtube.com/embed/cTcCmqJU65k",
          "hd_video_url": "https://www.youtube.com/embed/cTcCmqJU65k",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/qnTm2O2VeVAZ4HJ8CHmlanJz3c5pBfiMdRjq8CTR.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 31 || वृत्ताकार गति - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4393a720-b9a0-41e6-a0db-a0dfc2b4ab99.pdf"
            }
          ]
        },
        {
          "serial": 32,
          "title": "व्याख्यान- 32 || वृत्ताकार गति - 2",
          "published_date": "07 Oct 2024",
          "video_url": "https://www.youtube.com/embed/PfNTXk3iGxE",
          "hd_video_url": "https://www.youtube.com/embed/PfNTXk3iGxE",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/0AGaEGY54aihOUk8yeoTx98txZ2ZU0mPKh53Bv64.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 32 || वृत्ताकार गति - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3eb035c5-78e3-42bd-a922-d042ec10695e.pdf"
            }
          ]
        },
        {
          "serial": 33,
          "title": "व्याख्यान- 33 || वृत्ताकार गति - 3",
          "published_date": "08 Oct 2024",
          "video_url": "https://www.youtube.com/embed/fiycC8mu6gM",
          "hd_video_url": "https://www.youtube.com/embed/fiycC8mu6gM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/QY0hgeegdiyjh5prctL76vesHK8ScrpaOE7gF6eW.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 33 || वृत्ताकार गति - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/effcf61b-0600-44ac-b483-938e1c3b4596.pdf"
            }
          ]
        },
        {
          "serial": 34,
          "title": "व्याख्यान- 34 || सापेक्ष गति - 1",
          "published_date": "08 Oct 2024",
          "video_url": "https://www.youtube.com/embed/PiTsO9Fjk8s",
          "hd_video_url": "https://www.youtube.com/embed/PiTsO9Fjk8s",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/UxqpNiJxQBXrfVMiQbON8E9kbneFTFBd9FCaMtCp.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 34 || सापेक्ष गति - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/02f3fcf3-4059-49fb-8d4f-855dac6116e8.pdf"
            }
          ]
        },
        {
          "serial": 35,
          "title": "व्याख्यान- 35 || सापेक्ष गति - 2",
          "published_date": "09 Oct 2024",
          "video_url": "https://www.youtube.com/embed/v-IunXDT9S8",
          "hd_video_url": "https://www.youtube.com/embed/v-IunXDT9S8",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/jhLvN66tqrRxmaDpATfnpZxmZHlEkjMTsRnRjCBz.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 35 || सापेक्ष गति - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/23c6d62a-c2d4-4598-a30b-ec305a9d3489.pdf"
            }
          ]
        },
        {
          "serial": 36,
          "title": "व्याख्यान- 36 || सापेक्ष गति - 3",
          "published_date": "10 Oct 2024",
          "video_url": "https://www.youtube.com/embed/zERAolJfxps",
          "hd_video_url": "https://www.youtube.com/embed/zERAolJfxps",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/77Gr8ZXWMmba6uUkwQKhp6JGXxqAlzuuVHjsKUvC.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 36 || सापेक्ष गति - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/38c27459-1d2f-44ce-b145-97221969c2c0.pdf"
            }
          ]
        },
        {
          "serial": 37,
          "title": "व्याख्यान- 37 || सापेक्ष गति - 4",
          "published_date": "14 Oct 2024",
          "video_url": "https://www.youtube.com/embed/bKo-EmjXd1w",
          "hd_video_url": "https://www.youtube.com/embed/bKo-EmjXd1w",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/u8lnIiBujDMbFnTuU1sz1uquafONUwrrugH6vyK7.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 37 || सापेक्ष गति - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a976ca11-95d4-48a9-83db-7ca73eb57f1c.pdf"
            }
          ]
        },
        {
          "serial": 38,
          "title": "व्यख्यान- 38 || सापेक्ष गति - 5",
          "published_date": "14 Oct 2024",
          "video_url": "https://www.youtube.com/embed/Pv374Of5mRk",
          "hd_video_url": "https://www.youtube.com/embed/Pv374Of5mRk",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/EUUlw0PenPsb0kzWUQKxTPLUwoktYi4lVtgNg2F8.jpg",
          "notes": [
            {
              "title": "Class Notes - व्यख्यान- 38 || सापेक्ष गति - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/30400c5a-2238-4b05-af6e-a7565a69971c.pdf"
            }
          ]
        },
        {
          "serial": 39,
          "title": "व्याख्यान- 39 || न्यूटन का गति एवं घर्षण का नियम - 1",
          "published_date": "15 Oct 2024",
          "video_url": "https://www.youtube.com/embed/LT59BqZVD1g",
          "hd_video_url": "https://www.youtube.com/embed/LT59BqZVD1g",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/urWI5T5wwJwEAMlManh678OwEAr7a7tsDOkHfBKf.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 39 || न्यूटन का गति एवं घर्षण का नियम  - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b76fc033-3c56-4698-9465-f5b4064b0210.pdf"
            }
          ]
        },
        {
          "serial": 40,
          "title": "व्याख्यान- 40 || न्यूटन का गति एवं घर्षण का नियम - 2",
          "published_date": "16 Oct 2024",
          "video_url": "https://www.youtube.com/embed/kOJqVYjPTSQ",
          "hd_video_url": "https://www.youtube.com/embed/kOJqVYjPTSQ",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/34iaPwGqaJSqVZF1qCL2Wffgm4VgFNsD5kZjwA52.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 40  न्यूटन का गति एवं घर्षण का नियम - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1d32d3df-4f43-4de5-aea0-46461430cd85.pdf"
            }
          ]
        },
        {
          "serial": 41,
          "title": "व्याख्यान- 41 || न्यूटन का गति एवं घर्षण का नियम - 3",
          "published_date": "17 Oct 2024",
          "video_url": "https://www.youtube.com/embed/W3hvd1iv_dA",
          "hd_video_url": "https://www.youtube.com/embed/W3hvd1iv_dA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/oJXmUmGni85EjIZlvUJqpuV8ZaTMXpB2P3EGvQWq.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 41 || न्यूटन का गति एवं घर्षण का नियम - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/06083d66-d518-4170-b3ed-fc8a0d9c80a9.pdf"
            }
          ]
        },
        {
          "serial": 42,
          "title": "व्याख्यान- 42 || न्यूटन का गति एवं घर्षण का नियम - 4",
          "published_date": "17 Oct 2024",
          "video_url": "https://www.youtube.com/embed/YFs00KOPm3E",
          "hd_video_url": "https://www.youtube.com/embed/YFs00KOPm3E",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/UJvZqUVEV4cepNvJsdQAT6uxKvBCfh10XMjKHN81.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 42 || न्यूटन का गति एवं घर्षण का नियम - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/51d910c8-e892-4df4-884a-df7783581737.pdf"
            }
          ]
        },
        {
          "serial": 43,
          "title": "व्याख्यान- 43 || न्यूटन का गति एवं घर्षण का नियम - 5",
          "published_date": "18 Oct 2024",
          "video_url": "https://www.youtube.com/embed/Afj4E4Kqta8",
          "hd_video_url": "https://www.youtube.com/embed/Afj4E4Kqta8",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/XI3wOvdzM6Ztkhm4ewZXkzcXGkz5fyR1I6O43msi.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 43 || न्यूटन का गति एवं घर्षण का नियम - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/feedeef5-38c3-4701-bfbc-a917d0c8fc81.pdf"
            }
          ]
        },
        {
          "serial": 44,
          "title": "व्याख्यान- 44 || न्यूटन का गति एवं घर्षण का नियम - 6",
          "published_date": "19 Oct 2024",
          "video_url": "https://www.youtube.com/embed/75AlnT3a1F8",
          "hd_video_url": "https://www.youtube.com/embed/75AlnT3a1F8",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/qd2r8d26TQRy9X1iQziGCtb5DQCA072vNbhOwLem.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 44 || न्यूटन का गति एवं घर्षण का नियम - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/29af14b3-3814-4947-a3ec-c97fefa7cd23.pdf"
            }
          ]
        },
        {
          "serial": 45,
          "title": "व्याख्यान- 45 || न्यूटन का गति एवं घर्षण का नियम - 7",
          "published_date": "21 Oct 2024",
          "video_url": "https://www.youtube.com/embed/OvMPFfuE8Z4",
          "hd_video_url": "https://www.youtube.com/embed/OvMPFfuE8Z4",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/qxzlswf1JgHyc37pw8autMQExzOOlEMbHyTxP3mL.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 45 || न्यूटन का गति एवं घर्षण का नियम - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fd674ac7-b295-4493-88c5-9d00156d6eff.pdf"
            }
          ]
        },
        {
          "serial": 46,
          "title": "व्याख्यान- 46 || न्यूटन का गति एवं घर्षण का नियम -8",
          "published_date": "22 Oct 2024",
          "video_url": "https://www.youtube.com/embed/erYqZj4TFeA",
          "hd_video_url": "https://www.youtube.com/embed/erYqZj4TFeA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/3qBpyfvZbWMvnWxL0ge2Z03QJoYOLlPT2AJtvlaT.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 46 || न्यूटन का गति एवं घर्षण का नियम -8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/823ec6b8-73a0-4dbc-a5e1-4b0826e0a074.pdf"
            }
          ]
        },
        {
          "serial": 47,
          "title": "व्याख्यान- 47 || न्यूटन का गति एवं घर्षण का नियम -9",
          "published_date": "22 Oct 2024",
          "video_url": "https://www.youtube.com/embed/e4ECtsSC0lU",
          "hd_video_url": "https://www.youtube.com/embed/e4ECtsSC0lU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/Fs5XYroAcOeqGY3ma38WcKMDLZhKXrli1lph5YER.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 47 || न्यूटन का गति एवं घर्षण का नियम -9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/49985cca-cbfd-4d40-9ade-7896b039e791.pdf"
            }
          ]
        },
        {
          "serial": 48,
          "title": "व्याख्यान- 48 ||  घर्षण का नियम -1",
          "published_date": "23 Oct 2024",
          "video_url": "https://www.youtube.com/embed/A5WlJ9_EhFE",
          "hd_video_url": "https://www.youtube.com/embed/A5WlJ9_EhFE",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/UtGUTzBHiV2c1pPxEXwAYV7apbXqlWknWzFsul9C.jpg",
          "notes": [
            {
              "title": "Class Notes - घर्षण का नियम -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0b3532c1-5d9c-4cf9-ac04-37964a9b7527.pdf"
            }
          ]
        },
        {
          "serial": 49,
          "title": "व्याख्यान- 49 || घर्षण का नियम -2",
          "published_date": "24 Oct 2024",
          "video_url": "https://www.youtube.com/embed/XlIKmE1ynfU",
          "hd_video_url": "https://www.youtube.com/embed/XlIKmE1ynfU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/w18i9H268nx28sxUUtoPkDSPgI4fZ0zesmq0QjPQ.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 49 || घर्षण का नियम -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fcd16f50-55c0-4626-84dd-2f47939ca84f.pdf"
            }
          ]
        },
        {
          "serial": 50,
          "title": "व्याख्यान- 50 || घर्षण का नियम -3",
          "published_date": "24 Oct 2024",
          "video_url": "https://www.youtube.com/embed/0WUVNG72DUM",
          "hd_video_url": "https://www.youtube.com/embed/0WUVNG72DUM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/maG8yDfTV1O5LNQR5hVMp37AV1iBtEULM5D33UZu.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 50 || घर्षण का नियम -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6210e667-08f2-44e4-a492-ee37c7b39033.pdf"
            }
          ]
        },
        {
          "serial": 51,
          "title": "व्याख्यान- 51 || घर्षण का नियम -4",
          "published_date": "25 Oct 2024",
          "video_url": "https://www.youtube.com/embed/eY-entrNocA",
          "hd_video_url": "https://www.youtube.com/embed/eY-entrNocA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/JMiAYo5M1nS7zS1s3IBwkH7eFffEsKU4KbrAMcGd.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 51 || घर्षण का नियम -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/bb8a0211-e680-4a0e-aa53-0675de9077e0.pdf"
            }
          ]
        },
        {
          "serial": 52,
          "title": "व्याख्यान- 52 || घर्षण का नियम -5",
          "published_date": "26 Oct 2024",
          "video_url": "https://www.youtube.com/embed/SVUqNRjLdoI",
          "hd_video_url": "https://www.youtube.com/embed/SVUqNRjLdoI",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/ceiqIz80hgcC3HYPjkSaFK9bE9EHmjbNneyXCPBh.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 52 || घर्षण का नियम -5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/586e1735-c0c3-4ef5-8740-51bc95f7d8a3.pdf"
            }
          ]
        },
        {
          "serial": 53,
          "title": "व्याख्यान- 53 || कार्य, ऊर्जा एवं शक्ति - 1",
          "published_date": "28 Oct 2024",
          "video_url": "https://www.youtube.com/embed/d5h8FACDvz4",
          "hd_video_url": "https://www.youtube.com/embed/d5h8FACDvz4",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/YCbVuSnQeXSKqOVXjOe17oN8sZcHKtmImVRh8ufr.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 53 || कार्य, ऊर्जा एवं शक्ति - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3f6164dc-d4c2-486c-9d88-ae39708f3f37.pdf"
            }
          ]
        },
        {
          "serial": 54,
          "title": "व्याख्यान- 54 || कार्य, ऊर्जा एवं शक्ति - 2",
          "published_date": "29 Oct 2024",
          "video_url": "https://www.youtube.com/embed/JMV1vHp0_GM",
          "hd_video_url": "https://www.youtube.com/embed/JMV1vHp0_GM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/nHfaNGbB3gOKEGnYz9plmIyiL43CAnLt7KZX6bsG.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 54 || कार्य, ऊर्जा एवं शक्ति - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/740e66cb-9936-4401-8b10-d7da869ea5f3.pdf"
            }
          ]
        },
        {
          "serial": 55,
          "title": "व्याख्यान- 55 || कार्य, ऊर्जा एवं शक्ति - 3",
          "published_date": "04 Nov 2024",
          "video_url": "https://www.youtube.com/embed/ulFKoBhJCHs",
          "hd_video_url": "https://www.youtube.com/embed/ulFKoBhJCHs",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/thumb/uploads/4hH4ctdoX0FHyibFlYP27nPk5tim3lyU73yqXeLO.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 55 || कार्य, ऊर्जा एवं शक्ति - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/925a4644-3a0d-4552-9efe-3f726d4faab1.pdf"
            }
          ]
        },
        {
          "serial": 56,
          "title": "व्याख्यान- 56 || कार्य, ऊर्जा एवं शक्ति - 4",
          "published_date": "05 Nov 2024",
          "video_url": "https://www.youtube.com/embed/lHwAEn5cBiY",
          "hd_video_url": "https://www.youtube.com/embed/lHwAEn5cBiY",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/fgtM3gr014bCx1dGr9rZeF17HlffXZ6AOpCSYyEC.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 56 || कार्य, ऊर्जा एवं शक्ति - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/682e362b-dd77-4840-bf38-08c66141a395.pdf"
            }
          ]
        },
        {
          "serial": 57,
          "title": "व्याख्यान- 57 || कार्य, ऊर्जा एवं शक्ति - 5",
          "published_date": "05 Nov 2024",
          "video_url": "https://www.youtube.com/embed/pI_eyZhknYI",
          "hd_video_url": "https://www.youtube.com/embed/pI_eyZhknYI",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/y3zavoCi3KDE1PQuBeZqf86heMnvgNfJIJKjSwlp.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 57 || कार्य, ऊर्जा एवं शक्ति - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a819583a-ef2e-4e55-a668-2ead30062cad.pdf"
            }
          ]
        },
        {
          "serial": 58,
          "title": "व्याख्यान- 58 || कार्य, ऊर्जा एवं शक्ति - 6",
          "published_date": "06 Nov 2024",
          "video_url": "https://www.youtube.com/embed/nJylbIbUH64",
          "hd_video_url": "https://www.youtube.com/embed/nJylbIbUH64",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/qW3hmCxTETPcGFHinHKmg4HdZ0GSOXz10CbZCoDZ.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 58 || कार्य, ऊर्जा एवं शक्ति - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/427c3ade-b632-456f-8f9c-365ad16501fe.pdf"
            }
          ]
        },
        {
          "serial": 59,
          "title": "व्याख्यान- 59 || कार्य, ऊर्जा एवं शक्ति - 7",
          "published_date": "07 Nov 2024",
          "video_url": "https://www.youtube.com/embed/29ZtQlNFETg",
          "hd_video_url": "https://www.youtube.com/embed/29ZtQlNFETg",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/bagCgpJcEdYiEbLomGgYYR2rbnDzf2QTHmmMDlPE.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 59 || कार्य, ऊर्जा एवं शक्ति - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/434a5854-4914-4d84-bc25-4b2b33751d6a.pdf"
            }
          ]
        },
        {
          "serial": 60,
          "title": "व्याख्यान- 60 || कार्य, ऊर्जा एवं शक्ति - 8",
          "published_date": "07 Nov 2024",
          "video_url": "https://www.youtube.com/embed/3rCOZtZIPZE",
          "hd_video_url": "https://www.youtube.com/embed/3rCOZtZIPZE",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/pnZwBuVAG7wRQH4R3tutRi8pD43tSxW7szpwVJz2.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 60 || कार्य, ऊर्जा एवं शक्ति - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5b581e85-39f4-4848-965e-3f3560c35a64.pdf"
            }
          ]
        },
        {
          "serial": 61,
          "title": "व्याख्यान- 61 || कार्य, ऊर्जा एवं शक्ति - 9",
          "published_date": "08 Nov 2024",
          "video_url": "https://www.youtube.com/embed/GrRmRE9ZgKs",
          "hd_video_url": "https://www.youtube.com/embed/GrRmRE9ZgKs",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/NofJHs8xhtRDyqK6AnWkLJLk1LnCUH8GyBP0jcQl.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 61 || कार्य, ऊर्जा एवं शक्ति - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2ca64081-af2a-4396-933a-cb7fe272cf63.pdf"
            }
          ]
        },
        {
          "serial": 62,
          "title": "व्याख्यान- 62 || कार्य, ऊर्जा एवं शक्ति - 10",
          "published_date": "09 Nov 2024",
          "video_url": "https://www.youtube.com/embed/5RznFjmYkfo",
          "hd_video_url": "https://www.youtube.com/embed/5RznFjmYkfo",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/TXcTRawNLyk97mteOZzbPCQTiZ1rrUntauI1i7Tn.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 62 || कार्य, ऊर्जा एवं शक्ति - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/02632f54-7395-452a-a7dd-41e91a922ac7.pdf"
            }
          ]
        },
        {
          "serial": 63,
          "title": "व्याख्यान- 63 ||  द्रव्यमान केंद्र ओर संघट्‍ट-1",
          "published_date": "11 Nov 2024",
          "video_url": "https://www.youtube.com/embed/LeVO4XhwEB0",
          "hd_video_url": "https://www.youtube.com/embed/LeVO4XhwEB0",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/wDlckMw1mW6Rbn1myHoiVIV2RNmYLX4wTW1ySue6.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 63 || द्रव्यमान केंद्र ओर संघट्‍ट-1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8757c4f0-4d63-4749-9de9-3638a7758894.pdf"
            }
          ]
        },
        {
          "serial": 64,
          "title": "व्याख्यान- 64 || द्रव्यमान केंद्र ओर संघट्‍ट-2",
          "published_date": "12 Nov 2024",
          "video_url": "https://www.youtube.com/embed/6MHkxi0LMyU",
          "hd_video_url": "https://www.youtube.com/embed/6MHkxi0LMyU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/Exsl1sguibsyoz4Flkq0AtIpZ7xlxoaD0dirKxS5.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 64 || द्रव्यमान केंद्र ओर संघट्‍ट-2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c0dc204a-dc2c-45cf-b620-4e1b7413bac1.pdf"
            }
          ]
        },
        {
          "serial": 65,
          "title": "व्याख्यान- 65 || Unit Test 2 Discussion",
          "published_date": "12 Nov 2024",
          "video_url": "https://www.youtube.com/embed/_pr-aGgG5x8",
          "hd_video_url": "https://www.youtube.com/embed/_pr-aGgG5x8",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/thumb/uploads/805349BmvFAEEE6eerhAIKXE68dSmHf7tmkRM09j.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 65 || Unit Test Discussion",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ce5adb32-1dea-491f-8b66-1d1eacb060b3.pdf"
            }
          ]
        },
        {
          "serial": 66,
          "title": "व्याख्यान- 66 || द्रव्यमान केंद्र ओर संघट्‍ट- 3",
          "published_date": "12 Nov 2024",
          "video_url": "https://www.youtube.com/embed/LpHWBblV1nc",
          "hd_video_url": "https://www.youtube.com/embed/LpHWBblV1nc",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/FGU7UYCs9dEX0jVflojOzlXyvljWo8Mk1F0bwqtE.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 66 || द्रव्यमान केंद्र ओर संघट्‍ट- 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/830affd8-1534-46f5-9860-3ca22f2d55be.pdf"
            }
          ]
        },
        {
          "serial": 67,
          "title": "व्याख्यान- 67 || द्रव्यमान केंद्र ओर संघट्‍ट- 4",
          "published_date": "13 Nov 2024",
          "video_url": "https://www.youtube.com/embed/6mkyuvHFMiE",
          "hd_video_url": "https://www.youtube.com/embed/6mkyuvHFMiE",
          "thumbnail": "https://i.ytimg.com/vi/6mkyuvHFMiE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 67 || द्रव्यमान केंद्र ओर संघट्‍ट- 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/402b0552-012d-46de-9a8e-af4f654501d5.pdf"
            }
          ]
        },
        {
          "serial": 68,
          "title": "व्याख्यान- 68 || द्रव्यमान केंद्र ओर संघट्‍ट- 5",
          "published_date": "14 Nov 2024",
          "video_url": "https://www.youtube.com/embed/Rd1uYTmN7Iw",
          "hd_video_url": "https://www.youtube.com/embed/Rd1uYTmN7Iw",
          "thumbnail": "https://i.ytimg.com/vi/Rd1uYTmN7Iw/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 68 || द्रव्यमान केंद्र ओर संघट्‍ट- 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/79360d5d-30a3-4037-b7bf-515a590c834a.pdf"
            }
          ]
        },
        {
          "serial": 69,
          "title": "व्याख्यान- 69 || द्रव्यमान केंद्र ओर संघट्‍ट- 6",
          "published_date": "14 Nov 2024",
          "video_url": "https://www.youtube.com/embed/tCGTOTC8w4k",
          "hd_video_url": "https://www.youtube.com/embed/tCGTOTC8w4k",
          "thumbnail": "https://i.ytimg.com/vi/tCGTOTC8w4k/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 69 || द्रव्यमान केंद्र ओर संघट्‍ट- 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/be6b7859-6431-4d72-a36e-c90014c029ef.pdf"
            }
          ]
        },
        {
          "serial": 70,
          "title": "व्याख्यान- 70 || घूर्णन गति  - 1",
          "published_date": "15 Nov 2024",
          "video_url": "https://www.youtube.com/embed/pqaUY8ggr_A",
          "hd_video_url": "https://www.youtube.com/embed/pqaUY8ggr_A",
          "thumbnail": "https://i.ytimg.com/vi/pqaUY8ggr_A/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 70 || घूर्णन गति  - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/27df5e70-4fa5-4f64-8b9d-d033b8c8b623.pdf"
            }
          ]
        },
        {
          "serial": 71,
          "title": "व्याख्यान- 71 || घूर्णन गति - 2",
          "published_date": "16 Nov 2024",
          "video_url": "https://www.youtube.com/embed/QxdXOiaFISM",
          "hd_video_url": "https://www.youtube.com/embed/QxdXOiaFISM",
          "thumbnail": "https://i.ytimg.com/vi/QxdXOiaFISM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 71 || घूर्णन गति - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/04b3d013-296f-4094-b154-1a1475f7c3c5.pdf"
            }
          ]
        },
        {
          "serial": 72,
          "title": "व्याख्यान- 72 || घूर्णन गति - 3",
          "published_date": "17 Nov 2024",
          "video_url": "https://www.youtube.com/embed/HNIzgEnF8gQ",
          "hd_video_url": "https://www.youtube.com/embed/HNIzgEnF8gQ",
          "thumbnail": "https://i.ytimg.com/vi/HNIzgEnF8gQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 72 || घूर्णन गति - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/41baa6c0-2dd0-4bb4-837b-d04604164733.pdf"
            }
          ]
        },
        {
          "serial": 73,
          "title": "व्याख्यान- 73 || घूर्णन गति - 4",
          "published_date": "18 Nov 2024",
          "video_url": "https://www.youtube.com/embed/93OyfB3_t8s",
          "hd_video_url": "https://www.youtube.com/embed/93OyfB3_t8s",
          "thumbnail": "https://i.ytimg.com/vi/93OyfB3_t8s/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 73 || घूर्णन गति - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c3073e50-cf46-4487-84f1-8e36e1a8bf37.pdf"
            }
          ]
        },
        {
          "serial": 74,
          "title": "व्याख्यान- 74 || घूर्णन गति - 5",
          "published_date": "19 Nov 2024",
          "video_url": "https://www.youtube.com/embed/jTcXA20Zk80",
          "hd_video_url": "https://www.youtube.com/embed/jTcXA20Zk80",
          "thumbnail": "https://i.ytimg.com/vi/jTcXA20Zk80/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 74 || घूर्णन गति - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/088ada3a-8f22-446f-a914-e513ddf464a4.pdf"
            }
          ]
        },
        {
          "serial": 75,
          "title": "व्याख्यान- 75 || घूर्णन गति - 6",
          "published_date": "19 Nov 2024",
          "video_url": "https://www.youtube.com/embed/RRmTTtigyHs",
          "hd_video_url": "https://www.youtube.com/embed/RRmTTtigyHs",
          "thumbnail": "https://i.ytimg.com/vi/RRmTTtigyHs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 75 || घूर्णन गति - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8352c455-1e19-48d0-aa66-a7b0806f9f2e.pdf"
            }
          ]
        },
        {
          "serial": 76,
          "title": "व्याख्यान- 76 || घूर्णन गति - 7",
          "published_date": "20 Nov 2024",
          "video_url": "https://www.youtube.com/embed/AGKzSlTQ-G0",
          "hd_video_url": "https://www.youtube.com/embed/AGKzSlTQ-G0",
          "thumbnail": "https://i.ytimg.com/vi/AGKzSlTQ-G0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 76 || घूर्णन गति - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5414c410-a2cb-4ce8-a27e-53b99d2ca4a9.pdf"
            }
          ]
        },
        {
          "serial": 77,
          "title": "व्याख्यान- 77 || घूर्णन गति - 8",
          "published_date": "21 Nov 2024",
          "video_url": "https://www.youtube.com/embed/M9V3iaTpEu0",
          "hd_video_url": "https://www.youtube.com/embed/M9V3iaTpEu0",
          "thumbnail": "https://i.ytimg.com/vi/M9V3iaTpEu0/default.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 77 || घूर्णन गति - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2ae37990-c4f1-4ae6-9e5b-04c26b582d4e.pdf"
            }
          ]
        },
        {
          "serial": 78,
          "title": "व्याख्यान- 78 || घूर्णन गति - 9",
          "published_date": "21 Nov 2024",
          "video_url": "https://www.youtube.com/embed/-f1gQphvSZk",
          "hd_video_url": "https://www.youtube.com/embed/-f1gQphvSZk",
          "thumbnail": "https://i.ytimg.com/vi/-f1gQphvSZk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 78 || घूर्णन गति - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/74b8781e-25ac-4767-a48b-09007ca9cb35.pdf"
            }
          ]
        },
        {
          "serial": 79,
          "title": "व्याख्यान- 79 || गुरुत्वाकर्षण - 1",
          "published_date": "22 Nov 2024",
          "video_url": "https://www.youtube.com/embed/fDu33cHvg3w",
          "hd_video_url": "https://www.youtube.com/embed/fDu33cHvg3w",
          "thumbnail": "https://i.ytimg.com/vi/fDu33cHvg3w/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 79 || गुरुत्वाकर्षण - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b4953a02-1fff-4395-85e8-847d2ac07426.pdf"
            }
          ]
        },
        {
          "serial": 80,
          "title": "व्याख्यान- 80 || गुरुत्वाकर्षण - 2",
          "published_date": "23 Nov 2024",
          "video_url": "https://www.youtube.com/embed/TZmU62fW8L8",
          "hd_video_url": "https://www.youtube.com/embed/TZmU62fW8L8",
          "thumbnail": "https://i.ytimg.com/vi/TZmU62fW8L8/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 80 || गुरुत्वाकर्षण - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d10325f7-f010-4bbe-87a3-ea76bdc3c39c.pdf"
            }
          ]
        },
        {
          "serial": 81,
          "title": "व्याख्यान- 81 || गुरुत्वाकर्षण - 3",
          "published_date": "25 Nov 2024",
          "video_url": "https://www.youtube.com/embed/SVt3TuoXqwc",
          "hd_video_url": "https://www.youtube.com/embed/SVt3TuoXqwc",
          "thumbnail": "https://i.ytimg.com/vi/SVt3TuoXqwc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 81 || गुरुत्वाकर्षण - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/985a4326-64e3-4445-ac01-df5afe38a535.pdf"
            }
          ]
        },
        {
          "serial": 82,
          "title": "व्याख्यान- 82 || गुरुत्वाकर्षण - 4",
          "published_date": "26 Nov 2024",
          "video_url": "https://www.youtube.com/embed/rsaqaxn_pAE",
          "hd_video_url": "https://www.youtube.com/embed/rsaqaxn_pAE",
          "thumbnail": "https://i.ytimg.com/vi/rsaqaxn_pAE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 82 || गुरुत्वाकर्षण - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2180ad8f-a0f1-4a98-ae6d-f97961984fda.pdf"
            }
          ]
        },
        {
          "serial": 83,
          "title": "व्याख्यान- 83 || गुरुत्वाकर्षण - 5",
          "published_date": "26 Nov 2024",
          "video_url": "https://www.youtube.com/embed/3KlUTo8EDnI",
          "hd_video_url": "https://www.youtube.com/embed/3KlUTo8EDnI",
          "thumbnail": "https://i.ytimg.com/vi/3KlUTo8EDnI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 83 || गुरुत्वाकर्षण - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2b4651d0-38a7-43e4-9350-722c05637e32.pdf"
            }
          ]
        },
        {
          "serial": 84,
          "title": "व्याख्यान- 84 || गुरुत्वाकर्षण - 6",
          "published_date": "27 Nov 2024",
          "video_url": "https://www.youtube.com/embed/DhfOlS5A9oQ",
          "hd_video_url": "https://www.youtube.com/embed/DhfOlS5A9oQ",
          "thumbnail": "https://i.ytimg.com/vi/DhfOlS5A9oQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 84 || गुरुत्वाकर्षण - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/570075f1-6060-4e52-8bef-e8f2b829e42a.pdf"
            }
          ]
        },
        {
          "serial": 85,
          "title": "व्याख्यान- 85 || गुरुत्वाकर्षण - 7",
          "published_date": "28 Nov 2024",
          "video_url": "https://www.youtube.com/embed/yFb9fADjVkY",
          "hd_video_url": "https://www.youtube.com/embed/yFb9fADjVkY",
          "thumbnail": "https://i.ytimg.com/vi/yFb9fADjVkY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 85 || गुरुत्वाकर्षण - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3e9ff150-4c3a-4e09-b531-4422795d1eb1.pdf"
            }
          ]
        },
        {
          "serial": 86,
          "title": "व्याख्यान- 86 || गुरुत्वाकर्षण - 8",
          "published_date": "29 Nov 2024",
          "video_url": "https://www.youtube.com/embed/VEsshTlbpT4",
          "hd_video_url": "https://www.youtube.com/embed/VEsshTlbpT4",
          "thumbnail": "https://i.ytimg.com/vi/VEsshTlbpT4/default.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 86 || गुरुत्वाकर्षण - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4b13244c-ffa0-4521-9e6f-6ee5f5537a84.pdf"
            }
          ]
        },
        {
          "serial": 87,
          "title": "व्याख्यान- 87 || गुरुत्वाकर्षण - 9",
          "published_date": "30 Nov 2024",
          "video_url": "https://www.youtube.com/embed/t11fR-jdXBc",
          "hd_video_url": "https://www.youtube.com/embed/t11fR-jdXBc",
          "thumbnail": "https://i.ytimg.com/vi/t11fR-jdXBc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 87 || गुरुत्वाकर्षण - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c7af3054-f366-4be5-aee0-3287050f97a8.pdf"
            }
          ]
        },
        {
          "serial": 88,
          "title": "व्याख्यान- 88 || गुरुत्वाकर्षण - 10",
          "published_date": "02 Dec 2024",
          "video_url": "https://www.youtube.com/embed/4SHhb0Qb3oY",
          "hd_video_url": "https://www.youtube.com/embed/4SHhb0Qb3oY",
          "thumbnail": "https://i.ytimg.com/vi/4SHhb0Qb3oY/default.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 88 || गुरुत्वाकर्षण - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/99e72322-cf57-4619-8dde-690f0a20bde1.pdf"
            }
          ]
        },
        {
          "serial": 89,
          "title": "व्याख्यान- 89 || गुरुत्वाकर्षण - 11",
          "published_date": "03 Dec 2024",
          "video_url": "https://www.youtube.com/embed/R9Bf4WfBzO8",
          "hd_video_url": "https://www.youtube.com/embed/R9Bf4WfBzO8",
          "thumbnail": "https://i.ytimg.com/vi/R9Bf4WfBzO8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 89 || गुरुत्वाकर्षण - 11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4fdc17f1-921a-4cad-8ae8-67bc8eafce3a.pdf"
            }
          ]
        },
        {
          "serial": 90,
          "title": "व्याख्यान- 90 || ठोसों के यांत्रिक गुण - 1",
          "published_date": "03 Dec 2024",
          "video_url": "https://www.youtube.com/embed/UJzw9cQEugs",
          "hd_video_url": "https://www.youtube.com/embed/UJzw9cQEugs",
          "thumbnail": "https://i.ytimg.com/vi/UJzw9cQEugs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 90 || ठोसों के यांत्रिक गुण - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e89212c8-c220-4c53-992c-d75a757fd5d7.pdf"
            }
          ]
        },
        {
          "serial": 91,
          "title": "व्याख्यान- 91 || ठोसों के यांत्रिक गुण  - 2",
          "published_date": "04 Dec 2024",
          "video_url": "https://www.youtube.com/embed/bk3zqCQ4O44",
          "hd_video_url": "https://www.youtube.com/embed/bk3zqCQ4O44",
          "thumbnail": "https://i.ytimg.com/vi/bk3zqCQ4O44/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 91 || ठोसों के यांत्रिक गुण - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/495ed5c7-d5df-44c6-9f98-fcbb19a33e85.pdf"
            }
          ]
        },
        {
          "serial": 92,
          "title": "व्याख्यान- 92 || ठोसों के यांत्रिक गुण - 3",
          "published_date": "05 Dec 2024",
          "video_url": "https://www.youtube.com/embed/XKzqOVpSu6Y",
          "hd_video_url": "https://www.youtube.com/embed/XKzqOVpSu6Y",
          "thumbnail": "https://i.ytimg.com/vi/XKzqOVpSu6Y/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 92 || ठोसों के यांत्रिक गुण - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/133cdc75-ab69-434e-a414-6ac9064b6a29.pdf"
            }
          ]
        },
        {
          "serial": 93,
          "title": "व्याख्यान- 93 || ठोसों के यांत्रिक गुण - 4",
          "published_date": "05 Dec 2024",
          "video_url": "https://www.youtube.com/embed/mtw1yCF88NA",
          "hd_video_url": "https://www.youtube.com/embed/mtw1yCF88NA",
          "thumbnail": "https://i.ytimg.com/vi/mtw1yCF88NA/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 93  ठोसों के यांत्रिक गुण - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/31d8db79-6628-4b34-90ae-b9c171730371.pdf"
            }
          ]
        },
        {
          "serial": 94,
          "title": "व्याख्यान- 94 || ठोसों के यांत्रिक गुण - 5",
          "published_date": "06 Dec 2024",
          "video_url": "https://www.youtube.com/embed/NBZBDy2Xxdc",
          "hd_video_url": "https://www.youtube.com/embed/NBZBDy2Xxdc",
          "thumbnail": "https://i.ytimg.com/vi/NBZBDy2Xxdc/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 94  ठोसों के यांत्रिक गुण - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/95a9353c-df05-442e-a43c-c801928ff2f3.pdf"
            }
          ]
        },
        {
          "serial": 95,
          "title": "व्याख्यान- 95 ||  पदार्थ के तापीय गुण - 1",
          "published_date": "07 Dec 2024",
          "video_url": "https://www.youtube.com/embed/YUQzZxzzve8",
          "hd_video_url": "https://www.youtube.com/embed/YUQzZxzzve8",
          "thumbnail": "https://i.ytimg.com/vi/YUQzZxzzve8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 95 || द्रव्य के तापीय गुण  - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0beb0ced-25f1-4799-b28b-bbb3b086f43a.pdf"
            }
          ]
        },
        {
          "serial": 96,
          "title": "व्याख्यान- 96 || पदार्थ के तापीय गुण - 2",
          "published_date": "09 Dec 2024",
          "video_url": "https://www.youtube.com/embed/tbVNKm0hisE",
          "hd_video_url": "https://www.youtube.com/embed/tbVNKm0hisE",
          "thumbnail": "https://i.ytimg.com/vi/tbVNKm0hisE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 96 || पदार्थ के तापीय गुण - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d2b07c47-2d04-48d1-ab6d-d11b03336aa0.pdf"
            }
          ]
        },
        {
          "serial": 97,
          "title": "व्याख्यान- 97 || पदार्थ के तापीय गुण - 3",
          "published_date": "10 Dec 2024",
          "video_url": "https://www.youtube.com/embed/r0r_-2E_NIU",
          "hd_video_url": "https://www.youtube.com/embed/r0r_-2E_NIU",
          "thumbnail": "https://i.ytimg.com/vi/r0r_-2E_NIU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 97 || पदार्थ के तापीय गुण - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/75af731d-c7d5-4a8c-90c0-f7ffffabaf10.pdf"
            }
          ]
        },
        {
          "serial": 98,
          "title": "व्याख्यान- 98 || पदार्थ के तापीय गुण - 4",
          "published_date": "10 Dec 2024",
          "video_url": "https://www.youtube.com/embed/xL3nCKW7kfg",
          "hd_video_url": "https://www.youtube.com/embed/xL3nCKW7kfg",
          "thumbnail": "https://i.ytimg.com/vi/xL3nCKW7kfg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 98 || पदार्थ के तापीय गुण - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/62f8b814-70bf-4e3d-9b53-52341c498478.pdf"
            }
          ]
        },
        {
          "serial": 99,
          "title": "व्याख्यान- 99 || पदार्थ के तापीय गुण - 5",
          "published_date": "11 Dec 2024",
          "video_url": "https://www.youtube.com/embed/0JMePJ19s1k",
          "hd_video_url": "https://www.youtube.com/embed/0JMePJ19s1k",
          "thumbnail": "https://i.ytimg.com/vi/0JMePJ19s1k/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 99 || पदार्थ के तापीय गुण - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4193dafa-a58a-4b21-9120-1235ce907921.pdf"
            }
          ]
        },
        {
          "serial": 100,
          "title": "व्याख्यान- 100 || पदार्थ के तापीय गुण - 6",
          "published_date": "11 Dec 2024",
          "video_url": "https://www.youtube.com/embed/dYd8LLpNSec",
          "hd_video_url": "https://www.youtube.com/embed/dYd8LLpNSec",
          "thumbnail": "https://i.ytimg.com/vi/dYd8LLpNSec/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 100 || पदार्थ के तापीय गुण - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e750134c-e5f1-472f-9bf3-4336ce849ffa.pdf"
            }
          ]
        },
        {
          "serial": 101,
          "title": "व्याख्यान- 101 || पदार्थ के तापीय गुण - 7",
          "published_date": "16 Dec 2024",
          "video_url": "https://www.youtube.com/embed/QQm3TSHYmcI",
          "hd_video_url": "https://www.youtube.com/embed/QQm3TSHYmcI",
          "thumbnail": "https://i.ytimg.com/vi/QQm3TSHYmcI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 101 || पदार्थ के तापीय गुण - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2995c56f-0f2b-4a6a-a324-a89fb9badd09.pdf"
            }
          ]
        },
        {
          "serial": 102,
          "title": "व्याख्यान- 102 || पदार्थ के तापीय गुण - 8",
          "published_date": "17 Dec 2024",
          "video_url": "https://www.youtube.com/embed/x07YDjaihJM",
          "hd_video_url": "https://www.youtube.com/embed/x07YDjaihJM",
          "thumbnail": "https://i.ytimg.com/vi/x07YDjaihJM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 102 || पदार्थ के तापीय गुण - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1c24a925-67db-4250-9cde-dfd5dda7b195.pdf"
            }
          ]
        },
        {
          "serial": 103,
          "title": "व्याख्यान- 103 || पदार्थ के तापीय गुण - 9",
          "published_date": "17 Dec 2024",
          "video_url": "https://www.youtube.com/embed/1J1uj8q04Rs",
          "hd_video_url": "https://www.youtube.com/embed/1J1uj8q04Rs",
          "thumbnail": "https://i.ytimg.com/vi/1J1uj8q04Rs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 103 || पदार्थ के तापीय गुण - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4efa84bd-47e2-434a-9fea-579e4e9f70ae.pdf"
            }
          ]
        },
        {
          "serial": 104,
          "title": "व्याख्यान- 104 || पदार्थ के तापीय गुण - 10",
          "published_date": "18 Dec 2024",
          "video_url": "https://www.youtube.com/embed/6SKmKsZJY8E",
          "hd_video_url": "https://www.youtube.com/embed/6SKmKsZJY8E",
          "thumbnail": "https://i.ytimg.com/vi/6SKmKsZJY8E/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 104 || पदार्थ के तापीय गुण - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/92becbcd-5c48-40ff-b8a1-869073bce1a8.pdf"
            }
          ]
        },
        {
          "serial": 105,
          "title": "व्याख्यान- 105 || पदार्थ के तापीय गुण - 11",
          "published_date": "19 Dec 2024",
          "video_url": "https://www.youtube.com/embed/aDGSZjW8Jac",
          "hd_video_url": "https://www.youtube.com/embed/aDGSZjW8Jac",
          "thumbnail": "https://i.ytimg.com/vi/aDGSZjW8Jac/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 105 || पदार्थ के तापीय गुण - 11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9957904c-ef0e-4cdc-9ba0-e69b8d30437d.pdf"
            }
          ]
        },
        {
          "serial": 106,
          "title": "व्याख्यान- 106 || पदार्थ के तापीय गुण - 12",
          "published_date": "20 Dec 2024",
          "video_url": "https://www.youtube.com/embed/KThlpcD6G1w",
          "hd_video_url": "https://www.youtube.com/embed/KThlpcD6G1w",
          "thumbnail": "https://i.ytimg.com/vi/KThlpcD6G1w/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 106 || पदार्थ के तापीय गुण - 12",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/747d53f4-1759-45b9-aeec-35fa07732139.pdf"
            }
          ]
        },
        {
          "serial": 107,
          "title": "व्याख्यान- 107 || पदार्थ के तापीय गुण - 13",
          "published_date": "21 Dec 2024",
          "video_url": "https://www.youtube.com/embed/HGlfkfUwKto",
          "hd_video_url": "https://www.youtube.com/embed/HGlfkfUwKto",
          "thumbnail": "https://i.ytimg.com/vi/HGlfkfUwKto/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 107 || पदार्थ के तापीय गुण - 13",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2043e97f-00c3-43f4-866f-e44ee554389c.pdf"
            }
          ]
        },
        {
          "serial": 108,
          "title": "व्याख्यान- 108 || ऊष्मागतिकी  - 1",
          "published_date": "23 Dec 2024",
          "video_url": "https://www.youtube.com/embed/3f-vdSSptPE",
          "hd_video_url": "https://www.youtube.com/embed/3f-vdSSptPE",
          "thumbnail": "https://i.ytimg.com/vi/3f-vdSSptPE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 108 || ऊष्मागतिकी  - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1cab9097-0c3b-4c47-9084-bf3f4fe33962.pdf"
            }
          ]
        },
        {
          "serial": 109,
          "title": "व्याख्यान- 109 || ऊष्मागतिकी - 2",
          "published_date": "24 Dec 2024",
          "video_url": "https://www.youtube.com/embed/wwczFMFr0Mo",
          "hd_video_url": "https://www.youtube.com/embed/wwczFMFr0Mo",
          "thumbnail": "https://i.ytimg.com/vi/wwczFMFr0Mo/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 109 || ऊष्मागतिकी - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/534dcb75-d496-45db-80f1-3980a499fd83.pdf"
            }
          ]
        },
        {
          "serial": 110,
          "title": "व्याख्यान- 110 || ऊष्मागतिकी - 3",
          "published_date": "24 Dec 2024",
          "video_url": "https://www.youtube.com/embed/efGCMBXi2xc",
          "hd_video_url": "https://www.youtube.com/embed/efGCMBXi2xc",
          "thumbnail": "https://i.ytimg.com/vi/efGCMBXi2xc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 110 || ऊष्मागतिकी - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4ff7d07a-4153-4e92-9f1f-276a9aaeaea4.pdf"
            }
          ]
        },
        {
          "serial": 111,
          "title": "व्याख्यान- 111 || ऊष्मागतिकी - 4",
          "published_date": "26 Dec 2024",
          "video_url": "https://www.youtube.com/embed/NNb9Fbqu8V4",
          "hd_video_url": "https://www.youtube.com/embed/NNb9Fbqu8V4",
          "thumbnail": "https://i.ytimg.com/vi/NNb9Fbqu8V4/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 111 || ऊष्मागतिकी - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7caa0708-89d3-4b91-a36f-0b1d27172964.pdf"
            }
          ]
        },
        {
          "serial": 112,
          "title": "व्याख्यान- 112 || ऊष्मागतिकी - 5",
          "published_date": "27 Dec 2024",
          "video_url": "https://www.youtube.com/embed/1pqNTk27O2I",
          "hd_video_url": "https://www.youtube.com/embed/1pqNTk27O2I",
          "thumbnail": "https://i.ytimg.com/vi/1pqNTk27O2I/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 112 || ऊष्मागतिकी - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4cbd339a-45e2-4959-87e5-2acd8db83e37.pdf"
            }
          ]
        },
        {
          "serial": 113,
          "title": "व्याख्यान- 113 || ऊष्मागतिकी - 6",
          "published_date": "28 Dec 2024",
          "video_url": "https://www.youtube.com/embed/CDNK7fFgubM",
          "hd_video_url": "https://www.youtube.com/embed/CDNK7fFgubM",
          "thumbnail": "https://i.ytimg.com/vi/CDNK7fFgubM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 113 || ऊष्मागतिकी - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ac3c5133-2204-48cd-97c3-8911b1293bef.pdf"
            }
          ]
        },
        {
          "serial": 114,
          "title": "व्याख्यान- 114 || ऊष्मागतिकी - 7",
          "published_date": "29 Dec 2024",
          "video_url": "https://www.youtube.com/embed/ZpytAw3wH68",
          "hd_video_url": "https://www.youtube.com/embed/ZpytAw3wH68",
          "thumbnail": "https://i.ytimg.com/vi/ZpytAw3wH68/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 114 || ऊष्मागतिकी - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ec405733-f6df-4943-ae32-efa8343f6d2e.pdf"
            }
          ]
        },
        {
          "serial": 115,
          "title": "व्याख्यान- 115 || ऊष्मागतिकी - 8",
          "published_date": "30 Dec 2024",
          "video_url": "https://www.youtube.com/embed/kPctikMed_c",
          "hd_video_url": "https://www.youtube.com/embed/kPctikMed_c",
          "thumbnail": "https://i.ytimg.com/vi/kPctikMed_c/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 115 || ऊष्मागतिकी - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/030636b5-a6ef-4407-95a4-a537f2100ac5.pdf"
            }
          ]
        },
        {
          "serial": 116,
          "title": "व्याख्यान- 116 || ऊष्मागतिकी - 9",
          "published_date": "02 Jan 2025",
          "video_url": "https://www.youtube.com/embed/viDRcbItjhs",
          "hd_video_url": "https://www.youtube.com/embed/viDRcbItjhs",
          "thumbnail": "https://i.ytimg.com/vi/viDRcbItjhs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 116 || ऊष्मागतिकी - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/45d54b19-7895-4cd1-9da6-a2843825f37c.pdf"
            }
          ]
        },
        {
          "serial": 117,
          "title": "व्याख्यान- 117 || सरल आवर्त गति - 1",
          "published_date": "03 Jan 2025",
          "video_url": "https://www.youtube.com/embed/gBCNAHKwKcs",
          "hd_video_url": "https://www.youtube.com/embed/gBCNAHKwKcs",
          "thumbnail": "https://i.ytimg.com/vi/gBCNAHKwKcs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 117 || सरल आवर्त गति - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fa45a55e-a8a0-41e6-81dd-031a1a6a7677.pdf"
            }
          ]
        },
        {
          "serial": 118,
          "title": "व्याख्यान- 118 || सरल आवर्त गति - 2",
          "published_date": "04 Jan 2025",
          "video_url": "https://www.youtube.com/embed/dFYpJYy6JiI",
          "hd_video_url": "https://www.youtube.com/embed/dFYpJYy6JiI",
          "thumbnail": "https://i.ytimg.com/vi/dFYpJYy6JiI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 118 || सरल आवर्त गति - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c0f1b9f4-673b-4184-9861-fb99d54cf803.pdf"
            }
          ]
        },
        {
          "serial": 119,
          "title": "व्याख्यान- 119 || सरल आवर्त गति - 3",
          "published_date": "04 Jan 2025",
          "video_url": "https://www.youtube.com/embed/Mg651uYWql0",
          "hd_video_url": "https://www.youtube.com/embed/Mg651uYWql0",
          "thumbnail": "https://i.ytimg.com/vi/Mg651uYWql0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 119 || सरल आवर्त गति - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c1747dc1-e05f-443a-8997-ab80cb5ba355.pdf"
            }
          ]
        },
        {
          "serial": 120,
          "title": "व्याख्यान- 120 || सरल आवर्त गति - 4",
          "published_date": "06 Jan 2025",
          "video_url": "https://www.youtube.com/embed/Q9bi9HNy92w",
          "hd_video_url": "https://www.youtube.com/embed/Q9bi9HNy92w",
          "thumbnail": "https://i.ytimg.com/vi/Q9bi9HNy92w/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 120 || सरल आवर्त गति - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/97c5f2f3-16f9-45e4-b0e2-c5051c9ab8e3.pdf"
            }
          ]
        },
        {
          "serial": 121,
          "title": "व्याख्यान- 121 || सरल आवर्त गति - 5",
          "published_date": "07 Jan 2025",
          "video_url": "https://www.youtube.com/embed/QHlmtY0Pv5U",
          "hd_video_url": "https://www.youtube.com/embed/QHlmtY0Pv5U",
          "thumbnail": "https://i.ytimg.com/vi/QHlmtY0Pv5U/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 121 || सरल आवर्त गति - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/eba3a3f1-a5be-414b-b66f-7c7da75ee45c.pdf"
            }
          ]
        },
        {
          "serial": 122,
          "title": "व्याख्यान- 122 || सरल आवर्त गति - 6",
          "published_date": "08 Jan 2025",
          "video_url": "https://www.youtube.com/embed/_zhsaVBzYkA",
          "hd_video_url": "https://www.youtube.com/embed/_zhsaVBzYkA",
          "thumbnail": "https://i.ytimg.com/vi/_zhsaVBzYkA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 122 || सरल आवर्त गति - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/63f2d662-a836-4a2a-8c5d-8b466447c9cf.pdf"
            }
          ]
        },
        {
          "serial": 123,
          "title": "व्याख्यान- 123 || सरल आवर्त गति - 7",
          "published_date": "09 Jan 2025",
          "video_url": "https://www.youtube.com/embed/kh2GxpsDmoI",
          "hd_video_url": "https://www.youtube.com/embed/kh2GxpsDmoI",
          "thumbnail": "https://i.ytimg.com/vi/kh2GxpsDmoI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 123 || सरल आवर्त गति - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d15cad95-f432-4a52-ad5a-93cdfbb724fc.pdf"
            }
          ]
        },
        {
          "serial": 124,
          "title": "व्याख्यान- 124 ||  तरंग - 1",
          "published_date": "11 Jan 2025",
          "video_url": "https://www.youtube.com/embed/TUsBB-1xxOE",
          "hd_video_url": "https://www.youtube.com/embed/TUsBB-1xxOE",
          "thumbnail": "https://i.ytimg.com/vi/TUsBB-1xxOE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 124 || तरंग - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a60f4f0a-1485-4c31-916c-52ccb810f82b.pdf"
            }
          ]
        },
        {
          "serial": 125,
          "title": "व्याख्यान- 125 ||  तरंग - 2",
          "published_date": "13 Jan 2025",
          "video_url": "https://www.youtube.com/embed/15R_WlAN5D0",
          "hd_video_url": "https://www.youtube.com/embed/15R_WlAN5D0",
          "thumbnail": "https://i.ytimg.com/vi/15R_WlAN5D0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 125 ||  तरंग - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/65691d9d-4b79-4ce3-be8e-e1843b7899df.pdf"
            }
          ]
        },
        {
          "serial": 126,
          "title": "व्याख्यान- 126 || तरंग - 3",
          "published_date": "14 Jan 2025",
          "video_url": "https://www.youtube.com/embed/AKUr9vBqm4g",
          "hd_video_url": "https://www.youtube.com/embed/AKUr9vBqm4g",
          "thumbnail": "https://i.ytimg.com/vi/AKUr9vBqm4g/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 126  तरंग - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/23272318-3cbf-4f9d-a62d-50d80ec5e5ee.pdf"
            }
          ]
        },
        {
          "serial": 127,
          "title": "व्याख्यान- 127 || तरंग - 4",
          "published_date": "15 Jan 2025",
          "video_url": "https://www.youtube.com/embed/wvQ3oOlJrQ8",
          "hd_video_url": "https://www.youtube.com/embed/wvQ3oOlJrQ8",
          "thumbnail": "https://i.ytimg.com/vi/wvQ3oOlJrQ8/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 127 तरंग - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0a9c0769-5853-4b8c-a222-548607bc0c5d.pdf"
            }
          ]
        },
        {
          "serial": 128,
          "title": "व्याख्यान- 128 || तरंग - 5",
          "published_date": "16 Jan 2025",
          "video_url": "https://www.youtube.com/embed/t2XfMqf6nkI",
          "hd_video_url": "https://www.youtube.com/embed/t2XfMqf6nkI",
          "thumbnail": "https://i.ytimg.com/vi/t2XfMqf6nkI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 128 || तरंग - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c7bafdd0-5f6c-41f8-8463-39ff75d61905.pdf"
            }
          ]
        },
        {
          "serial": 129,
          "title": "व्याख्यान- 129 || तरंग - 6",
          "published_date": "17 Jan 2025",
          "video_url": "https://www.youtube.com/embed/s8vLm4PBe10",
          "hd_video_url": "https://www.youtube.com/embed/s8vLm4PBe10",
          "thumbnail": "https://i.ytimg.com/vi/s8vLm4PBe10/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 129 || तरंग - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/940ed7c3-24db-4be9-97dc-f9b1de51f6f6.pdf"
            }
          ]
        },
        {
          "serial": 130,
          "title": "व्याख्यान- 130 || तरंग - 7",
          "published_date": "18 Jan 2025",
          "video_url": "https://www.youtube.com/embed/mBOYKG2kJ2Q",
          "hd_video_url": "https://www.youtube.com/embed/mBOYKG2kJ2Q",
          "thumbnail": "https://i.ytimg.com/vi/mBOYKG2kJ2Q/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 130 || तरंग - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b8dea858-c237-46f8-8374-97121e90d4fa.pdf"
            }
          ]
        },
        {
          "serial": 131,
          "title": "व्याख्यान- 131 || तरंग - 8",
          "published_date": "20 Jan 2025",
          "video_url": "https://www.youtube.com/embed/fDf1Vm3Po0w",
          "hd_video_url": "https://www.youtube.com/embed/fDf1Vm3Po0w",
          "thumbnail": "https://i.ytimg.com/vi/fDf1Vm3Po0w/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 131 तरंग - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/94f31f6a-2a6c-4403-8a25-9316861441aa.pdf"
            }
          ]
        },
        {
          "serial": 132,
          "title": "व्याख्यान- 132 || तरंग - 9",
          "published_date": "21 Jan 2025",
          "video_url": "https://www.youtube.com/embed/P5VHLT9pd_Q",
          "hd_video_url": "https://www.youtube.com/embed/P5VHLT9pd_Q",
          "thumbnail": "https://i.ytimg.com/vi/P5VHLT9pd_Q/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 132  तरंग - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/57529e09-01d1-466d-87d0-12a91c13fb4c.pdf"
            }
          ]
        },
        {
          "serial": 133,
          "title": "व्याख्यान- 133 || तरंग - 10",
          "published_date": "22 Jan 2025",
          "video_url": "https://www.youtube.com/embed/kNZGZQWrloA",
          "hd_video_url": "https://www.youtube.com/embed/kNZGZQWrloA",
          "thumbnail": "https://i.ytimg.com/vi/kNZGZQWrloA/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 133  तरंग - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/35359f44-c077-42d9-a6f0-eba00ed7d503.pdf"
            }
          ]
        },
        {
          "serial": 134,
          "title": "व्याख्यान- 134 || तरंग - 11",
          "published_date": "23 Jan 2025",
          "video_url": "https://www.youtube.com/embed/n_BgdFDNXxI",
          "hd_video_url": "https://www.youtube.com/embed/n_BgdFDNXxI",
          "thumbnail": "https://i.ytimg.com/vi/n_BgdFDNXxI/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 134 || तरंग - 11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c4de4a3d-68fe-4b38-8ea2-8aa803014625.pdf"
            }
          ]
        },
        {
          "serial": 135,
          "title": "व्याख्यान- 135 || तरंग - 12",
          "published_date": "24 Jan 2025",
          "video_url": "https://www.youtube.com/embed/7_zKoSoKkoM",
          "hd_video_url": "https://www.youtube.com/embed/7_zKoSoKkoM",
          "thumbnail": "https://i.ytimg.com/vi/7_zKoSoKkoM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 135 || तरंग - 12",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a8a95cc6-4b74-4931-bea3-2c103200d76c.pdf"
            }
          ]
        },
        {
          "serial": 136,
          "title": "व्याख्यान- 136 || विद्युत आवेश और क्षेत्र - 1",
          "published_date": "25 Jan 2025",
          "video_url": "https://www.youtube.com/embed/VsMyjbl2YkE",
          "hd_video_url": "https://www.youtube.com/embed/VsMyjbl2YkE",
          "thumbnail": "https://i.ytimg.com/vi/VsMyjbl2YkE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 136 || विद्युत आवेश और क्षेत्र - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f8f5a0fb-9e45-48f5-bc9f-ffe718e8c847.pdf"
            }
          ]
        },
        {
          "serial": 137,
          "title": "व्याख्यान- 137 || विद्युत आवेश और क्षेत्र- 2",
          "published_date": "27 Jan 2025",
          "video_url": "https://www.youtube.com/embed/t1xRFvRI_rg",
          "hd_video_url": "https://www.youtube.com/embed/t1xRFvRI_rg",
          "thumbnail": "https://i.ytimg.com/vi/t1xRFvRI_rg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 137 || विद्युत आवेश और क्षेत्र- 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6a4de0a1-b0dc-4ccf-8f8a-b7fe78a9d134.pdf"
            }
          ]
        },
        {
          "serial": 138,
          "title": "व्याख्यान- 138 || विद्युत आवेश और क्षेत्र- 3",
          "published_date": "28 Jan 2025",
          "video_url": "https://www.youtube.com/embed/8WqA2WguoVY",
          "hd_video_url": "https://www.youtube.com/embed/8WqA2WguoVY",
          "thumbnail": "https://i.ytimg.com/vi/8WqA2WguoVY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 138 || विद्युत आवेश और क्षेत्र - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5476f348-ad21-4703-a906-db5db5065c4b.pdf"
            }
          ]
        },
        {
          "serial": 139,
          "title": "व्याख्यान- 139 || विद्युत आवेश और क्षेत्र - 4",
          "published_date": "29 Jan 2025",
          "video_url": "https://www.youtube.com/embed/_e2W0bfGY7g",
          "hd_video_url": "https://www.youtube.com/embed/_e2W0bfGY7g",
          "thumbnail": "https://i.ytimg.com/vi/_e2W0bfGY7g/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 139 || विद्युत आवेश और क्षेत्र - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e88f4298-eaa5-4b2e-90ca-bdca9cfcf58c.pdf"
            }
          ]
        },
        {
          "serial": 140,
          "title": "व्याख्यान- 140 || विद्युत आवेश और क्षेत्र - 5",
          "published_date": "30 Jan 2025",
          "video_url": "https://www.youtube.com/embed/ubaNV8uQPmg",
          "hd_video_url": "https://www.youtube.com/embed/ubaNV8uQPmg",
          "thumbnail": "https://i.ytimg.com/vi/ubaNV8uQPmg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 140|| विद्युत आवेश और क्षेत्र - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/aa23036e-af69-4cc4-80ad-2f103c1f6463.pdf"
            }
          ]
        },
        {
          "serial": 141,
          "title": "व्याख्यान- 141 || विद्युत आवेश और क्षेत्र - 6",
          "published_date": "31 Jan 2025",
          "video_url": "https://www.youtube.com/embed/wZoV14bPAMs",
          "hd_video_url": "https://www.youtube.com/embed/wZoV14bPAMs",
          "thumbnail": "https://i.ytimg.com/vi/wZoV14bPAMs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 141 || विद्युत आवेश और क्षेत्र - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f68a000f-0503-40fd-ba11-1dda5ace4b5c.pdf"
            }
          ]
        },
        {
          "serial": 142,
          "title": "व्याख्यान- 142 || विद्युत आवेश और क्षेत्र - 7",
          "published_date": "01 Feb 2025",
          "video_url": "https://www.youtube.com/embed/wWI412kD6Ww",
          "hd_video_url": "https://www.youtube.com/embed/wWI412kD6Ww",
          "thumbnail": "https://i.ytimg.com/vi/wWI412kD6Ww/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 142 || विद्युत आवेश और क्षेत्र - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/bd280abf-a884-4551-bfec-ccbf0fa308d4.pdf"
            }
          ]
        },
        {
          "serial": 143,
          "title": "व्याख्यान- 143 || विद्युत आवेश और क्षेत्र - 8",
          "published_date": "02 Feb 2025",
          "video_url": "https://www.youtube.com/embed/Bh-ktqfpVXk",
          "hd_video_url": "https://www.youtube.com/embed/Bh-ktqfpVXk",
          "thumbnail": "https://i.ytimg.com/vi/Bh-ktqfpVXk/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 143 || विद्युत आवेश और क्षेत्र - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0b0439e0-1096-4089-92a4-566993708003.pdf"
            }
          ]
        },
        {
          "serial": 144,
          "title": "व्याख्यान- 144 || स्थिर वैधुत विभव तथा धारिता - 1",
          "published_date": "04 Feb 2025",
          "video_url": "https://www.youtube.com/embed/4jLUZXKFUOo",
          "hd_video_url": "https://www.youtube.com/embed/4jLUZXKFUOo",
          "thumbnail": "https://i.ytimg.com/vi/4jLUZXKFUOo/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 144 || स्थिर वैधुत विभव तथा धारिता - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/79b8c793-2da3-4352-929b-a61cc20d2493.pdf"
            }
          ]
        },
        {
          "serial": 145,
          "title": "व्याख्यान- 145 || स्थिर वैधुत विभव तथा धारिता - 2",
          "published_date": "05 Feb 2025",
          "video_url": "https://www.youtube.com/embed/9F-753bm7Jg",
          "hd_video_url": "https://www.youtube.com/embed/9F-753bm7Jg",
          "thumbnail": "https://i.ytimg.com/vi/9F-753bm7Jg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 145 || स्थिर वैधुत विभव तथा धारिता - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ada4dbed-a8bd-4dcb-b1d2-38fe5ed762df.pdf"
            }
          ]
        },
        {
          "serial": 146,
          "title": "व्याख्यान- 146 || स्थिर वैधुत विभव तथा धारिता - 3",
          "published_date": "06 Feb 2025",
          "video_url": "https://www.youtube.com/embed/vGi_Z-M24Bk",
          "hd_video_url": "https://www.youtube.com/embed/vGi_Z-M24Bk",
          "thumbnail": "https://i.ytimg.com/vi/vGi_Z-M24Bk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 146 || स्थिर वैधुत विभव तथा धारिता - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/284ad8bd-7b44-4d42-b0b9-1ef2c1cef9e1.pdf"
            }
          ]
        },
        {
          "serial": 147,
          "title": "व्याख्यान- 147 || स्थिर वैधुत विभव तथा धारिता - 4",
          "published_date": "06 Feb 2025",
          "video_url": "https://www.youtube.com/embed/fY3w0YJT1Xw",
          "hd_video_url": "https://www.youtube.com/embed/fY3w0YJT1Xw",
          "thumbnail": "https://i.ytimg.com/vi/fY3w0YJT1Xw/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 147 || स्थिर वैधुत विभव तथा धारिता - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/edcff044-24ef-47e9-bb7c-bb8577d25179.pdf"
            }
          ]
        },
        {
          "serial": 148,
          "title": "व्याख्यान- 148 || स्थिर वैधुत विभव तथा धारिता - 5",
          "published_date": "07 Feb 2025",
          "video_url": "https://www.youtube.com/embed/pQ_jeLXhUZA",
          "hd_video_url": "https://www.youtube.com/embed/pQ_jeLXhUZA",
          "thumbnail": "https://i.ytimg.com/vi/pQ_jeLXhUZA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 148 || स्थिर वैधुत विभव तथा धारिता - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b4b8d206-b831-40d4-b9c3-adc91db6056f.pdf"
            }
          ]
        },
        {
          "serial": 149,
          "title": "व्याख्यान- 149 || स्थिर वैधुत विभव तथा धारिता - 6",
          "published_date": "08 Feb 2025",
          "video_url": "https://www.youtube.com/embed/Yi_gPq8DfxM",
          "hd_video_url": "https://www.youtube.com/embed/Yi_gPq8DfxM",
          "thumbnail": "https://i.ytimg.com/vi/Yi_gPq8DfxM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 149 || स्थिर वैधुत विभव तथा धारिता - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a2747a01-d000-4685-8f78-67d7378ef885.pdf"
            }
          ]
        },
        {
          "serial": 150,
          "title": "व्याख्यान- 150 || स्थिर वैधुत विभव तथा धारिता - 7",
          "published_date": "10 Feb 2025",
          "video_url": "https://www.youtube.com/embed/Bz4WdO20AWY",
          "hd_video_url": "https://www.youtube.com/embed/Bz4WdO20AWY",
          "thumbnail": "https://i.ytimg.com/vi/Bz4WdO20AWY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 150 || स्थिर वैधुत विभव तथा धारिता - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/506f0b1e-b73a-45ea-be54-9a6560aa6e69.pdf"
            }
          ]
        },
        {
          "serial": 151,
          "title": "व्याख्यान- 151 || स्थिर वैधुत विभव तथा धारिता - 8",
          "published_date": "11 Feb 2025",
          "video_url": "https://www.youtube.com/embed/1TkOEuIwPmI",
          "hd_video_url": "https://www.youtube.com/embed/1TkOEuIwPmI",
          "thumbnail": "https://i.ytimg.com/vi/1TkOEuIwPmI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 151 || स्थिर वैधुत विभव तथा धारिता - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8f79c2e2-40f3-4a86-8fbb-04ac32f4e7c2.pdf"
            }
          ]
        },
        {
          "serial": 152,
          "title": "व्याख्यान- 152 || स्थिर वैधुत विभव तथा धारिता - 9",
          "published_date": "11 Feb 2025",
          "video_url": "https://www.youtube.com/embed/x_3XZGxnh4E",
          "hd_video_url": "https://www.youtube.com/embed/x_3XZGxnh4E",
          "thumbnail": "https://i.ytimg.com/vi/x_3XZGxnh4E/default.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 152 || स्थिर वैधुत विभव तथा धारिता - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b816f38e-71d0-4651-b028-a913fba475f0.pdf"
            }
          ]
        },
        {
          "serial": 153,
          "title": "व्याख्यान- 153 || स्थिर वैधुत विभव तथा धारिता - 10",
          "published_date": "12 Feb 2025",
          "video_url": "https://www.youtube.com/embed/JQDNaCNXiRU",
          "hd_video_url": "https://www.youtube.com/embed/JQDNaCNXiRU",
          "thumbnail": "https://i.ytimg.com/vi/JQDNaCNXiRU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 153 || स्थिर वैधुत विभव तथा धारिता - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/49b06f2c-10bc-4ed4-a89e-6ec15ea494c8.pdf"
            }
          ]
        },
        {
          "serial": 154,
          "title": "व्याख्यान- 154 || विधुत धारा  - 1",
          "published_date": "13 Feb 2025",
          "video_url": "https://www.youtube.com/embed/uFHMtKRh0FE",
          "hd_video_url": "https://www.youtube.com/embed/uFHMtKRh0FE",
          "thumbnail": "https://i.ytimg.com/vi/uFHMtKRh0FE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 154 || विधुत धारा  - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3d1e69d0-0465-47b3-aa0d-63634fa71281.pdf"
            }
          ]
        },
        {
          "serial": 155,
          "title": "व्याख्यान- 156 || विधुत धारा - 2",
          "published_date": "14 Feb 2025",
          "video_url": "https://www.youtube.com/embed/vlDI4JwTKYY",
          "hd_video_url": "https://www.youtube.com/embed/vlDI4JwTKYY",
          "thumbnail": "https://i.ytimg.com/vi/vlDI4JwTKYY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 156 || विधुत धारा - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1ec5b5c2-ea50-4ee5-b890-a621d5d99764.pdf"
            }
          ]
        },
        {
          "serial": 156,
          "title": "व्याख्यान- 157 || विधुत धारा - 3",
          "published_date": "15 Feb 2025",
          "video_url": "https://www.youtube.com/embed/X-Iu9aiD8kc",
          "hd_video_url": "https://www.youtube.com/embed/X-Iu9aiD8kc",
          "thumbnail": "https://i.ytimg.com/vi/X-Iu9aiD8kc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 157 || विधुत धारा - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2ed49efa-83e4-430f-8d77-17ee756abf1a.pdf"
            }
          ]
        },
        {
          "serial": 157,
          "title": "व्याख्यान- 158 || विधुत धारा - 4",
          "published_date": "15 Feb 2025",
          "video_url": "https://www.youtube.com/embed/pSSPPtcGGmo",
          "hd_video_url": "https://www.youtube.com/embed/pSSPPtcGGmo",
          "thumbnail": "https://i.ytimg.com/vi/pSSPPtcGGmo/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 158 || विधुत धारा - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/278c2913-dd03-4946-a705-07b046d5c780.pdf"
            }
          ]
        },
        {
          "serial": 158,
          "title": "व्याख्यान- 159 || विधुत धारा - 5",
          "published_date": "17 Feb 2025",
          "video_url": "https://www.youtube.com/embed/hYycb3R6gco",
          "hd_video_url": "https://www.youtube.com/embed/hYycb3R6gco",
          "thumbnail": "https://i.ytimg.com/vi/hYycb3R6gco/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 159 || विधुत धारा - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5678c2c1-b3cf-43a0-ad3b-b74eeea459d2.pdf"
            }
          ]
        },
        {
          "serial": 159,
          "title": "व्याख्यान- 160 || विधुत धारा - 6",
          "published_date": "18 Feb 2025",
          "video_url": "https://www.youtube.com/embed/Hc8cEGEEdyA",
          "hd_video_url": "https://www.youtube.com/embed/Hc8cEGEEdyA",
          "thumbnail": "https://i.ytimg.com/vi/Hc8cEGEEdyA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 160 || विधुत धारा - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c23cbed0-ca95-407e-8bea-633f423eab1b.pdf"
            }
          ]
        },
        {
          "serial": 160,
          "title": "व्याख्यान- 161 || विधुत धारा - 7",
          "published_date": "19 Feb 2025",
          "video_url": "https://www.youtube.com/embed/HbPV_gslyiY",
          "hd_video_url": "https://www.youtube.com/embed/HbPV_gslyiY",
          "thumbnail": "https://i.ytimg.com/vi/HbPV_gslyiY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 161 || विधुत धारा - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/91347ca0-ab96-45b6-b89c-7caae1201bb7.pdf"
            }
          ]
        },
        {
          "serial": 161,
          "title": "व्याख्यान- 162 || विधुत धारा - 8",
          "published_date": "20 Feb 2025",
          "video_url": "https://www.youtube.com/embed/YnlCEQlG3nI",
          "hd_video_url": "https://www.youtube.com/embed/YnlCEQlG3nI",
          "thumbnail": "https://i.ytimg.com/vi/YnlCEQlG3nI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 162 || विधुत धारा - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9a9a6a10-6051-46bd-8e40-07e596f3b274.pdf"
            }
          ]
        },
        {
          "serial": 162,
          "title": "व्याख्यान- 163 || विधुत धारा - 9",
          "published_date": "20 Feb 2025",
          "video_url": "https://www.youtube.com/embed/FF9nXdxqgdI",
          "hd_video_url": "https://www.youtube.com/embed/FF9nXdxqgdI",
          "thumbnail": "https://i.ytimg.com/vi/FF9nXdxqgdI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 163 || विधुत धारा - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7f5df30b-99c9-433f-93a7-c532888c8367.pdf"
            }
          ]
        },
        {
          "serial": 163,
          "title": "व्याख्यान- 164 || विधुत धारा - 10",
          "published_date": "21 Feb 2025",
          "video_url": "https://www.youtube.com/embed/YvnoVuq-Mho",
          "hd_video_url": "https://www.youtube.com/embed/YvnoVuq-Mho",
          "thumbnail": "https://i.ytimg.com/vi/YvnoVuq-Mho/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 164 || विधुत धारा - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/cb1d7386-fcb8-4669-af05-fb6ee6a33bb0.pdf"
            }
          ]
        },
        {
          "serial": 164,
          "title": "व्याख्यान- 165 || गतिमान आवेश और चुंबकत्व -1",
          "published_date": "22 Feb 2025",
          "video_url": "https://www.youtube.com/embed/DgzDFKuj5Vc",
          "hd_video_url": "https://www.youtube.com/embed/DgzDFKuj5Vc",
          "thumbnail": "https://i.ytimg.com/vi/DgzDFKuj5Vc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 165 || गतिमान आवेश और चुंबकत्व -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f41d4905-535b-43c1-b80a-082f78cc2823.pdf"
            }
          ]
        },
        {
          "serial": 165,
          "title": "व्याख्यान- 166 || गतिमान आवेश और चुंबकत्व -2",
          "published_date": "24 Feb 2025",
          "video_url": "https://www.youtube.com/embed/FkeXmn8i5L4",
          "hd_video_url": "https://www.youtube.com/embed/FkeXmn8i5L4",
          "thumbnail": "https://i.ytimg.com/vi/FkeXmn8i5L4/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 166 || गतिमान आवेश और चुंबकत्व -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3824ab0f-a9c7-4aa8-9f53-b963e43fcfb4.pdf"
            }
          ]
        },
        {
          "serial": 166,
          "title": "व्याख्यान- 167 || गतिमान आवेश और चुंबकत्व -3",
          "published_date": "25 Feb 2025",
          "video_url": "https://www.youtube.com/embed/6WwAmhIImPc",
          "hd_video_url": "https://www.youtube.com/embed/6WwAmhIImPc",
          "thumbnail": "https://i.ytimg.com/vi/6WwAmhIImPc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 167 || गतिमान आवेश और चुंबकत्व -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b8b9e864-e351-4cf0-8f9c-db749336fcac.pdf"
            }
          ]
        },
        {
          "serial": 167,
          "title": "व्याख्यान- 168 || गतिमान आवेश और चुंबकत्व -4",
          "published_date": "25 Feb 2025",
          "video_url": "https://www.youtube.com/embed/-lKXvIgrxBU",
          "hd_video_url": "https://www.youtube.com/embed/-lKXvIgrxBU",
          "thumbnail": "https://i.ytimg.com/vi/-lKXvIgrxBU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 168 || गतिमान आवेश और चुंबकत्व -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/248c1016-8085-470e-a29d-a457ef88e92f.pdf"
            }
          ]
        },
        {
          "serial": 168,
          "title": "व्याख्यान- 169 || गतिमान आवेश और चुंबकत्व -5",
          "published_date": "27 Feb 2025",
          "video_url": "https://www.youtube.com/embed/cboF0qAF-C0",
          "hd_video_url": "https://www.youtube.com/embed/cboF0qAF-C0",
          "thumbnail": "https://i.ytimg.com/vi/cboF0qAF-C0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 169 || गतिमान आवेश और चुंबकत्व -5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a15edb6c-3c64-46eb-a300-bfacac5f5201.pdf"
            }
          ]
        },
        {
          "serial": 169,
          "title": "व्याख्यान- 170 || गतिमान आवेश और चुंबकत्व -6",
          "published_date": "27 Feb 2025",
          "video_url": "https://www.youtube.com/embed/rPtGcDxVCuo",
          "hd_video_url": "https://www.youtube.com/embed/rPtGcDxVCuo",
          "thumbnail": "https://i.ytimg.com/vi/rPtGcDxVCuo/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 170 || गतिमान आवेश और चुंबकत्व -6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f9853f99-a4e4-4bbd-a22a-67a104a694ce.pdf"
            }
          ]
        },
        {
          "serial": 170,
          "title": "व्याख्यान- 171 || गतिमान आवेश और चुंबकत्व -7",
          "published_date": "28 Feb 2025",
          "video_url": "https://www.youtube.com/embed/4Cu_buRSuNY",
          "hd_video_url": "https://www.youtube.com/embed/4Cu_buRSuNY",
          "thumbnail": "https://i.ytimg.com/vi/4Cu_buRSuNY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 171 || गतिमान आवेश और चुंबकत्व -7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/325adf3f-9e49-4bac-a203-48b1ff60e16d.pdf"
            }
          ]
        },
        {
          "serial": 171,
          "title": "व्याख्यान- 172 || गतिमान आवेश और चुंबकत्व -8",
          "published_date": "01 Mar 2025",
          "video_url": "https://www.youtube.com/embed/F_zU35rpKLU",
          "hd_video_url": "https://www.youtube.com/embed/F_zU35rpKLU",
          "thumbnail": "https://i.ytimg.com/vi/F_zU35rpKLU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 172 || गतिमान आवेश और चुंबकत्व -8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/cab7df97-a429-43f2-a8dc-0601c3774171.pdf"
            }
          ]
        },
        {
          "serial": 172,
          "title": "व्याख्यान- 173 || चुंबकत्व और पदार्थ -1",
          "published_date": "02 Mar 2025",
          "video_url": "https://www.youtube.com/embed/T7ZmCXM6YdA",
          "hd_video_url": "https://www.youtube.com/embed/T7ZmCXM6YdA",
          "thumbnail": "https://i.ytimg.com/vi/T7ZmCXM6YdA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 173 || चुंबकत्व और पदार्थ -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e47483de-3c58-48c1-8b35-1ac892170583.pdf"
            }
          ]
        },
        {
          "serial": 173,
          "title": "व्याख्यान- 174 || चुंबकत्व और पदार्थ -2",
          "published_date": "03 Mar 2025",
          "video_url": "https://www.youtube.com/embed/DzD1kHfnu64",
          "hd_video_url": "https://www.youtube.com/embed/DzD1kHfnu64",
          "thumbnail": "https://i.ytimg.com/vi/DzD1kHfnu64/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 174 || चुंबकत्व और पदार्थ -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7dd143cf-ab0c-4d1e-8cbf-beeabb95cca7.pdf"
            }
          ]
        },
        {
          "serial": 174,
          "title": "व्याख्यान- 175 || चुंबकत्व और पदार्थ -3",
          "published_date": "04 Mar 2025",
          "video_url": "https://www.youtube.com/embed/H2fbUZydozs",
          "hd_video_url": "https://www.youtube.com/embed/H2fbUZydozs",
          "thumbnail": "https://i.ytimg.com/vi/H2fbUZydozs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 175 || चुंबकत्व और पदार्थ -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c639fc49-9382-439c-8691-1e5da223366c.pdf"
            }
          ]
        },
        {
          "serial": 175,
          "title": "व्याख्यान- 176 || विद्युत चुंबकीय प्रेरण -1",
          "published_date": "04 Mar 2025",
          "video_url": "https://www.youtube.com/embed/6UxtqTArVYg",
          "hd_video_url": "https://www.youtube.com/embed/6UxtqTArVYg",
          "thumbnail": "https://i.ytimg.com/vi/6UxtqTArVYg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 176 || विद्युत चुंबकीय प्रेरण -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2fba3d2a-f2dc-4806-8f49-105a445d285a.pdf"
            }
          ]
        },
        {
          "serial": 176,
          "title": "व्याख्यान- 177 || विद्युत चुंबकीय प्रेरण - 2",
          "published_date": "05 Mar 2025",
          "video_url": "https://www.youtube.com/embed/kVCSK2by9Ms",
          "hd_video_url": "https://www.youtube.com/embed/kVCSK2by9Ms",
          "thumbnail": "https://i.ytimg.com/vi/kVCSK2by9Ms/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 177 || विद्युत चुंबकीय प्रेरण - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/47d362bc-f360-4ac5-b565-a4b194311a54.pdf"
            }
          ]
        },
        {
          "serial": 177,
          "title": "व्याख्यान- 178 || विद्युत चुंबकीय प्रेरण - 3",
          "published_date": "06 Mar 2025",
          "video_url": "https://www.youtube.com/embed/QXk4XkKiMfg",
          "hd_video_url": "https://www.youtube.com/embed/QXk4XkKiMfg",
          "thumbnail": "https://i.ytimg.com/vi/QXk4XkKiMfg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 178 || विद्युत चुंबकीय प्रेरण - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6756e889-3809-4c1d-9e87-18ff403d986b.pdf"
            }
          ]
        },
        {
          "serial": 178,
          "title": "व्याख्यान- 179 || विद्युत चुंबकीय प्रेरण - 4",
          "published_date": "06 Mar 2025",
          "video_url": "https://www.youtube.com/embed/RMV9Qb2_2Ek",
          "hd_video_url": "https://www.youtube.com/embed/RMV9Qb2_2Ek",
          "thumbnail": "https://i.ytimg.com/vi/RMV9Qb2_2Ek/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 179 || विद्युत चुंबकीय प्रेरण - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/33db12f0-3920-453e-9155-e0498e8b1f0b.pdf"
            }
          ]
        },
        {
          "serial": 179,
          "title": "व्याख्यान- 180 || विद्युत चुंबकीय प्रेरण - 5",
          "published_date": "07 Mar 2025",
          "video_url": "https://www.youtube.com/embed/FQkvj-qHC58",
          "hd_video_url": "https://www.youtube.com/embed/FQkvj-qHC58",
          "thumbnail": "https://i.ytimg.com/vi/FQkvj-qHC58/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 180 || विद्युत चुंबकीय प्रेरण - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/525e12af-b848-4369-a32f-53da2a2ca5f5.pdf"
            }
          ]
        },
        {
          "serial": 180,
          "title": "व्याख्यान- 181 || विद्युत चुंबकीय प्रेरण - 6",
          "published_date": "08 Mar 2025",
          "video_url": "https://www.youtube.com/embed/TLnHxvPKuiU",
          "hd_video_url": "https://www.youtube.com/embed/TLnHxvPKuiU",
          "thumbnail": "https://i.ytimg.com/vi/TLnHxvPKuiU/default.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 181 || विद्युत चुंबकीय प्रेरण - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/53b1b638-47a9-4012-8789-0026c7df7913.pdf"
            }
          ]
        },
        {
          "serial": 181,
          "title": "व्याख्यान- 182 || विद्युत चुंबकीय प्रेरण - 7",
          "published_date": "10 Mar 2025",
          "video_url": "https://www.youtube.com/embed/yiT_l_e-ry0",
          "hd_video_url": "https://www.youtube.com/embed/yiT_l_e-ry0",
          "thumbnail": "https://i.ytimg.com/vi/yiT_l_e-ry0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 182 || विद्युत चुंबकीय प्रेरण - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2cb80352-fdfb-4445-9fc3-1c7218e73cbc.pdf"
            }
          ]
        },
        {
          "serial": 182,
          "title": "व्याख्यान- 183 || मात्रक एवं मापन - 1",
          "published_date": "10 Mar 2025",
          "video_url": "https://www.youtube.com/embed/yRhT1daHNMY",
          "hd_video_url": "https://www.youtube.com/embed/yRhT1daHNMY",
          "thumbnail": "https://i.ytimg.com/vi/yRhT1daHNMY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 183 || मात्रक एवं मापन - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/25b65db7-acec-46d8-a57c-36a6d7308d6b.pdf"
            }
          ]
        },
        {
          "serial": 183,
          "title": "व्याख्यान- 184 || विद्युत चुंबकीय प्रेरण - 8",
          "published_date": "11 Mar 2025",
          "video_url": "https://www.youtube.com/embed/hIhtEoDB03Q",
          "hd_video_url": "https://www.youtube.com/embed/hIhtEoDB03Q",
          "thumbnail": "https://i.ytimg.com/vi/hIhtEoDB03Q/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 184 || विद्युत चुंबकीय प्रेरण - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c4138765-1fcb-4d0e-9b9b-ff4558ea2cbb.pdf"
            }
          ]
        },
        {
          "serial": 184,
          "title": "व्याख्यान- 185 || मात्रक एवं मापन - 2",
          "published_date": "11 Mar 2025",
          "video_url": "https://www.youtube.com/embed/DWQpWD7bY8I",
          "hd_video_url": "https://www.youtube.com/embed/DWQpWD7bY8I",
          "thumbnail": "https://i.ytimg.com/vi/DWQpWD7bY8I/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 185 || मात्रक एवं मापन - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/535dfdf6-a5b7-4011-85a1-0baf091c9bc6.pdf"
            }
          ]
        },
        {
          "serial": 185,
          "title": "व्याख्यान- 186 || मात्रक एवं मापन - 3",
          "published_date": "12 Mar 2025",
          "video_url": "https://www.youtube.com/embed/_G_zHTiEx54",
          "hd_video_url": "https://www.youtube.com/embed/_G_zHTiEx54",
          "thumbnail": "https://i.ytimg.com/vi/_G_zHTiEx54/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 186 || मात्रक एवं मापन - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fd1ce91e-a237-478a-b786-72620a0fedce.pdf"
            }
          ]
        },
        {
          "serial": 186,
          "title": "व्याख्यान- 187 || विद्युत चुंबकीय प्रेरण - 9",
          "published_date": "17 Mar 2025",
          "video_url": "https://www.youtube.com/embed/VH6GKNGMjjo",
          "hd_video_url": "https://www.youtube.com/embed/VH6GKNGMjjo",
          "thumbnail": "https://i.ytimg.com/vi/VH6GKNGMjjo/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 187 || विद्युत चुंबकीय प्रेरण - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/cee6f8d8-4f60-4163-8590-d2ade604429f.pdf"
            }
          ]
        },
        {
          "serial": 187,
          "title": "व्याख्यान- 188 || विद्युतचुम्बकीय तरंगें -1",
          "published_date": "18 Mar 2025",
          "video_url": "https://www.youtube.com/embed/dBHndx4SqDU",
          "hd_video_url": "https://www.youtube.com/embed/dBHndx4SqDU",
          "thumbnail": "https://i.ytimg.com/vi/dBHndx4SqDU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 188 || विद्युतचुम्बकीय तरंगें -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3fcfd36a-6019-4e4a-8a61-ce9de7fdf5e6.pdf"
            }
          ]
        },
        {
          "serial": 188,
          "title": "व्याख्यान- 189 || विद्युतचुम्बकीय तरंगें -2",
          "published_date": "19 Mar 2025",
          "video_url": "https://www.youtube.com/embed/dFsTtcKVTjU",
          "hd_video_url": "https://www.youtube.com/embed/dFsTtcKVTjU",
          "thumbnail": "https://i.ytimg.com/vi/dFsTtcKVTjU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 189 || विद्युतचुम्बकीय तरंगें -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/08a1da15-d885-4bf6-8f3e-0581018ef753.pdf"
            }
          ]
        },
        {
          "serial": 189,
          "title": "व्याख्यान- 190 || प्रत्यावर्ती धारा -1",
          "published_date": "20 Mar 2025",
          "video_url": "https://www.youtube.com/embed/hqmdd0Q0pmQ",
          "hd_video_url": "https://www.youtube.com/embed/hqmdd0Q0pmQ",
          "thumbnail": "https://i.ytimg.com/vi/hqmdd0Q0pmQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 190 || प्रत्यावर्ती धारा -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/36cccf2d-f98b-481e-9abb-6c75b8be67b7.pdf"
            }
          ]
        },
        {
          "serial": 190,
          "title": "व्याख्यान- 191 || मात्रक एवं मापन - 4",
          "published_date": "20 Mar 2025",
          "video_url": "https://www.youtube.com/embed/9awL2UiKi70",
          "hd_video_url": "https://www.youtube.com/embed/9awL2UiKi70",
          "thumbnail": "https://i.ytimg.com/vi/9awL2UiKi70/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 191 || मात्रक एवं मापन - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7a1f3c9a-21d9-491f-ac4a-1fc96712d9a8.pdf"
            }
          ]
        },
        {
          "serial": 191,
          "title": "व्याख्यान- 192 || प्रत्यावर्ती धारा -2",
          "published_date": "21 Mar 2025",
          "video_url": "https://www.youtube.com/embed/f8qA7_SqguY",
          "hd_video_url": "https://www.youtube.com/embed/f8qA7_SqguY",
          "thumbnail": "https://i.ytimg.com/vi/f8qA7_SqguY/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 192  प्रत्यावर्ती धारा -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/aeef9da2-6125-4540-93c3-c9849c59e48c.pdf"
            }
          ]
        },
        {
          "serial": 192,
          "title": "व्याख्यान- 193 || प्रत्यावर्ती धारा -3",
          "published_date": "22 Mar 2025",
          "video_url": "https://www.youtube.com/embed/2tRMCJjfSjQ",
          "hd_video_url": "https://www.youtube.com/embed/2tRMCJjfSjQ",
          "thumbnail": "https://i.ytimg.com/vi/2tRMCJjfSjQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 193 || प्रत्यावर्ती धारा -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e270e9a2-0e04-4625-813b-00b2ba5d0dc8.pdf"
            }
          ]
        },
        {
          "serial": 193,
          "title": "व्याख्यान- 194 || मात्रक एवं मापन - 5",
          "published_date": "22 Mar 2025",
          "video_url": "https://www.youtube.com/embed/KX1JCxJO15Y",
          "hd_video_url": "https://www.youtube.com/embed/KX1JCxJO15Y",
          "thumbnail": "https://i.ytimg.com/vi/KX1JCxJO15Y/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 194 || प्रत्यावर्ती धारा -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/474413e2-4b6d-4306-9092-d2bf7aa9a731.pdf"
            }
          ]
        },
        {
          "serial": 194,
          "title": "व्याख्यान- 195 || प्रत्यावर्ती धारा -4",
          "published_date": "23 Mar 2025",
          "video_url": "https://www.youtube.com/embed/lOprPieAG5o",
          "hd_video_url": "https://www.youtube.com/embed/lOprPieAG5o",
          "thumbnail": "https://i.ytimg.com/vi/lOprPieAG5o/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 195 || प्रत्यावर्ती धारा -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6f8e8176-7646-4b9d-94d6-ff1d224b7d40.pdf"
            }
          ]
        },
        {
          "serial": 195,
          "title": "व्याख्यान- 196 || प्रत्यावर्ती धारा -5",
          "published_date": "26 Mar 2025",
          "video_url": "https://www.youtube.com/embed/Fvpv4jOkIwc",
          "hd_video_url": "https://www.youtube.com/embed/Fvpv4jOkIwc",
          "thumbnail": "https://i.ytimg.com/vi/Fvpv4jOkIwc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 196 || प्रत्यावर्ती धारा -5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3f72df29-9f5f-49eb-8324-84c082ff98af.pdf"
            }
          ]
        },
        {
          "serial": 196,
          "title": "व्याख्यान- 197 || मात्रक एवं मापन - 6",
          "published_date": "27 Mar 2025",
          "video_url": "https://www.youtube.com/embed/l1TzrPEQFTc",
          "hd_video_url": "https://www.youtube.com/embed/l1TzrPEQFTc",
          "thumbnail": "https://i.ytimg.com/vi/l1TzrPEQFTc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 197 || मात्रक एवं मापन - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c9dbf293-8d89-4309-9ff4-a19f5c2e75e1.pdf"
            }
          ]
        },
        {
          "serial": 197,
          "title": "व्याख्यान- 198 || मात्रक एवं मापन - 7",
          "published_date": "01 Apr 2025",
          "video_url": "https://www.youtube.com/embed/6JwNrHe9g7I",
          "hd_video_url": "https://www.youtube.com/embed/6JwNrHe9g7I",
          "thumbnail": "https://i.ytimg.com/vi/6JwNrHe9g7I/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 198 || मात्रक एवं मापन - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5b16c56d-0692-44a1-9016-67bd2ae25616.pdf"
            }
          ]
        },
        {
          "serial": 198,
          "title": "व्याख्यान- 199 || नाभिकीय भौतिकी",
          "published_date": "01 Apr 2025",
          "video_url": "https://www.youtube.com/embed/PpR-SICHfbY",
          "hd_video_url": "https://www.youtube.com/embed/PpR-SICHfbY",
          "thumbnail": "https://i.ytimg.com/vi/PpR-SICHfbY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 199 || नाभिकीय भौतिकी",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/79a7d45e-e8f9-4708-991f-b7b1bf497986.pdf"
            }
          ]
        },
        {
          "serial": 199,
          "title": "व्याख्यान- 200 || परमाणु भौतिकी",
          "published_date": "02 Apr 2025",
          "video_url": "https://www.youtube.com/embed/tOq5OTWNenw",
          "hd_video_url": "https://www.youtube.com/embed/tOq5OTWNenw",
          "thumbnail": "https://i.ytimg.com/vi/tOq5OTWNenw/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 200 || परमाणु भौतिकी",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/baa9e5a4-3bd1-4b62-bf2b-30abeab1d00c.pdf"
            }
          ]
        },
        {
          "serial": 200,
          "title": "व्याख्यान- 201|| दोहरी प्रकृति",
          "published_date": "03 Apr 2025",
          "video_url": "https://www.youtube.com/embed/RO2Jm878Ks0",
          "hd_video_url": "https://www.youtube.com/embed/RO2Jm878Ks0",
          "thumbnail": "https://i.ytimg.com/vi/RO2Jm878Ks0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 201|| दोहरी प्रकृति",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0248805d-2346-4916-9fbd-c27d88cdb361.pdf"
            }
          ]
        },
        {
          "serial": 201,
          "title": "व्याख्यान- 202 || अर्धचालक",
          "published_date": "04 Apr 2025",
          "video_url": "https://www.youtube.com/embed/pFhb9UmnTMg",
          "hd_video_url": "https://www.youtube.com/embed/pFhb9UmnTMg",
          "thumbnail": "https://i.ytimg.com/vi/pFhb9UmnTMg/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 202 || अर्धचालक",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/80df5f19-e4fb-4d74-9fe5-ed71f8ba243b.pdf"
            }
          ]
        },
        {
          "serial": 202,
          "title": "व्याख्यान- 203 || Revision - 1",
          "published_date": "05 Apr 2025",
          "video_url": "https://www.youtube.com/embed/mXpRl8jTzsk",
          "hd_video_url": "https://www.youtube.com/embed/mXpRl8jTzsk",
          "thumbnail": "https://i.ytimg.com/vi/mXpRl8jTzsk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 203 || Revision - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3608da46-a833-4bc9-8fe7-95227c377c94.pdf"
            }
          ]
        },
        {
          "serial": 203,
          "title": "व्याख्यान- 204 || किरण प्रकाशिकी - 1",
          "published_date": "07 Apr 2025",
          "video_url": "https://www.youtube.com/embed/JsgW23hgX1M",
          "hd_video_url": "https://www.youtube.com/embed/JsgW23hgX1M",
          "thumbnail": "https://i.ytimg.com/vi/JsgW23hgX1M/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 204 || किरण प्रकाशिकी - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d4514001-a918-4e12-bae2-967d7e1de396.pdf"
            }
          ]
        },
        {
          "serial": 204,
          "title": "व्याख्यान- 205|| दोहरी प्रकृति Revision",
          "published_date": "08 Apr 2025",
          "video_url": "https://www.youtube.com/embed/hMj-NNQBAEo",
          "hd_video_url": "https://www.youtube.com/embed/hMj-NNQBAEo",
          "thumbnail": "https://i.ytimg.com/vi/hMj-NNQBAEo/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 205|| दोहरी प्रकृति Revision",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fc242baf-a191-4a69-96eb-75826f35886c.pdf"
            }
          ]
        },
        {
          "serial": 205,
          "title": "व्याख्यान- 206 || किरण प्रकाशिकी - 2",
          "published_date": "09 Apr 2025",
          "video_url": "https://www.youtube.com/embed/KH6UmQf7GFo",
          "hd_video_url": "https://www.youtube.com/embed/KH6UmQf7GFo",
          "thumbnail": "https://i.ytimg.com/vi/KH6UmQf7GFo/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 206 || किरण प्रकाशिकी - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b3d6ebbb-93ca-4a60-9c3f-d5834c567e30.pdf"
            }
          ]
        },
        {
          "serial": 206,
          "title": "व्याख्यान- 207 || किरण प्रकाशिकी - 3",
          "published_date": "09 Apr 2025",
          "video_url": "https://www.youtube.com/embed/8KSBJV1oQ6o",
          "hd_video_url": "https://www.youtube.com/embed/8KSBJV1oQ6o",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 207 || किरण प्रकाशिकी - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c48ab5b6-1ce1-4f99-a4e3-80d52eb35790.pdf"
            }
          ]
        },
        {
          "serial": 207,
          "title": "व्याख्यान- 208 || किरण प्रकाशिकी - 4",
          "published_date": "10 Apr 2025",
          "video_url": "https://www.youtube.com/embed/4aPAS0PAxRI",
          "hd_video_url": "https://www.youtube.com/embed/4aPAS0PAxRI",
          "thumbnail": "",
          "notes": [
            {
              "title": "व्याख्यान- 208 || किरण प्रकाशिकी - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/aba04d59-200c-485f-a2b6-8128c8d8f9b2.pdf"
            }
          ]
        },
        {
          "serial": 208,
          "title": "व्याख्यान- 209 || किरण प्रकाशिकी - 5",
          "published_date": "10 Apr 2025",
          "video_url": "https://www.youtube.com/embed/fDR4qqbHb8A",
          "hd_video_url": "https://www.youtube.com/embed/fDR4qqbHb8A",
          "thumbnail": "",
          "notes": [
            {
              "title": "व्याख्यान- 209 || किरण प्रकाशिकी - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5e22015c-40f7-4808-b293-fea871dbf0c2.pdf"
            }
          ]
        },
        {
          "serial": 209,
          "title": "व्याख्यान- 210 || तरंग प्रकाशिकी -1",
          "published_date": "12 Apr 2025",
          "video_url": "https://www.youtube.com/embed/ItEYRr3A6GU",
          "hd_video_url": "https://www.youtube.com/embed/ItEYRr3A6GU",
          "thumbnail": "",
          "notes": [
            {
              "title": "व्याख्यान- 210 || तरंग प्रकाशिकी -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1711b28a-4651-4c8c-a1c3-902e4d597ccd.pdf"
            }
          ]
        },
        {
          "serial": 210,
          "title": "व्याख्यान- 211 || अर्धचालक Revision PYQ",
          "published_date": "15 Apr 2025",
          "video_url": "https://www.youtube.com/embed/Q91jya186bk",
          "hd_video_url": "https://www.youtube.com/embed/Q91jya186bk",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/XNUq3gdvAXGWHdRmZIz0TLX6f9gYw23cXRgvYeh3.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 211 || अर्धचालक Revision PYQ",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2c7cf508-9a10-4249-9fbb-7142f4ab7bd3.pdf"
            }
          ]
        },
        {
          "serial": 211,
          "title": "व्याख्यान- 212 || तरंग प्रकाशिकी -2",
          "published_date": "15 Apr 2025",
          "video_url": "https://www.youtube.com/embed/5LQ30UMDTp0",
          "hd_video_url": "https://www.youtube.com/embed/5LQ30UMDTp0",
          "thumbnail": "",
          "notes": [
            {
              "title": "व्याख्यान- 212 || तरंग प्रकाशिकी -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3b561d11-ecf9-4b86-99a2-98bba7299e78.pdf"
            }
          ]
        },
        {
          "serial": 212,
          "title": "व्याख्यान- 213 ||  Revision",
          "published_date": "16 Apr 2025",
          "video_url": "https://www.youtube.com/embed/MMbgtyo0nDM",
          "hd_video_url": "https://www.youtube.com/embed/MMbgtyo0nDM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/7wXjnZGbyVxQBX5tNkxFUqAnStSTHb72MgOs8Wa5.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 213 || Revision",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d2b1759c-ab59-4968-801a-224956f16fd2.pdf"
            }
          ]
        },
        {
          "serial": 213,
          "title": "व्याख्यान- 214 || तरंग प्रकाशिकी -3",
          "published_date": "17 Apr 2025",
          "video_url": "https://www.youtube.com/embed/DftwLDArT7k",
          "hd_video_url": "https://www.youtube.com/embed/DftwLDArT7k",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 214 || तरंग प्रकाशिकी -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/18ecd8fb-9c82-4a48-b7a8-af9f858696a9.pdf"
            }
          ]
        },
        {
          "serial": 214,
          "title": "व्याख्यान- 214 || Revision",
          "published_date": "19 Apr 2025",
          "video_url": "https://www.youtube.com/embed/V6YMlKuFxq4",
          "hd_video_url": "https://www.youtube.com/embed/V6YMlKuFxq4",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/QcdpSK42qdqw1nm0zSmDB5fBZ4wvGO9SQ7CZindw.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 214 || Revision",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/62a75a6c-a3ca-4fbb-a55b-320eef4a8b5a.pdf"
            }
          ]
        }
      ],
      "notes": []
    },
    {
      "subject_name": "Physics Supporting Material",
      "subject_id": 3426,
      "video_count": 64,
      "note_count": 64,
      "videos": [
        {
          "serial": 1,
          "title": "डीपीपी-1 || मूलभूत गणित -Video Solution",
          "published_date": "07 Oct 2024",
          "video_url": "https://www.youtube.com/embed/0sqEjUCRsaY",
          "hd_video_url": "https://www.youtube.com/embed/0sqEjUCRsaY",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-1 || मूलभूत गणित -Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/58b70e03-4e71-413f-82f8-5b416a3572cb.pdf"
            }
          ]
        },
        {
          "serial": 2,
          "title": "डीपीपी-2 || मूलभूत गणित -Video Solution",
          "published_date": "07 Oct 2024",
          "video_url": "https://www.youtube.com/embed/08H7iPsWF54",
          "hd_video_url": "https://www.youtube.com/embed/08H7iPsWF54",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-2 || मूलभूत गणित -Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1d1d6e95-011c-4617-9634-3744bb378149.pdf"
            }
          ]
        },
        {
          "serial": 3,
          "title": "डीपीपी-3 || मूलभूत गणित -Video Solution",
          "published_date": "09 Oct 2024",
          "video_url": "https://www.youtube.com/embed/mUn-jxyjc6o",
          "hd_video_url": "https://www.youtube.com/embed/mUn-jxyjc6o",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/NIZcnhvhctY3SweOkVrrarfMMTLXpe1zhwIotPGW.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-3 || मूलभूत गणित -Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e30c5a0f-5ad2-4268-90fb-c92cbbf6d1ca.pdf"
            }
          ]
        },
        {
          "serial": 4,
          "title": "डीपीपी-4 || मूलभूत गणित -Video Solution",
          "published_date": "09 Oct 2024",
          "video_url": "https://www.youtube.com/embed/nGlrRQvDxl8",
          "hd_video_url": "https://www.youtube.com/embed/nGlrRQvDxl8",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-4 || मूलभूत गणित -Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2b19ff6d-fc34-40ad-9d83-5262e50c2bd0.pdf"
            }
          ]
        },
        {
          "serial": 5,
          "title": "डीपीपी-5 || मूलभूत गणित -Video Solution",
          "published_date": "09 Oct 2024",
          "video_url": "https://www.youtube.com/embed/swa1IYpDsbU",
          "hd_video_url": "https://www.youtube.com/embed/swa1IYpDsbU",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-5 || मूलभूत गणित -Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3b0482d0-6bd6-469a-ac7b-32746fa31b6c.pdf"
            }
          ]
        },
        {
          "serial": 6,
          "title": "डीपीपी-6 || मूलभूत गणित -Video Solution",
          "published_date": "09 Oct 2024",
          "video_url": "https://youtube.com/embed/ZEDMcu14T-Y",
          "hd_video_url": "https://youtube.com/embed/ZEDMcu14T-Y",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-6 || मूलभूत गणित -Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/589c80c0-23d1-4aa9-992b-8cc176400f65.pdf"
            }
          ]
        },
        {
          "serial": 7,
          "title": "डीपीपी-7 ||  सदिश राशि -1 Video Solution",
          "published_date": "09 Oct 2024",
          "video_url": "https://youtube.com/embed/s5KwukE1ze4",
          "hd_video_url": "https://youtube.com/embed/s5KwukE1ze4",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-7 ||  सदिश राशि -1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ecab11eb-fa5d-4845-9320-49cb603550bd.pdf"
            }
          ]
        },
        {
          "serial": 8,
          "title": "डीपीपी-8 || सदिश राशि -2 Video Solution",
          "published_date": "09 Oct 2024",
          "video_url": "https://youtube.com/embed/KQ0YA3iT49Y",
          "hd_video_url": "https://youtube.com/embed/KQ0YA3iT49Y",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-8 || सदिश राशि -2 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ae30d88f-3c9d-4ad2-99bf-eb88948c8145.pdf"
            }
          ]
        },
        {
          "serial": 9,
          "title": "डीपीपी-9 || सदिश राशि -3 Video Solution",
          "published_date": "09 Oct 2024",
          "video_url": "https://youtube.com/embed/M1exIAKtbCs",
          "hd_video_url": "https://youtube.com/embed/M1exIAKtbCs",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-9 || सदिश राशि -3 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d424536f-0c04-4a0e-9dfc-5e063db6c88e.pdf"
            }
          ]
        },
        {
          "serial": 10,
          "title": "डीपीपी-10 || सदिश राशि -4 Video Solution",
          "published_date": "09 Oct 2024",
          "video_url": "https://www.youtube.com/embed/Frq-vfM2jYw",
          "hd_video_url": "https://www.youtube.com/embed/Frq-vfM2jYw",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-10 || सदिश राशि -4 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/aea9f63d-04ef-4a35-992a-0756564102af.pdf"
            }
          ]
        },
        {
          "serial": 11,
          "title": "डीपीपी-11 || सदिश राशि -5 Video Solution",
          "published_date": "10 Oct 2024",
          "video_url": "https://youtube.com/embed/4qOvcxgZ6B8",
          "hd_video_url": "https://youtube.com/embed/4qOvcxgZ6B8",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes -डीपीपी-11 || सदिश राशि -5 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6b2f04d5-d8db-4760-b1c6-83822aaf488b.pdf"
            }
          ]
        },
        {
          "serial": 12,
          "title": "डीपीपी-12 ||  सरल रेखा में गति - 1 Video Solution",
          "published_date": "10 Oct 2024",
          "video_url": "https://youtube.com/embed/eA1Oo94vIds",
          "hd_video_url": "https://youtube.com/embed/eA1Oo94vIds",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-12 ||  सरल रेखा में गति - 1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/029c2738-312c-42a1-8f38-f1ce0def831f.pdf"
            }
          ]
        },
        {
          "serial": 13,
          "title": "डीपीपी-13 ||  सरल रेखा में गति - 2 Video Solution",
          "published_date": "10 Oct 2024",
          "video_url": "https://youtube.com/embed/_8zxQeEOgXY",
          "hd_video_url": "https://youtube.com/embed/_8zxQeEOgXY",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-13 ||  सरल रेखा में गति - 2 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/79c62b4c-99d3-4167-8d99-e1b8ef865ed2.pdf"
            }
          ]
        },
        {
          "serial": 14,
          "title": "डीपीपी-14 || सरल रेखा में गति -3 Video Solution",
          "published_date": "10 Oct 2024",
          "video_url": "https://youtube.com/embed/LYWWdAdTkYE",
          "hd_video_url": "https://youtube.com/embed/LYWWdAdTkYE",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-14 || सरल रेखा में गति -3 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/36605510-947d-43e0-8b5a-c5ee9eba5f93.pdf"
            }
          ]
        },
        {
          "serial": 15,
          "title": "डीपीपी-15 || सरल रेखा में गति -4 Video Solution",
          "published_date": "10 Oct 2024",
          "video_url": "https://youtube.com/embed/Or1LJeQViQo",
          "hd_video_url": "https://youtube.com/embed/Or1LJeQViQo",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-15 || सरल रेखा में गति -4 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/23cd5a1e-43e5-4a55-9ddf-6d05504d2837.pdf"
            }
          ]
        },
        {
          "serial": 16,
          "title": "डीपीपी-16 || सरल रेखा में गति -5 Video Solution",
          "published_date": "10 Oct 2024",
          "video_url": "https://youtube.com/embed/WmuMCO6innc",
          "hd_video_url": "https://youtube.com/embed/WmuMCO6innc",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी-16 || सरल रेखा में गति -5 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fed99401-0720-4c3d-bfb8-f420527b19bc.pdf"
            }
          ]
        },
        {
          "serial": 17,
          "title": "डीपीपी- 17|| समतल में गति - 1 Video Solution",
          "published_date": "14 Oct 2024",
          "video_url": "https://youtube.com/embed/Ntp1LOv4lEs",
          "hd_video_url": "https://youtube.com/embed/Ntp1LOv4lEs",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 17|| समतल में गति - 1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/bf4f92b2-6a5c-42da-85c1-b8230f6f3bfb.pdf"
            }
          ]
        },
        {
          "serial": 18,
          "title": "डीपीपी- 18 || समतल में गति - 2 Video Solution",
          "published_date": "14 Oct 2024",
          "video_url": "https://www.youtube.com/embed/NJ6XpfkrSes",
          "hd_video_url": "https://www.youtube.com/embed/NJ6XpfkrSes",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 18 || समतल में गति - 2 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/817686eb-507d-4071-ac53-e929af40038e.pdf"
            }
          ]
        },
        {
          "serial": 19,
          "title": "डीपीपी- 19 || समतल में गति - 3 Video Solution",
          "published_date": "23 Oct 2024",
          "video_url": "https://www.youtube.com/embed/bBw4KmgWEAw",
          "hd_video_url": "https://www.youtube.com/embed/bBw4KmgWEAw",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 19 || समतल में गति - 3 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3452a743-27b5-4bfc-b920-a7ae4ba786a4.pdf"
            }
          ]
        },
        {
          "serial": 20,
          "title": "डीपीपी- 20 || समतल में गति - 4 Video Solution",
          "published_date": "23 Oct 2024",
          "video_url": "https://www.youtube.com/embed/H9DnXoV-tog",
          "hd_video_url": "https://www.youtube.com/embed/H9DnXoV-tog",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 20 || समतल में गति - 4 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/85428418-6ade-48bd-ba63-97cb8714fba4.pdf"
            }
          ]
        },
        {
          "serial": 21,
          "title": "डीपीपी- 21 || समतल में गति - 5 Video Solution",
          "published_date": "23 Oct 2024",
          "video_url": "https://www.youtube.com/embed/qqriHfMfa5A",
          "hd_video_url": "https://www.youtube.com/embed/qqriHfMfa5A",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes -डीपीपी- 21 || समतल में गति - 5 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6c0c8d8c-f879-4776-b551-76cb54d73d7e.pdf"
            }
          ]
        },
        {
          "serial": 22,
          "title": "डीपीपी- 22 || सापेक्ष गति -1 Video Solution",
          "published_date": "09 Nov 2024",
          "video_url": "https://www.youtube.com/embed/ttrx_z0BpXg",
          "hd_video_url": "https://www.youtube.com/embed/ttrx_z0BpXg",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 22 || सापेक्ष गति -1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/cbd0ed0f-3f63-4486-8802-f2ad3c51bfc3.pdf"
            }
          ]
        },
        {
          "serial": 23,
          "title": "डीपीपी- 23 || न्यूटन का गति  नियम -1 Video Solution",
          "published_date": "18 Nov 2024",
          "video_url": "https://www.youtube.com/embed/SJD1wtN1HSg",
          "hd_video_url": "https://www.youtube.com/embed/SJD1wtN1HSg",
          "thumbnail": "https://i.ytimg.com/vi/SJD1wtN1HSg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 23 || न्यूटन का गति  नियम -1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f94e8f26-dd3f-4bcd-8177-ac34ba9e0abe.pdf"
            }
          ]
        },
        {
          "serial": 24,
          "title": "डीपीपी- 24 || न्यूटन का गति नियम -2 Video Solution",
          "published_date": "18 Nov 2024",
          "video_url": "https://www.youtube.com/embed/JNDgF_m3FFs",
          "hd_video_url": "https://www.youtube.com/embed/JNDgF_m3FFs",
          "thumbnail": "https://i.ytimg.com/vi/JNDgF_m3FFs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 24 || न्यूटन का गति नियम -2 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/cbf3cfd3-83e2-43b9-bcb4-4a9912d0a183.pdf"
            }
          ]
        },
        {
          "serial": 25,
          "title": "डीपीपी- 25 || न्यूटन का गति नियम -3 Video Solution",
          "published_date": "18 Nov 2024",
          "video_url": "https://www.youtube.com/embed/WFm2qbTESWg",
          "hd_video_url": "https://www.youtube.com/embed/WFm2qbTESWg",
          "thumbnail": "https://i.ytimg.com/vi/WFm2qbTESWg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 25 || न्यूटन का गति नियम -3 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a84378f7-5fe0-44e7-83e0-d70564829ab8.pdf"
            }
          ]
        },
        {
          "serial": 26,
          "title": "डीपीपी- 26 || न्यूटन का गति नियम -4 Video Solution",
          "published_date": "19 Nov 2024",
          "video_url": "https://www.youtube.com/embed/xyIui-zzVdk",
          "hd_video_url": "https://www.youtube.com/embed/xyIui-zzVdk",
          "thumbnail": "https://i.ytimg.com/vi/xyIui-zzVdk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 26 || न्यूटन का गति नियम -4 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5bd83502-2961-4899-8126-9b886843cecf.pdf"
            }
          ]
        },
        {
          "serial": 27,
          "title": "डीपीपी- 27 || न्यूटन का गति नियम -5 Video Solution",
          "published_date": "19 Nov 2024",
          "video_url": "https://www.youtube.com/embed/QP1bnXCnkHg",
          "hd_video_url": "https://www.youtube.com/embed/QP1bnXCnkHg",
          "thumbnail": "https://i.ytimg.com/vi/QP1bnXCnkHg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 27 || न्यूटन का गति नियम -5 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9f9913c9-77ae-47cd-b614-a27ad2b5f70a.pdf"
            }
          ]
        },
        {
          "serial": 28,
          "title": "28 - DPP | सापेक्ष गति -2 Video Solution",
          "published_date": "21 Nov 2024",
          "video_url": "https://www.youtube.com/embed/CNeMCw9rDFs",
          "hd_video_url": "https://www.youtube.com/embed/CNeMCw9rDFs",
          "thumbnail": "https://i.ytimg.com/vi/CNeMCw9rDFs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 28 || सापेक्ष गति -2 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/453b835c-9afe-43d6-ac39-e3f2fb07bfc3.pdf"
            }
          ]
        },
        {
          "serial": 29,
          "title": "29 - DPP कार्य, ऊर्जा एवं शक्ति - 1 Video Solution",
          "published_date": "22 Nov 2024",
          "video_url": "https://www.youtube.com/embed/Vkgwe88YBz8",
          "hd_video_url": "https://www.youtube.com/embed/Vkgwe88YBz8",
          "thumbnail": "https://i.ytimg.com/vi/Vkgwe88YBz8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - 29 - DPP कार्य, ऊर्जा एवं शक्ति - 1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f80a1700-a82d-43b4-848f-87923316d93a.pdf"
            }
          ]
        },
        {
          "serial": 30,
          "title": "डीपीपी- 30 || द्रव्यमान केंद्र ओर संघट्‍ट- 1 Video Solution",
          "published_date": "02 Dec 2024",
          "video_url": "https://www.youtube.com/embed/T7fsCWwlYT0",
          "hd_video_url": "https://www.youtube.com/embed/T7fsCWwlYT0",
          "thumbnail": "https://i.ytimg.com/vi/T7fsCWwlYT0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 30 || द्रव्यमान केंद्र ओर संघट्‍ट- 1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/724bc900-3d18-42a3-b0a5-52a3dcce9e5a.pdf"
            }
          ]
        },
        {
          "serial": 31,
          "title": "डीपीपी- 31 || द्रव्यमान केंद्र ओर संघट्‍ट- 2 Video Solution",
          "published_date": "02 Dec 2024",
          "video_url": "https://www.youtube.com/embed/LSRo7sbb63E",
          "hd_video_url": "https://www.youtube.com/embed/LSRo7sbb63E",
          "thumbnail": "https://i.ytimg.com/vi/LSRo7sbb63E/default.jpg",
          "notes": [
            {
              "title": "Class Notes -डीपीपी- 31 || द्रव्यमान केंद्र ओर संघट्‍ट- 2 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d5e51361-2d05-434b-9b67-41a3a81b629f.pdf"
            }
          ]
        },
        {
          "serial": 32,
          "title": "डीपीपी- 32 || द्रव्यमान केंद्र ओर संघट्‍ट- 3 Video Solution",
          "published_date": "02 Dec 2024",
          "video_url": "https://www.youtube.com/embed/8-D0W9KEt74",
          "hd_video_url": "https://www.youtube.com/embed/8-D0W9KEt74",
          "thumbnail": "https://i.ytimg.com/vi/8-D0W9KEt74/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 32 || द्रव्यमान केंद्र ओर संघट्‍ट- 3 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/052b42a8-eb09-41ea-bdd8-25c1f62497c2.pdf"
            }
          ]
        },
        {
          "serial": 33,
          "title": "डीपीपी- 33 || घूर्णन गति - 1 Video Solution",
          "published_date": "02 Dec 2024",
          "video_url": "https://www.youtube.com/embed/rEW9UA7MACs",
          "hd_video_url": "https://www.youtube.com/embed/rEW9UA7MACs",
          "thumbnail": "https://i.ytimg.com/vi/rEW9UA7MACs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 33 || घूर्णन गति - 1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/69c7b85b-1f42-433b-ad2b-d168deaf3c84.pdf"
            }
          ]
        },
        {
          "serial": 34,
          "title": "डीपीपी- 34 || घूर्णन गति - 2 Video Solution",
          "published_date": "23 Dec 2024",
          "video_url": "https://www.youtube.com/embed/7ktdyVzeh-g",
          "hd_video_url": "https://www.youtube.com/embed/7ktdyVzeh-g",
          "thumbnail": "https://i.ytimg.com/vi/7ktdyVzeh-g/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 34 || घूर्णन गति - 2 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ac97ffc0-1872-41da-b1e9-e1bab8cc83f6.pdf"
            }
          ]
        },
        {
          "serial": 35,
          "title": "डीपीपी- 35 || गुरुत्वाकर्षण- 1 Video Solution",
          "published_date": "30 Dec 2024",
          "video_url": "https://www.youtube.com/embed/eZEKqrYvtMY",
          "hd_video_url": "https://www.youtube.com/embed/eZEKqrYvtMY",
          "thumbnail": "https://i.ytimg.com/vi/eZEKqrYvtMY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 35 || गुरुत्वाकर्षण- 1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e07961c0-bc31-4d69-91d3-5fbc0e33b58d.pdf"
            }
          ]
        },
        {
          "serial": 36,
          "title": "डीपीपी- 36 || गुरुत्वाकर्षण- 2 Video Solution",
          "published_date": "03 Jan 2025",
          "video_url": "https://www.youtube.com/embed/1a2cfRLce6I",
          "hd_video_url": "https://www.youtube.com/embed/1a2cfRLce6I",
          "thumbnail": "https://i.ytimg.com/vi/1a2cfRLce6I/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 36 || गुरुत्वाकर्षण- 2 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/00c5cc4a-8e37-4f27-b2a2-35835874346d.pdf"
            }
          ]
        },
        {
          "serial": 37,
          "title": "डीपीपी- 37 || गुरुत्वाकर्षण- 3 Video Solution",
          "published_date": "18 Jan 2025",
          "video_url": "https://www.youtube.com/embed/kBmlhmdTfJg",
          "hd_video_url": "https://www.youtube.com/embed/kBmlhmdTfJg",
          "thumbnail": "https://i.ytimg.com/vi/kBmlhmdTfJg/default.jpg",
          "notes": [
            {
              "title": "Class Notes -डीपीपी- 37 || गुरुत्वाकर्षण- 3 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a0620262-60ea-4bfb-b5b8-dc15a8cc5ade.pdf"
            }
          ]
        },
        {
          "serial": 38,
          "title": "डीपीपी- 38 || गुरुत्वाकर्षण- 4 Video Solution",
          "published_date": "18 Jan 2025",
          "video_url": "https://www.youtube.com/embed/ITW9-y4vzMI",
          "hd_video_url": "https://www.youtube.com/embed/ITW9-y4vzMI",
          "thumbnail": "https://i.ytimg.com/vi/ITW9-y4vzMI/default.jpg",
          "notes": [
            {
              "title": "Class Notes -डीपीपी- 38 || गुरुत्वाकर्षण- 4 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2647422c-9a56-4ea7-ac9c-d01dfce8eace.pdf"
            }
          ]
        },
        {
          "serial": 39,
          "title": "डीपीपी- 39 || गुरुत्वाकर्षण- 5 Video Solution",
          "published_date": "18 Jan 2025",
          "video_url": "https://www.youtube.com/embed/tj59xN-_UvA",
          "hd_video_url": "https://www.youtube.com/embed/tj59xN-_UvA",
          "thumbnail": "https://i.ytimg.com/vi/tj59xN-_UvA/default.jpg",
          "notes": [
            {
              "title": "Class Notes -डीपीपी- 39 || गुरुत्वाकर्षण- 5 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/47f3c305-901f-4ff1-9fef-01a87a175c08.pdf"
            }
          ]
        },
        {
          "serial": 40,
          "title": "डीपीपी- 40 || गुरुत्वाकर्षण- 6 Video Solution",
          "published_date": "21 Jan 2025",
          "video_url": "https://www.youtube.com/embed/SSR9OG6YnQM",
          "hd_video_url": "https://www.youtube.com/embed/SSR9OG6YnQM",
          "thumbnail": "https://i.ytimg.com/vi/SSR9OG6YnQM/default.jpg",
          "notes": [
            {
              "title": "Class Notes डीपीपी- 40  गुरुत्वाकर्षण- 6 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/bee17cb4-9ef1-42c2-a30e-ae41708c5f38.pdf"
            }
          ]
        },
        {
          "serial": 41,
          "title": "डीपीपी- 41 || पदार्थ के तापीय गुण - 1 Video Solution",
          "published_date": "21 Jan 2025",
          "video_url": "https://www.youtube.com/embed/qY9dTiKHIy0",
          "hd_video_url": "https://www.youtube.com/embed/qY9dTiKHIy0",
          "thumbnail": "https://i.ytimg.com/vi/qY9dTiKHIy0/default.jpg",
          "notes": [
            {
              "title": "Class Notes डीपीपी- 41  पदार्थ के तापीय गुण - 1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/94388308-d0ab-4219-953f-079f18672f8a.pdf"
            }
          ]
        },
        {
          "serial": 42,
          "title": "डीपीपी- 42 || पदार्थ के तापीय गुण - 2 Video Solution",
          "published_date": "24 Jan 2025",
          "video_url": "https://www.youtube.com/embed/8R6lP77T1tc",
          "hd_video_url": "https://www.youtube.com/embed/8R6lP77T1tc",
          "thumbnail": "https://i.ytimg.com/vi/8R6lP77T1tc/default.jpg",
          "notes": [
            {
              "title": "Class Notes डीपीपी- 42  पदार्थ के तापीय गुण - 2 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/703b3763-2be5-40ae-a831-e204fd56afec.pdf"
            }
          ]
        },
        {
          "serial": 43,
          "title": "डीपीपी- 43 || पदार्थ के तापीय गुण - 3 Video Solution",
          "published_date": "28 Jan 2025",
          "video_url": "https://www.youtube.com/embed/0WMsoNIHmiM",
          "hd_video_url": "https://www.youtube.com/embed/0WMsoNIHmiM",
          "thumbnail": "https://i.ytimg.com/vi/0WMsoNIHmiM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 43 || पदार्थ के तापीय गुण - 3 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/77a77574-1954-4190-9b58-a02a7801f2b7.pdf"
            }
          ]
        },
        {
          "serial": 44,
          "title": "डीपीपी- 44 || पदार्थ के तापीय गुण - 4 Video Solution",
          "published_date": "28 Jan 2025",
          "video_url": "https://www.youtube.com/embed/43z3VyyM5Es",
          "hd_video_url": "https://www.youtube.com/embed/43z3VyyM5Es",
          "thumbnail": "https://i.ytimg.com/vi/43z3VyyM5Es/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 44 || पदार्थ के तापीय गुण - 4 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/94dc54f4-c89b-42eb-814a-d688b34173e0.pdf"
            }
          ]
        },
        {
          "serial": 45,
          "title": "डीपीपी- 45 || पदार्थ के तापीय गुण -5 Video Solution",
          "published_date": "01 Feb 2025",
          "video_url": "https://www.youtube.com/embed/JJkOc06mPNw",
          "hd_video_url": "https://www.youtube.com/embed/JJkOc06mPNw",
          "thumbnail": "https://i.ytimg.com/vi/JJkOc06mPNw/default.jpg",
          "notes": [
            {
              "title": "Class Notes -डीपीपी- 45 || पदार्थ के तापीय गुण -5 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c42cf870-6cd6-48ad-b7e4-d7265d43a7e4.pdf"
            }
          ]
        },
        {
          "serial": 46,
          "title": "डीपीपी- 46 || पदार्थ के तापीय गुण -6 Video Solution",
          "published_date": "03 Feb 2025",
          "video_url": "https://www.youtube.com/embed/YcBdMJYkatg",
          "hd_video_url": "https://www.youtube.com/embed/YcBdMJYkatg",
          "thumbnail": "https://i.ytimg.com/vi/YcBdMJYkatg/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 46 || पदार्थ के तापीय गुण -6 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/129275ce-aec6-4bf0-90e3-a6c993e0a457.pdf"
            }
          ]
        },
        {
          "serial": 47,
          "title": "डीपीपी- 47 || पदार्थ के तापीय गुण -7 Video Solution",
          "published_date": "15 Feb 2025",
          "video_url": "https://www.youtube.com/embed/wA70x0zbZTE",
          "hd_video_url": "https://www.youtube.com/embed/wA70x0zbZTE",
          "thumbnail": "https://i.ytimg.com/vi/wA70x0zbZTE/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 47 || पदार्थ के तापीय गुण -7 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a6afab64-ea19-484a-b56b-52188d32a83d.pdf"
            }
          ]
        },
        {
          "serial": 48,
          "title": "डीपीपी- 48 || पदार्थ के तापीय गुण -8 Video Solution",
          "published_date": "15 Feb 2025",
          "video_url": "https://www.youtube.com/embed/aruLvdJ3ID4",
          "hd_video_url": "https://www.youtube.com/embed/aruLvdJ3ID4",
          "thumbnail": "https://i.ytimg.com/vi/aruLvdJ3ID4/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 48 || पदार्थ के तापीय गुण -8 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2e129a4c-bb78-4c07-b38b-fc9785be06e5.pdf"
            }
          ]
        },
        {
          "serial": 49,
          "title": "डीपीपी- 49 || पदार्थ के तापीय गुण -9 Video Solution",
          "published_date": "15 Feb 2025",
          "video_url": "https://www.youtube.com/embed/oXSWrQmnazM",
          "hd_video_url": "https://www.youtube.com/embed/oXSWrQmnazM",
          "thumbnail": "https://i.ytimg.com/vi/oXSWrQmnazM/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 49 || पदार्थ के तापीय गुण -9 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/366ab9ee-ecf9-4a4a-9a65-7441ca764427.pdf"
            }
          ]
        },
        {
          "serial": 50,
          "title": "डीपीपी- 50 || विद्युत आवेश और क्षेत्र - 1 Video Solution",
          "published_date": "17 Feb 2025",
          "video_url": "https://www.youtube.com/embed/TAVcttt4uk0",
          "hd_video_url": "https://www.youtube.com/embed/TAVcttt4uk0",
          "thumbnail": "https://i.ytimg.com/vi/TAVcttt4uk0/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 47 || विद्युत आवेश और क्षेत्र - 1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/278d2008-5e48-4125-957c-cbfdf1e15c7c.pdf"
            }
          ]
        },
        {
          "serial": 51,
          "title": "डीपीपी- 51 || विद्युत आवेश और क्षेत्र - 2 Video Solution",
          "published_date": "17 Feb 2025",
          "video_url": "https://www.youtube.com/embed/LzLxTvIeLLs",
          "hd_video_url": "https://www.youtube.com/embed/LzLxTvIeLLs",
          "thumbnail": "https://i.ytimg.com/vi/LzLxTvIeLLs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 48 || विद्युत आवेश और क्षेत्र - 2 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/88baaf6f-214f-4862-afee-bd0bf2547d90.pdf"
            }
          ]
        },
        {
          "serial": 52,
          "title": "डीपीपी- 52 || विद्युत आवेश और क्षेत्र - 3 Video Solution",
          "published_date": "17 Feb 2025",
          "video_url": "https://www.youtube.com/embed/1mpLhqJMv9w",
          "hd_video_url": "https://www.youtube.com/embed/1mpLhqJMv9w",
          "thumbnail": "https://i.ytimg.com/vi/1mpLhqJMv9w/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 49 || विद्युत आवेश और क्षेत्र - 3 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3548eb61-c9c8-428b-8777-91a29fd4a929.pdf"
            }
          ]
        },
        {
          "serial": 53,
          "title": "डीपीपी- 53 || विद्युत आवेश और क्षेत्र - 4 Video Solution",
          "published_date": "22 Feb 2025",
          "video_url": "https://www.youtube.com/embed/HcvenMWCAkg",
          "hd_video_url": "https://www.youtube.com/embed/HcvenMWCAkg",
          "thumbnail": "https://i.ytimg.com/vi/HcvenMWCAkg/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 53 || विद्युत आवेश और क्षेत्र - 4 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/55aa0c8f-56ee-4ead-8f3d-5d8400331db2.pdf"
            }
          ]
        },
        {
          "serial": 54,
          "title": "डीपीपी- 54 || विद्युत आवेश और क्षेत्र -5  Video Solution",
          "published_date": "22 Feb 2025",
          "video_url": "https://www.youtube.com/embed/glxfvDxQwhA",
          "hd_video_url": "https://www.youtube.com/embed/glxfvDxQwhA",
          "thumbnail": "https://i.ytimg.com/vi/glxfvDxQwhA/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 54 || विद्युत आवेश और क्षेत्र -5  Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f7deeff4-c8a6-49bf-a5a8-21cc1ad27a7e.pdf"
            }
          ]
        },
        {
          "serial": 55,
          "title": "डीपीपी- 55 || स्थिर वैधुत विभव तथा संधारित्र -1 Video Solution",
          "published_date": "22 Feb 2025",
          "video_url": "https://www.youtube.com/embed/1QSC7MvDCp0",
          "hd_video_url": "https://www.youtube.com/embed/1QSC7MvDCp0",
          "thumbnail": "https://i.ytimg.com/vi/1QSC7MvDCp0/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 55 || स्थिर वैधुत विभव तथा संधारित्र -1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/73e2487c-757b-4f09-8dfb-69bc951ef3c4.pdf"
            }
          ]
        },
        {
          "serial": 56,
          "title": "डीपीपी- 56 || स्थिर वैधुत विभव तथा संधारित्र -2 Video Solution",
          "published_date": "03 Mar 2025",
          "video_url": "https://www.youtube.com/embed/6Upi068rFEA",
          "hd_video_url": "https://www.youtube.com/embed/6Upi068rFEA",
          "thumbnail": "https://i.ytimg.com/vi/6Upi068rFEA/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 56 || स्थिर वैधुत विभव तथा संधारित्र -2 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/04cc1dd0-fc7d-4526-8fbf-01ba5d75a217.pdf"
            }
          ]
        },
        {
          "serial": 57,
          "title": "डीपीपी- 57 || स्थिर वैधुत विभव तथा संधारित्र -3 Video Solution",
          "published_date": "03 Mar 2025",
          "video_url": "https://www.youtube.com/embed/Y5LkIuiPfR8",
          "hd_video_url": "https://www.youtube.com/embed/Y5LkIuiPfR8",
          "thumbnail": "https://i.ytimg.com/vi/Y5LkIuiPfR8/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 57 || स्थिर वैधुत विभव तथा संधारित्र -3 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3f5408eb-d79c-40e4-a9e8-dd7cedc0a5dd.pdf"
            }
          ]
        },
        {
          "serial": 58,
          "title": "डीपीपी- 58 || स्थिर वैधुत विभव तथा संधारित्र -4 Video Solution",
          "published_date": "03 Mar 2025",
          "video_url": "https://www.youtube.com/embed/I2j_2tblFjg",
          "hd_video_url": "https://www.youtube.com/embed/I2j_2tblFjg",
          "thumbnail": "https://i.ytimg.com/vi/I2j_2tblFjg/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 58 || स्थिर वैधुत विभव तथा संधारित्र -4 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4ad2ccd1-2ced-43df-bbe1-3a92e39fbc60.pdf"
            }
          ]
        },
        {
          "serial": 59,
          "title": "डीपीपी- 59 || गैसों का गतिक सिद्धांत तथा ऊष्मागतिकी -1 Video Solution",
          "published_date": "04 Mar 2025",
          "video_url": "https://www.youtube.com/embed/q4q9bUDxvt4",
          "hd_video_url": "https://www.youtube.com/embed/q4q9bUDxvt4",
          "thumbnail": "https://i.ytimg.com/vi/q4q9bUDxvt4/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 59 || गैसों का गतिक सिद्धांत तथा ऊष्मागतिकी -1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/30ab85f9-89e7-4f48-a7fd-8059c7f87875.pdf"
            }
          ]
        },
        {
          "serial": 60,
          "title": "डीपीपी- 60 || स्थिर वैधुत विभव तथा संधारित्र -5 Video Solution",
          "published_date": "19 Mar 2025",
          "video_url": "https://www.youtube.com/embed/c4SJVah2Ic4",
          "hd_video_url": "https://www.youtube.com/embed/c4SJVah2Ic4",
          "thumbnail": "https://i.ytimg.com/vi/c4SJVah2Ic4/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 60 || स्थिर वैधुत विभव तथा संधारित्र -5 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9c5e99b1-9d5d-4372-b4ba-5b334a41795b.pdf"
            }
          ]
        },
        {
          "serial": 61,
          "title": "डीपीपी- 61 || स्थिर वैधुत विभव तथा संधारित्र -6 Video Solution",
          "published_date": "25 Mar 2025",
          "video_url": "https://www.youtube.com/embed/p_g_3mmoWHg",
          "hd_video_url": "https://www.youtube.com/embed/p_g_3mmoWHg",
          "thumbnail": "https://i.ytimg.com/vi/p_g_3mmoWHg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - डीपीपी- 61 || स्थिर वैधुत विभव तथा संधारित्र -6 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/41710900-abd9-4ebd-97c7-e3a805391639.pdf"
            }
          ]
        },
        {
          "serial": 62,
          "title": "डीपीपी- 62 || विधुत धारा - 1 Video Solution",
          "published_date": "27 Mar 2025",
          "video_url": "https://www.youtube.com/embed/iWhmQR2nQHg",
          "hd_video_url": "https://www.youtube.com/embed/iWhmQR2nQHg",
          "thumbnail": "https://i.ytimg.com/vi/iWhmQR2nQHg/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 62 || विधुत धारा - 1 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/dd56e0f9-c4b9-422e-9339-3b1ec4eea76f.pdf"
            }
          ]
        },
        {
          "serial": 63,
          "title": "डीपीपी- 63 || विधुत धारा - 2 Video Solution",
          "published_date": "01 Apr 2025",
          "video_url": "https://www.youtube.com/embed/ih54u5b3xyc",
          "hd_video_url": "https://www.youtube.com/embed/ih54u5b3xyc",
          "thumbnail": "https://i.ytimg.com/vi/ih54u5b3xyc/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 63 || विधुत धारा - 2 Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b9cf0ed9-fced-4916-bd3a-58a5c6688e9b.pdf"
            }
          ]
        },
        {
          "serial": 64,
          "title": "डीपीपी- 64 || विधुत धारा -3  Video Solution",
          "published_date": "01 Apr 2025",
          "video_url": "https://www.youtube.com/embed/mDGzCBapfwE",
          "hd_video_url": "https://www.youtube.com/embed/mDGzCBapfwE",
          "thumbnail": "https://i.ytimg.com/vi/mDGzCBapfwE/default.jpg",
          "notes": [
            {
              "title": "डीपीपी- 64 || विधुत धारा -3  Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/662d0f3e-abb6-4e97-807b-f6d195663ba2.pdf"
            }
          ]
        }
      ],
      "notes": []
    },
    {
      "subject_name": "Test Paper and Solutions",
      "subject_id": 3425,
      "video_count": 0,
      "note_count": 0,
      "videos": [],
      "notes": []
    },
    {
      "subject_name": "Zoology by Shashank Yadav (Sapiens Sir)",
      "subject_id": 3424,
      "video_count": 117,
      "note_count": 117,
      "videos": [
        {
          "serial": 1,
          "title": "व्याख्यान- 01 || मानव जनन - 1",
          "published_date": "09 Sep 2024",
          "video_url": "https://www.youtube.com/embed/q80FeYL5Gp0",
          "hd_video_url": "https://www.youtube.com/embed/q80FeYL5Gp0",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 01 || मानव जनन - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/bf703b09-9faa-42d0-9fff-0ebd8410101e.pdf"
            }
          ]
        },
        {
          "serial": 2,
          "title": "व्याख्यान- 02 || मानव जनन - 2",
          "published_date": "10 Sep 2024",
          "video_url": "https://www.youtube.com/embed/zXRDAeyLlQQ",
          "hd_video_url": "https://www.youtube.com/embed/zXRDAeyLlQQ",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/thumb/uploads/eBt6oMm8D550bgvKtJkE32wWdTJkyZDTEIDkd90Q.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 02 || मानव जनन - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0fdb0b54-4ecd-4146-96a5-e0d4be75cc90.pdf"
            }
          ]
        },
        {
          "serial": 3,
          "title": "व्याख्यान- 03 || मानव जनन - 3",
          "published_date": "11 Sep 2024",
          "video_url": "https://www.youtube.com/embed/u8QOn1QEPFA",
          "hd_video_url": "https://www.youtube.com/embed/u8QOn1QEPFA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/0Y6cQKISlKYfS5H2EWuQbNrtY9lP0PV4Bk4f6KDh.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 03 || मानव जनन - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/881b94c4-d8b8-44df-886a-310114f337c1.pdf"
            }
          ]
        },
        {
          "serial": 4,
          "title": "व्याख्यान- 04 || मानव जनन - 4",
          "published_date": "16 Sep 2024",
          "video_url": "https://www.youtube.com/embed/fXQcsfPbPvw",
          "hd_video_url": "https://www.youtube.com/embed/fXQcsfPbPvw",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/WXDDYriyuw85t2OLgkQnR79BJrD1ELdEUiOii8mL.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 04 || मानव जनन - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/14cecc0e-985f-45f5-ba4f-ddc304fedf15.pdf"
            }
          ]
        },
        {
          "serial": 5,
          "title": "व्याख्यान- 05 || मानव जनन - 5",
          "published_date": "18 Sep 2024",
          "video_url": "https://www.youtube.com/embed/5VpU7Xc3whI",
          "hd_video_url": "https://www.youtube.com/embed/5VpU7Xc3whI",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/1QPzMCVrsfCpSosi6vjHK6kmVbdqKS4r5w7nDjIn.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 05 || मानव जनन - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/62d53404-d82a-4c23-be68-cc21f9fc519a.pdf"
            }
          ]
        },
        {
          "serial": 6,
          "title": "व्याख्यान- 06 || मानव जनन - 6",
          "published_date": "23 Sep 2024",
          "video_url": "https://www.youtube.com/embed/7zX9_eZQ73A",
          "hd_video_url": "https://www.youtube.com/embed/7zX9_eZQ73A",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/lTJHErFQtexzc7SjqncSC2BqaSbEqqzV3XZfMrOI.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 06 || मानव जनन - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/59a30401-ca14-431c-9af1-730c38c9c7db.pdf"
            }
          ]
        },
        {
          "serial": 7,
          "title": "व्याख्यान- 07 || मानव जनन - 7",
          "published_date": "24 Sep 2024",
          "video_url": "https://www.youtube.com/embed/345kT6n6fw8",
          "hd_video_url": "https://www.youtube.com/embed/345kT6n6fw8",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/wSl4oMHVIork6JfpzGJsYrpgQIJWBmMlGXHKYGge.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 07 || मानव जनन - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2326d908-90c7-45e4-9d6f-2fde91c1f178.pdf"
            }
          ]
        },
        {
          "serial": 8,
          "title": "व्याख्यान- 08 || मानव जनन - 8",
          "published_date": "25 Sep 2024",
          "video_url": "https://www.youtube.com/embed/8TC9gyiXx5A",
          "hd_video_url": "https://www.youtube.com/embed/8TC9gyiXx5A",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/ybcLI2DKjmN3jPDNsGtgX20SawENTRtz3bW0SdNU.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 08 || मानव जनन - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/193060e6-d80b-4b6a-98d9-260c6d5d3a2a.pdf"
            }
          ]
        },
        {
          "serial": 9,
          "title": "व्याख्यान- 09 || मानव जनन - 9",
          "published_date": "30 Sep 2024",
          "video_url": "https://www.youtube.com/embed/Tm4huK8CKJs",
          "hd_video_url": "https://www.youtube.com/embed/Tm4huK8CKJs",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/KpsDuMQsrMwxIIdX7wPzJc6uKWZfNRblMd1iVpfT.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 09 || मानव जनन - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c65edb2e-7cfe-4eff-9d4d-cd48342a77f2.pdf"
            }
          ]
        },
        {
          "serial": 10,
          "title": "व्याख्यान- 10 || मानव जनन - 10",
          "published_date": "01 Oct 2024",
          "video_url": "https://www.youtube.com/embed/EydPM4Fcx_8",
          "hd_video_url": "https://www.youtube.com/embed/EydPM4Fcx_8",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/CHlIeVnwPQ6UcTsAMHdOHq3YihA38g5q69HcxVwk.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 10 || मानव जनन - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/42639188-da13-4ff7-9de7-ff514852e9d5.pdf"
            }
          ]
        },
        {
          "serial": 11,
          "title": "व्याख्यान- 11 || मानव जनन - 11",
          "published_date": "06 Oct 2024",
          "video_url": "https://www.youtube.com/embed/ZBQ9HUnJPwg",
          "hd_video_url": "https://www.youtube.com/embed/ZBQ9HUnJPwg",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/k1TL6tAv4wHnhnY7R1BlyToEE9rQfSvXGLvmSqaP.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 11 || मानव जनन - 11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/34bca5bd-a6aa-4170-a9b1-a053299443fd.pdf"
            }
          ]
        },
        {
          "serial": 12,
          "title": "व्याख्यान- 12 ||  जनन स्वास्थ्य - 1",
          "published_date": "07 Oct 2024",
          "video_url": "https://www.youtube.com/embed/OjKFJjyIEJ4",
          "hd_video_url": "https://www.youtube.com/embed/OjKFJjyIEJ4",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/jKUFjSidBBrdg28ij4sl69IGyFNu8oIljKsxoxPI.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 12 || जनन स्वास्थ्य - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f7678784-2a2f-411c-aaf6-04d6f460b575.pdf"
            }
          ]
        },
        {
          "serial": 13,
          "title": "व्याख्यान- 13 || जनन स्वास्थ्य - 2",
          "published_date": "08 Oct 2024",
          "video_url": "https://www.youtube.com/embed/qlD9ipd8qQ4",
          "hd_video_url": "https://www.youtube.com/embed/qlD9ipd8qQ4",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/pFXy5kammPeBbJ0Bmb2CmfK4Ql6neS4eqz6Y0Dhi.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 13 || जनन स्वास्थ्य - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c97535e8-11fd-4012-a4a4-867a724a198d.pdf"
            }
          ]
        },
        {
          "serial": 14,
          "title": "व्याख्यान- 14 || जनन स्वास्थ्य - 3",
          "published_date": "09 Oct 2024",
          "video_url": "https://www.youtube.com/embed/CsDMXOJ9VUc",
          "hd_video_url": "https://www.youtube.com/embed/CsDMXOJ9VUc",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/h7GrlTkmnnwmdhoFjKe0rnjFpueyqaS7gRcUDxuj.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 14 || जनन स्वास्थ्य - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/169d5524-f79e-4b84-bae7-e1ead8644e6b.pdf"
            }
          ]
        },
        {
          "serial": 15,
          "title": "व्याख्यान- 15 || विकास - 1",
          "published_date": "16 Oct 2024",
          "video_url": "https://www.youtube.com/embed/i1vrRvRX1KM",
          "hd_video_url": "https://www.youtube.com/embed/i1vrRvRX1KM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/hLKe9PuBgKiqlwT1wqewDZkmClPyof71HvTJXCV0.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 14  विकास - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/77361fd9-3f01-46d2-8ae9-7e280d20f6a5.pdf"
            }
          ]
        },
        {
          "serial": 16,
          "title": "व्याख्यान- 15 || विकास - 2",
          "published_date": "21 Oct 2024",
          "video_url": "https://www.youtube.com/embed/Ipm4F1sUzCA",
          "hd_video_url": "https://www.youtube.com/embed/Ipm4F1sUzCA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/fcxUrgNxuhE0PoYswvTpX0IFpISvr4Yb16mPIDd4.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 15 || विकास - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/88e8ce1b-ec9a-4f18-be5b-cfd3212cf5e8.pdf"
            }
          ]
        },
        {
          "serial": 17,
          "title": "व्याख्यान- 16 || विकास - 3",
          "published_date": "22 Oct 2024",
          "video_url": "https://www.youtube.com/embed/-Nipzt_7OZU",
          "hd_video_url": "https://www.youtube.com/embed/-Nipzt_7OZU",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/ceGivdbMcTMPdb0zC0TPIbEuV2mrDf2XyEyugK0d.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 16 || विकास - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ec12cc03-5b91-4aa8-9567-63bc16814795.pdf"
            }
          ]
        },
        {
          "serial": 18,
          "title": "व्याख्यान- 17 || विकास - 4",
          "published_date": "23 Oct 2024",
          "video_url": "https://www.youtube.com/embed/gTSY5vGMq68",
          "hd_video_url": "https://www.youtube.com/embed/gTSY5vGMq68",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/crtXPnfkAa4sBeo5MLvXgzLl51dRZN4PCxOARuY9.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 17 || विकास - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1678c4c0-f2ac-4ad4-9d37-287b801afb94.pdf"
            }
          ]
        },
        {
          "serial": 19,
          "title": "व्याख्यान- 18 || विकास - 5",
          "published_date": "28 Oct 2024",
          "video_url": "https://www.youtube.com/embed/sG2yTz7n7m8",
          "hd_video_url": "https://www.youtube.com/embed/sG2yTz7n7m8",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/GHq3kFozpX9jaad0JdGRmLtDliJLWo5CfE0nU2xI.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 17 || विकास - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e821566c-70cb-4ce9-95c7-6426a526d18f.pdf"
            }
          ]
        },
        {
          "serial": 20,
          "title": "व्याख्यान- 19 || विकास - 6",
          "published_date": "29 Oct 2024",
          "video_url": "https://www.youtube.com/embed/yDT2pxMi1lM",
          "hd_video_url": "https://www.youtube.com/embed/yDT2pxMi1lM",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/4KyuXSuQgHsBohQCWoYVEZTURHOQP7JUET2zk4CY.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 19 || विकास - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ca3e234d-8b94-45cb-8934-8c17d39bcb5f.pdf"
            }
          ]
        },
        {
          "serial": 21,
          "title": "व्याख्यान- 20 || विकास - 7",
          "published_date": "04 Nov 2024",
          "video_url": "https://www.youtube.com/embed/uEBhez8vqNA",
          "hd_video_url": "https://www.youtube.com/embed/uEBhez8vqNA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/thumb/uploads/CfjgxdpwmxyUzjNA60HInyMsfVEwMsObFCTZqvcZ.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 20 || विकास - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d08de5cd-352d-484a-87e9-fe27934a320c.pdf"
            }
          ]
        },
        {
          "serial": 22,
          "title": "व्याख्यान- 21 || विकास - 8",
          "published_date": "05 Nov 2024",
          "video_url": "https://www.youtube.com/embed/SupsaXbaA1o",
          "hd_video_url": "https://www.youtube.com/embed/SupsaXbaA1o",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/0bXWOWYlP0p5gYsYInEdx3To5clfY8U0RbR598z1.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 21 || विकास - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/39dce1ef-3a0c-4be1-b5af-67fc46d4e533.pdf"
            }
          ]
        },
        {
          "serial": 23,
          "title": "व्याख्यान- 22 || मानव स्वास्थ्य और रोग -1",
          "published_date": "06 Nov 2024",
          "video_url": "https://www.youtube.com/embed/IfGJJ5QgDTY",
          "hd_video_url": "https://www.youtube.com/embed/IfGJJ5QgDTY",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/tiNCzDspraypdWUeQHVyBg43OAHT4gagZY01Kq31.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 22 || मानव स्वास्थ्य और रोग -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8b62972d-2ebd-44fc-b7df-efadf1a20126.pdf"
            }
          ]
        },
        {
          "serial": 24,
          "title": "व्याख्यान- 23 || मानव स्वास्थ्य और रोग -2",
          "published_date": "11 Nov 2024",
          "video_url": "https://www.youtube.com/embed/EcrDSPi6CoA",
          "hd_video_url": "https://www.youtube.com/embed/EcrDSPi6CoA",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/bgDf81atpoercm12kCUGWVIykWUMLaAaxUrhe1SC.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 23 || मानव स्वास्थ्य और रोग -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/66b73996-9115-408a-b7f7-9ad2e7a474f3.pdf"
            }
          ]
        },
        {
          "serial": 25,
          "title": "व्याख्यान- 24 || मानव स्वास्थ्य और रोग -3",
          "published_date": "12 Nov 2024",
          "video_url": "https://www.youtube.com/embed/362zaUTayTw",
          "hd_video_url": "https://www.youtube.com/embed/362zaUTayTw",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/Iqh66CialGHp4mxYN1YTB6IvPkCmp6XRO2co71wX.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 24 || मानव स्वास्थ्य और रोग -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/99d45ba2-bc46-493c-926e-abe86fb4d593.pdf"
            }
          ]
        },
        {
          "serial": 26,
          "title": "व्याख्यान- 25 || मानव स्वास्थ्य और रोग -4",
          "published_date": "13 Nov 2024",
          "video_url": "https://www.youtube.com/embed/zvUZMe5AIAg",
          "hd_video_url": "https://www.youtube.com/embed/zvUZMe5AIAg",
          "thumbnail": "https://kgs.nyc3.digitaloceanspaces.com/video-thumbs/X5fr5HqzqouHXAS6I27VJxtqYkj3hUQC22ifRPwU.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 25 || मानव स्वास्थ्य और रोग -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0f3eb2b9-dbd4-4f96-bb8d-d913a4ded3c6.pdf"
            }
          ]
        },
        {
          "serial": 27,
          "title": "व्याख्यान- 26 || मानव स्वास्थ्य और रोग -5",
          "published_date": "16 Nov 2024",
          "video_url": "https://www.youtube.com/embed/nrONt7Pm5fU",
          "hd_video_url": "https://www.youtube.com/embed/nrONt7Pm5fU",
          "thumbnail": "https://i.ytimg.com/vi/nrONt7Pm5fU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 26 || मानव स्वास्थ्य और रोग -5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/68037969-7a93-4d3b-90cb-cfd509259b38.pdf"
            }
          ]
        },
        {
          "serial": 28,
          "title": "व्याख्यान- 27 || मानव स्वास्थ्य और रोग -6",
          "published_date": "17 Nov 2024",
          "video_url": "https://www.youtube.com/embed/wulgH6zf7gM",
          "hd_video_url": "https://www.youtube.com/embed/wulgH6zf7gM",
          "thumbnail": "https://i.ytimg.com/vi/wulgH6zf7gM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 27 || मानव स्वास्थ्य और रोग -6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1eaba3cd-45fb-4b20-b2a1-9604cedab268.pdf"
            }
          ]
        },
        {
          "serial": 29,
          "title": "व्याख्यान- 28 || मानव स्वास्थ्य और रोग -7",
          "published_date": "18 Nov 2024",
          "video_url": "https://www.youtube.com/embed/8pyvFMMi0uw",
          "hd_video_url": "https://www.youtube.com/embed/8pyvFMMi0uw",
          "thumbnail": "https://i.ytimg.com/vi/8pyvFMMi0uw/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 28 || मानव स्वास्थ्य और रोग -7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/24382faf-1134-48fd-8ac0-64c780d68db8.pdf"
            }
          ]
        },
        {
          "serial": 30,
          "title": "व्याख्यान- 29 || मानव कल्याण मे सूक्ष्मजीव  - 1",
          "published_date": "19 Nov 2024",
          "video_url": "https://www.youtube.com/embed/B4KrxDrc3Gc",
          "hd_video_url": "https://www.youtube.com/embed/B4KrxDrc3Gc",
          "thumbnail": "https://i.ytimg.com/vi/B4KrxDrc3Gc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 29 || मानव कल्याण मे सूक्ष्मजीव  - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/44ecbe3e-3a5a-4869-845d-2f973e811987.pdf"
            }
          ]
        },
        {
          "serial": 31,
          "title": "व्याख्यान- 30 || मानव कल्याण मे सूक्ष्मजीव - 2",
          "published_date": "20 Nov 2024",
          "video_url": "https://www.youtube.com/embed/KzJytABa-UA",
          "hd_video_url": "https://www.youtube.com/embed/KzJytABa-UA",
          "thumbnail": "https://i.ytimg.com/vi/KzJytABa-UA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 30 || मानव कल्याण मे सूक्ष्मजीव - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/22c00302-2d33-4bcd-9707-eed0a3ef0ca1.pdf"
            }
          ]
        },
        {
          "serial": 32,
          "title": "व्याख्यान- 31 || मानव कल्याण मे सूक्ष्मजीव - 3",
          "published_date": "20 Nov 2024",
          "video_url": "https://www.youtube.com/embed/WITPs87mypU",
          "hd_video_url": "https://www.youtube.com/embed/WITPs87mypU",
          "thumbnail": "https://i.ytimg.com/vi/WITPs87mypU/default.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 31 || मानव कल्याण मे सूक्ष्मजीव - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/829ba611-fcbb-4928-bd1f-c36de65b3f00.pdf"
            }
          ]
        },
        {
          "serial": 33,
          "title": "व्याख्यान- 31 ||  प्राणी जगत - 1",
          "published_date": "21 Nov 2024",
          "video_url": "https://www.youtube.com/embed/MCeKdCXiJMk",
          "hd_video_url": "https://www.youtube.com/embed/MCeKdCXiJMk",
          "thumbnail": "https://i.ytimg.com/vi/MCeKdCXiJMk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 31 || प्राणी जगत - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0388fd2b-6987-481d-9b6d-e59060624e75.pdf"
            }
          ]
        },
        {
          "serial": 34,
          "title": "व्याख्यान- 32 || प्राणी जगत - 2",
          "published_date": "22 Nov 2024",
          "video_url": "https://www.youtube.com/embed/bn8qMp4Shhk",
          "hd_video_url": "https://www.youtube.com/embed/bn8qMp4Shhk",
          "thumbnail": "https://i.ytimg.com/vi/bn8qMp4Shhk/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 32 || प्राणी जगत - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2beb4acc-986d-4e12-8993-9799a2adf475.pdf"
            }
          ]
        },
        {
          "serial": 35,
          "title": "व्याख्यान- 33 || प्राणी जगत - 3",
          "published_date": "23 Nov 2024",
          "video_url": "https://www.youtube.com/embed/JEVk1ElPjS4",
          "hd_video_url": "https://www.youtube.com/embed/JEVk1ElPjS4",
          "thumbnail": "https://i.ytimg.com/vi/JEVk1ElPjS4/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 33  प्राणी जगत - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/22db823f-4290-4d13-9378-d5296990ac04.pdf"
            }
          ]
        },
        {
          "serial": 36,
          "title": "व्याख्यान- 34 || प्राणी जगत - 4",
          "published_date": "05 Dec 2024",
          "video_url": "https://www.youtube.com/embed/VR-5sU-iqes",
          "hd_video_url": "https://www.youtube.com/embed/VR-5sU-iqes",
          "thumbnail": "https://i.ytimg.com/vi/VR-5sU-iqes/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 34 || प्राणी जगत - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6a2a7199-c6a4-448a-b638-371262385e63.pdf"
            }
          ]
        },
        {
          "serial": 37,
          "title": "व्याख्यान- 35 || प्राणी जगत - 5",
          "published_date": "06 Dec 2024",
          "video_url": "https://www.youtube.com/embed/W7lUKajKHHo",
          "hd_video_url": "https://www.youtube.com/embed/W7lUKajKHHo",
          "thumbnail": "https://i.ytimg.com/vi/W7lUKajKHHo/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 35  प्राणी जगत - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c289d7bf-02da-471a-b001-8f5b0065c6e8.pdf"
            }
          ]
        },
        {
          "serial": 38,
          "title": "व्याख्यान- 36 || प्राणी जगत - 6",
          "published_date": "07 Dec 2024",
          "video_url": "https://www.youtube.com/embed/lY4x2DPOacI",
          "hd_video_url": "https://www.youtube.com/embed/lY4x2DPOacI",
          "thumbnail": "https://i.ytimg.com/vi/lY4x2DPOacI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 36 || प्राणी जगत - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9253d775-da76-4215-b00f-d223d4a3ad03.pdf"
            }
          ]
        },
        {
          "serial": 39,
          "title": "व्याख्यान- 37 || प्राणी जगत - 7",
          "published_date": "12 Dec 2024",
          "video_url": "https://www.youtube.com/embed/otJb2TQgD78",
          "hd_video_url": "https://www.youtube.com/embed/otJb2TQgD78",
          "thumbnail": "https://i.ytimg.com/vi/otJb2TQgD78/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 37 || प्राणी जगत - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/e0391206-2c92-44d0-a1ca-f49d746b0c27.pdf"
            }
          ]
        },
        {
          "serial": 40,
          "title": "व्याख्यान- 38 || प्राणी जगत - 8",
          "published_date": "13 Dec 2024",
          "video_url": "https://www.youtube.com/embed/iava9868Bu0",
          "hd_video_url": "https://www.youtube.com/embed/iava9868Bu0",
          "thumbnail": "https://i.ytimg.com/vi/iava9868Bu0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 38 || प्राणी जगत - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fd836746-f95d-4ef2-b949-f2480a4cc3b2.pdf"
            }
          ]
        },
        {
          "serial": 41,
          "title": "व्याख्यान- 39 || प्राणी जगत - 9",
          "published_date": "14 Dec 2024",
          "video_url": "https://www.youtube.com/embed/7O9vObz8NuE",
          "hd_video_url": "https://www.youtube.com/embed/7O9vObz8NuE",
          "thumbnail": "https://i.ytimg.com/vi/7O9vObz8NuE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 39 || प्राणी जगत - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d6d9c851-aa3a-4e9a-af58-fffb61bde23a.pdf"
            }
          ]
        },
        {
          "serial": 42,
          "title": "व्याख्यान- 40 || Unit Test- 3 Discussion",
          "published_date": "14 Dec 2024",
          "video_url": "https://www.youtube.com/embed/S-kiS8Eq07E",
          "hd_video_url": "https://www.youtube.com/embed/S-kiS8Eq07E",
          "thumbnail": "https://i.ytimg.com/vi/S-kiS8Eq07E/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 40 || Unit Test- 3 Discussion",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9293215b-7c78-4891-9088-222a4296f9a1.pdf"
            }
          ]
        },
        {
          "serial": 43,
          "title": "व्याख्यान- 41 || प्राणी जगत - 10",
          "published_date": "15 Dec 2024",
          "video_url": "https://www.youtube.com/embed/NxUU0ufBvjI",
          "hd_video_url": "https://www.youtube.com/embed/NxUU0ufBvjI",
          "thumbnail": "https://i.ytimg.com/vi/NxUU0ufBvjI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 41 || प्राणी जगत - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9181eac3-035d-49a7-a3b6-d326ed92c06a.pdf"
            }
          ]
        },
        {
          "serial": 44,
          "title": "व्याख्यान- 42 || जीवों में संरचनात्मक संगठन - 1",
          "published_date": "19 Dec 2024",
          "video_url": "https://www.youtube.com/embed/g7PjTNS_I0Y",
          "hd_video_url": "https://www.youtube.com/embed/g7PjTNS_I0Y",
          "thumbnail": "https://i.ytimg.com/vi/g7PjTNS_I0Y/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 42 || जीवों में संरचनात्मक संगठन - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/53497554-e0c0-4280-8cba-af47d90c2177.pdf"
            }
          ]
        },
        {
          "serial": 45,
          "title": "व्याख्यान- 43 || जीवों में संरचनात्मक संगठन - 2",
          "published_date": "20 Dec 2024",
          "video_url": "https://www.youtube.com/embed/oOY1ZTNSNy8",
          "hd_video_url": "https://www.youtube.com/embed/oOY1ZTNSNy8",
          "thumbnail": "https://i.ytimg.com/vi/oOY1ZTNSNy8/default.jpg",
          "notes": [
            {
              "title": "Class Notes -  व्याख्यान- 43 || जीवों में संरचनात्मक संगठन - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a06b87a2-84cf-442f-b5c9-3d654da72599.pdf"
            }
          ]
        },
        {
          "serial": 46,
          "title": "व्याख्यान- 44 || जीवों में संरचनात्मक संगठन - 3",
          "published_date": "26 Dec 2024",
          "video_url": "https://www.youtube.com/embed/tGlc1IXtfVI",
          "hd_video_url": "https://www.youtube.com/embed/tGlc1IXtfVI",
          "thumbnail": "https://i.ytimg.com/vi/tGlc1IXtfVI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 44 || जीवों में संरचनात्मक संगठन - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/553e7a1f-bf8b-4c56-bb12-4747217fbb69.pdf"
            }
          ]
        },
        {
          "serial": 47,
          "title": "व्याख्यान- 45 || जीवों में संरचनात्मक संगठन - 4",
          "published_date": "27 Dec 2024",
          "video_url": "https://www.youtube.com/embed/1IOz830_2Ls",
          "hd_video_url": "https://www.youtube.com/embed/1IOz830_2Ls",
          "thumbnail": "https://i.ytimg.com/vi/1IOz830_2Ls/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 45 || जीवों में संरचनात्मक संगठन - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1c6fc2c3-4c45-461f-ad72-14ec48373561.pdf"
            }
          ]
        },
        {
          "serial": 48,
          "title": "व्याख्यान- 46 || जीवों में संरचनात्मक संगठन - 5",
          "published_date": "28 Dec 2024",
          "video_url": "https://www.youtube.com/embed/1t_so9plh9c",
          "hd_video_url": "https://www.youtube.com/embed/1t_so9plh9c",
          "thumbnail": "https://i.ytimg.com/vi/1t_so9plh9c/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 46 || जीवों में संरचनात्मक संगठन - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/bf606c80-4a6c-458c-b4d0-c44228530897.pdf"
            }
          ]
        },
        {
          "serial": 49,
          "title": "व्याख्यान- 47 || Unit Test 4 Discussion",
          "published_date": "28 Dec 2024",
          "video_url": "https://www.youtube.com/embed/Eu9bpJknyfc",
          "hd_video_url": "https://www.youtube.com/embed/Eu9bpJknyfc",
          "thumbnail": "https://i.ytimg.com/vi/Eu9bpJknyfc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 47 || Unit Test 4 Discussion",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/90bf9c41-e30e-441e-b535-7e5659d4d158.pdf"
            }
          ]
        },
        {
          "serial": 50,
          "title": "व्याख्यान- 48 || जीवों में संरचनात्मक संगठन - 6",
          "published_date": "02 Jan 2025",
          "video_url": "https://www.youtube.com/embed/rXazKQ_gWkU",
          "hd_video_url": "https://www.youtube.com/embed/rXazKQ_gWkU",
          "thumbnail": "https://i.ytimg.com/vi/rXazKQ_gWkU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 48 || जीवों में संरचनात्मक संगठन - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1a0c1bfb-a63e-49c0-9a58-4c37892f746f.pdf"
            }
          ]
        },
        {
          "serial": 51,
          "title": "व्याख्यान- 49 || जीवों में संरचनात्मक संगठन - 7",
          "published_date": "04 Jan 2025",
          "video_url": "https://www.youtube.com/embed/XZ0T2AHJf1g",
          "hd_video_url": "https://www.youtube.com/embed/XZ0T2AHJf1g",
          "thumbnail": "https://i.ytimg.com/vi/XZ0T2AHJf1g/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 49 || जीवों में संरचनात्मक संगठन - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/21aa5dc1-5e4c-412f-903e-d5a0b8d64610.pdf"
            }
          ]
        },
        {
          "serial": 52,
          "title": "व्याख्यान- 50 || जीवों में संरचनात्मक संगठन - 8",
          "published_date": "09 Jan 2025",
          "video_url": "https://www.youtube.com/embed/9p8hYZqZUC8",
          "hd_video_url": "https://www.youtube.com/embed/9p8hYZqZUC8",
          "thumbnail": "https://i.ytimg.com/vi/9p8hYZqZUC8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 50 || जीवों में संरचनात्मक संगठन - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/2b8f719c-1084-4fa0-b8f5-7a272acc93c1.pdf"
            }
          ]
        },
        {
          "serial": 53,
          "title": "व्याख्यान- 51 || जीवों में संरचनात्मक संगठन - 9",
          "published_date": "10 Jan 2025",
          "video_url": "https://www.youtube.com/embed/4hYnDXeEiow",
          "hd_video_url": "https://www.youtube.com/embed/4hYnDXeEiow",
          "thumbnail": "https://i.ytimg.com/vi/4hYnDXeEiow/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 51 || जीवों में संरचनात्मक संगठन - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6ff94bc0-05d6-4f25-bcae-3fe1803a7d0a.pdf"
            }
          ]
        },
        {
          "serial": 54,
          "title": "व्याख्यान- 52 || जीवों में संरचनात्मक संगठन - 10",
          "published_date": "11 Jan 2025",
          "video_url": "https://www.youtube.com/embed/ZfFWn-eO6BQ",
          "hd_video_url": "https://www.youtube.com/embed/ZfFWn-eO6BQ",
          "thumbnail": "https://i.ytimg.com/vi/ZfFWn-eO6BQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 52 || जीवों में संरचनात्मक संगठन - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c18f7e0b-7296-4bf7-b733-34f14886c923.pdf"
            }
          ]
        },
        {
          "serial": 55,
          "title": "व्याख्यान- 53 || जीवों में संरचनात्मक संगठन - 11",
          "published_date": "13 Jan 2025",
          "video_url": "https://www.youtube.com/embed/G5SCtimRvNA",
          "hd_video_url": "https://www.youtube.com/embed/G5SCtimRvNA",
          "thumbnail": "https://i.ytimg.com/vi/G5SCtimRvNA/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 53 || जीवों में संरचनात्मक संगठन - 11",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/559bb0f4-fcd9-472d-bd44-8207713ac50c.pdf"
            }
          ]
        },
        {
          "serial": 56,
          "title": "व्याख्यान- 54 || जीवों में संरचनात्मक संगठन - 12",
          "published_date": "16 Jan 2025",
          "video_url": "https://www.youtube.com/embed/kvF85AWIbJ8",
          "hd_video_url": "https://www.youtube.com/embed/kvF85AWIbJ8",
          "thumbnail": "https://i.ytimg.com/vi/kvF85AWIbJ8/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 54  जीवों में संरचनात्मक संगठन - 12",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f3c1d87b-11e4-4cb0-9f2c-4e77875cb955.pdf"
            }
          ]
        },
        {
          "serial": 57,
          "title": "व्याख्यान- 55 || जीवों में संरचनात्मक संगठन - 13",
          "published_date": "17 Jan 2025",
          "video_url": "https://www.youtube.com/embed/Tc93mxW4mxs",
          "hd_video_url": "https://www.youtube.com/embed/Tc93mxW4mxs",
          "thumbnail": "https://i.ytimg.com/vi/Tc93mxW4mxs/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 55  जीवों में संरचनात्मक संगठन - 13",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3023395f-1139-4b57-8ab0-81143e3ee0d2.pdf"
            }
          ]
        },
        {
          "serial": 58,
          "title": "व्याख्यान- 56 || जीवों में संरचनात्मक संगठन - 14",
          "published_date": "18 Jan 2025",
          "video_url": "https://www.youtube.com/embed/LlXfexkPzss",
          "hd_video_url": "https://www.youtube.com/embed/LlXfexkPzss",
          "thumbnail": "https://i.ytimg.com/vi/LlXfexkPzss/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 56 || जीवों में संरचनात्मक संगठन - 14",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/df0f6e13-437d-4e92-8632-281ac5d2dddc.pdf"
            }
          ]
        },
        {
          "serial": 59,
          "title": "व्याख्यान- 57 || जैव अणु - 1",
          "published_date": "23 Jan 2025",
          "video_url": "https://www.youtube.com/embed/73gjPsUVsh4",
          "hd_video_url": "https://www.youtube.com/embed/73gjPsUVsh4",
          "thumbnail": "https://i.ytimg.com/vi/73gjPsUVsh4/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 57  जैव अणु - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f49d39a6-d2eb-4e82-9174-b37c0b17d45a.pdf"
            }
          ]
        },
        {
          "serial": 60,
          "title": "व्याख्यान- 58 || जैव अणु - 2",
          "published_date": "24 Jan 2025",
          "video_url": "https://www.youtube.com/embed/ZxZ5MffYDXQ",
          "hd_video_url": "https://www.youtube.com/embed/ZxZ5MffYDXQ",
          "thumbnail": "https://i.ytimg.com/vi/ZxZ5MffYDXQ/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 58  जैव अणु - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/5f8d1c5c-4b72-45f0-bb41-f3591cf08ae7.pdf"
            }
          ]
        },
        {
          "serial": 61,
          "title": "व्याख्यान- 59 || जैव अणु - 3",
          "published_date": "25 Jan 2025",
          "video_url": "https://www.youtube.com/embed/PB5g-Z-pEPg",
          "hd_video_url": "https://www.youtube.com/embed/PB5g-Z-pEPg",
          "thumbnail": "https://i.ytimg.com/vi/PB5g-Z-pEPg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 59 || जैव अणु - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/21f0a90b-4e08-4768-a972-94cd6a43e178.pdf"
            }
          ]
        },
        {
          "serial": 62,
          "title": "व्याख्यान- 60 || जैव अणु - 4",
          "published_date": "30 Jan 2025",
          "video_url": "https://www.youtube.com/embed/_-lgoMS2QDg",
          "hd_video_url": "https://www.youtube.com/embed/_-lgoMS2QDg",
          "thumbnail": "https://i.ytimg.com/vi/_-lgoMS2QDg/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 60 || जैव अणु - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/05018ac3-cf19-4694-a761-55d3f2f8b341.pdf"
            }
          ]
        },
        {
          "serial": 63,
          "title": "व्याख्यान- 61 || जैव अणु - 5",
          "published_date": "31 Jan 2025",
          "video_url": "https://www.youtube.com/embed/E2vBu8edn7U",
          "hd_video_url": "https://www.youtube.com/embed/E2vBu8edn7U",
          "thumbnail": "https://i.ytimg.com/vi/E2vBu8edn7U/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 61 || जैव अणु - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9de9a493-7d50-4abe-9055-a86561b27187.pdf"
            }
          ]
        },
        {
          "serial": 64,
          "title": "व्याख्यान- 62 || जैव अणु - 6",
          "published_date": "01 Feb 2025",
          "video_url": "https://www.youtube.com/embed/l1T3fwSM1no",
          "hd_video_url": "https://www.youtube.com/embed/l1T3fwSM1no",
          "thumbnail": "https://i.ytimg.com/vi/l1T3fwSM1no/default.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 62 || जैव अणु - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/13e6b6c4-aa5a-4664-bd3d-82cb11bf7d48.pdf"
            }
          ]
        },
        {
          "serial": 65,
          "title": "व्याख्यान- 63 || जैव अणु - 7",
          "published_date": "06 Feb 2025",
          "video_url": "https://www.youtube.com/embed/eg2PhyCxXiM",
          "hd_video_url": "https://www.youtube.com/embed/eg2PhyCxXiM",
          "thumbnail": "https://i.ytimg.com/vi/eg2PhyCxXiM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 63 || जैव अणु - 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4ce1c26d-a125-42d4-acea-8cb326284aad.pdf"
            }
          ]
        },
        {
          "serial": 66,
          "title": "व्याख्यान- 64 || जैव अणु - 8",
          "published_date": "07 Feb 2025",
          "video_url": "https://www.youtube.com/embed/DtRPeaJLzO8",
          "hd_video_url": "https://www.youtube.com/embed/DtRPeaJLzO8",
          "thumbnail": "https://i.ytimg.com/vi/DtRPeaJLzO8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 64 || जैव अणु - 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d2a03f9d-59de-4d77-8d9c-dd9ee879b43c.pdf"
            }
          ]
        },
        {
          "serial": 67,
          "title": "व्याख्यान- 65 || जैव अणु - 9",
          "published_date": "08 Feb 2025",
          "video_url": "https://www.youtube.com/embed/ChCTy5uF7EY",
          "hd_video_url": "https://www.youtube.com/embed/ChCTy5uF7EY",
          "thumbnail": "https://i.ytimg.com/vi/ChCTy5uF7EY/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 65 || जैव अणु - 9",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f1b11975-0f6b-4a25-ac7a-20a5e3afc6ba.pdf"
            }
          ]
        },
        {
          "serial": 68,
          "title": "व्याख्यान- 66 || जैव अणु - 10",
          "published_date": "09 Feb 2025",
          "video_url": "https://www.youtube.com/embed/eUeVXTz1CJE",
          "hd_video_url": "https://www.youtube.com/embed/eUeVXTz1CJE",
          "thumbnail": "https://i.ytimg.com/vi/eUeVXTz1CJE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 66 || जैव अणु - 10",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/7fe7ec14-1f9f-454f-8b9b-eb74f3e384a1.pdf"
            }
          ]
        },
        {
          "serial": 69,
          "title": "व्याख्यान- 68 || श्वसन और गैसों का विनिमय- 1",
          "published_date": "15 Feb 2025",
          "video_url": "https://www.youtube.com/embed/lkH8begC054",
          "hd_video_url": "https://www.youtube.com/embed/lkH8begC054",
          "thumbnail": "https://i.ytimg.com/vi/lkH8begC054/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 68 || श्वसन और गैसों का विनिमय- 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/77aee6fd-2c1f-4df3-808e-8778f72d7d81.pdf"
            }
          ]
        },
        {
          "serial": 70,
          "title": "व्याख्यान- 69 || श्वास और गैसों का  विनिमय- 2",
          "published_date": "15 Feb 2025",
          "video_url": "https://www.youtube.com/embed/tYmDZxtWNQ0",
          "hd_video_url": "https://www.youtube.com/embed/tYmDZxtWNQ0",
          "thumbnail": "https://i.ytimg.com/vi/tYmDZxtWNQ0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 69 || श्वास और गैसों का  विनिमय- 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/41ddf390-c708-450a-b4f0-cb526a3e342a.pdf"
            }
          ]
        },
        {
          "serial": 71,
          "title": "व्याख्यान- 70 || श्वास और गैसों का विनिमय- 3",
          "published_date": "18 Feb 2025",
          "video_url": "https://www.youtube.com/embed/z6p_iYvI6f8",
          "hd_video_url": "https://www.youtube.com/embed/z6p_iYvI6f8",
          "thumbnail": "https://i.ytimg.com/vi/z6p_iYvI6f8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 70 || श्वास और गैसों का विनिमय- 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/aefe225b-b4a8-4e20-8f96-2539387a3f30.pdf"
            }
          ]
        },
        {
          "serial": 72,
          "title": "व्याख्यान- 71 || श्वास और गैसों का विनिमय- 4",
          "published_date": "19 Feb 2025",
          "video_url": "https://www.youtube.com/embed/LnCfM7OTCK8",
          "hd_video_url": "https://www.youtube.com/embed/LnCfM7OTCK8",
          "thumbnail": "https://i.ytimg.com/vi/LnCfM7OTCK8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 71 || श्वास और गैसों का विनिमय- 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/50391631-51e9-4e0e-bb51-2e252e342ae7.pdf"
            }
          ]
        },
        {
          "serial": 73,
          "title": "व्याख्यान- 72 || श्वास और गैसों का विनिमय- 5",
          "published_date": "20 Feb 2025",
          "video_url": "https://www.youtube.com/embed/VuuvCmMpgQc",
          "hd_video_url": "https://www.youtube.com/embed/VuuvCmMpgQc",
          "thumbnail": "https://i.ytimg.com/vi/VuuvCmMpgQc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 72 || श्वास और गैसों का विनिमय- 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/122176ca-aba3-4046-82e0-89342eadf583.pdf"
            }
          ]
        },
        {
          "serial": 74,
          "title": "व्याख्यान- 73 || श्वास और गैसों का विनिमय- 6",
          "published_date": "21 Feb 2025",
          "video_url": "https://www.youtube.com/embed/cj6uSPVlOQw",
          "hd_video_url": "https://www.youtube.com/embed/cj6uSPVlOQw",
          "thumbnail": "https://i.ytimg.com/vi/cj6uSPVlOQw/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 73 || श्वास और गैसों का विनिमय- 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3b9517a8-2989-4567-b1a1-3ab7177e15da.pdf"
            }
          ]
        },
        {
          "serial": 75,
          "title": "व्याख्यान- 74 || श्वास और गैसों का विनिमय- 7",
          "published_date": "22 Feb 2025",
          "video_url": "https://www.youtube.com/embed/TD6ZyZgRiQc",
          "hd_video_url": "https://www.youtube.com/embed/TD6ZyZgRiQc",
          "thumbnail": "https://i.ytimg.com/vi/TD6ZyZgRiQc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 74 || श्वास और गैसों का विनिमय- 7",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/94a0cca2-95aa-4dc7-b90e-11ece05a54ff.pdf"
            }
          ]
        },
        {
          "serial": 76,
          "title": "व्याख्यान- 75 || श्वास और गैसों का विनिमय- 8",
          "published_date": "27 Feb 2025",
          "video_url": "https://www.youtube.com/embed/kMyHRl09TBc",
          "hd_video_url": "https://www.youtube.com/embed/kMyHRl09TBc",
          "thumbnail": "https://i.ytimg.com/vi/kMyHRl09TBc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 75 || श्वास और गैसों का विनिमय- 8",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d45d9f87-dbdb-4a00-839a-253843b649f8.pdf"
            }
          ]
        },
        {
          "serial": 77,
          "title": "व्याख्यान- 76 || शारीरिक द्रव और परिसंचरण - 1",
          "published_date": "28 Feb 2025",
          "video_url": "https://www.youtube.com/embed/QVMmISRkpnI",
          "hd_video_url": "https://www.youtube.com/embed/QVMmISRkpnI",
          "thumbnail": "https://i.ytimg.com/vi/QVMmISRkpnI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 76 || शारीरिक द्रव और परिसंचरण - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/60a65e3f-9d1e-42e5-a1ae-902218841d73.pdf"
            }
          ]
        },
        {
          "serial": 78,
          "title": "व्याख्यान- 77 || शारीरिक द्रव और परिसंचरण - 2",
          "published_date": "01 Mar 2025",
          "video_url": "https://www.youtube.com/embed/fg25CfDE3nI",
          "hd_video_url": "https://www.youtube.com/embed/fg25CfDE3nI",
          "thumbnail": "https://i.ytimg.com/vi/fg25CfDE3nI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 77 || शारीरिक द्रव और परिसंचरण - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1027c346-0cc5-4a9f-8b4d-1693abdfdeda.pdf"
            }
          ]
        },
        {
          "serial": 79,
          "title": "व्याख्यान- 78 || शारीरिक द्रव और परिसंचरण - 3",
          "published_date": "01 Mar 2025",
          "video_url": "https://www.youtube.com/embed/WA-uYCtJ1Yc",
          "hd_video_url": "https://www.youtube.com/embed/WA-uYCtJ1Yc",
          "thumbnail": "https://i.ytimg.com/vi/WA-uYCtJ1Yc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 78 || शारीरिक द्रव और परिसंचरण - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/de63c237-a389-4887-aaca-0dea0378a006.pdf"
            }
          ]
        },
        {
          "serial": 80,
          "title": "व्याख्यान- 79 || शारीरिक द्रव और परिसंचरण - 4",
          "published_date": "02 Mar 2025",
          "video_url": "https://www.youtube.com/embed/pGtHinCYtf8",
          "hd_video_url": "https://www.youtube.com/embed/pGtHinCYtf8",
          "thumbnail": "https://i.ytimg.com/vi/pGtHinCYtf8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 79 || शारीरिक द्रव और परिसंचरण - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0d693958-cbc2-4407-a2c3-2924d9d04443.pdf"
            }
          ]
        },
        {
          "serial": 81,
          "title": "व्याख्यान- 80 || शारीरिक द्रव और परिसंचरण - 5",
          "published_date": "04 Mar 2025",
          "video_url": "https://www.youtube.com/embed/HKgUxHSsmjM",
          "hd_video_url": "https://www.youtube.com/embed/HKgUxHSsmjM",
          "thumbnail": "https://i.ytimg.com/vi/HKgUxHSsmjM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 80 || शारीरिक द्रव और परिसंचरण - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/85402f14-1117-4021-b62f-69696bf565bb.pdf"
            }
          ]
        },
        {
          "serial": 82,
          "title": "व्याख्यान- 81 || शारीरिक द्रव और परिसंचरण - 6",
          "published_date": "05 Mar 2025",
          "video_url": "https://www.youtube.com/embed/mW9L7Al90mA",
          "hd_video_url": "https://www.youtube.com/embed/mW9L7Al90mA",
          "thumbnail": "https://i.ytimg.com/vi/mW9L7Al90mA/default.jpg",
          "notes": [
            {
              "title": "Class Notes -व्याख्यान- 81 || शारीरिक द्रव और परिसंचरण - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/83d4fead-f3ed-4bfe-a559-da09e0aaa592.pdf"
            }
          ]
        },
        {
          "serial": 83,
          "title": "व्याख्यान- 82 || उत्सर्जी उत्पाद और उनका उन्मूलन - 1",
          "published_date": "06 Mar 2025",
          "video_url": "https://www.youtube.com/embed/HwVkbTxhbS4",
          "hd_video_url": "https://www.youtube.com/embed/HwVkbTxhbS4",
          "thumbnail": "https://i.ytimg.com/vi/HwVkbTxhbS4/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 82 || उत्सर्जी उत्पाद और उनका उन्मूलन - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/997f1d6b-ad3a-4dda-b74c-d969e1becb6e.pdf"
            }
          ]
        },
        {
          "serial": 84,
          "title": "व्याख्यान- 83 || उत्सर्जी उत्पाद और उनका उन्मूलन - 2",
          "published_date": "07 Mar 2025",
          "video_url": "https://www.youtube.com/embed/i8jrUClts6Q",
          "hd_video_url": "https://www.youtube.com/embed/i8jrUClts6Q",
          "thumbnail": "https://i.ytimg.com/vi/i8jrUClts6Q/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 83 || उत्सर्जी उत्पाद और उनका उन्मूलन - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/dd20162a-8ed3-49f6-a45a-4c128ddb4a24.pdf"
            }
          ]
        },
        {
          "serial": 85,
          "title": "व्याख्यान- 84 || उत्सर्जी उत्पाद और उनका उन्मूलन - 3",
          "published_date": "08 Mar 2025",
          "video_url": "https://www.youtube.com/embed/GW44vZzAwSU",
          "hd_video_url": "https://www.youtube.com/embed/GW44vZzAwSU",
          "thumbnail": "https://i.ytimg.com/vi/GW44vZzAwSU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 84 || उत्सर्जी उत्पाद और उनका उन्मूलन - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4b19e245-e6a9-47be-90a9-65eb22da3bd7.pdf"
            }
          ]
        },
        {
          "serial": 86,
          "title": "व्याख्यान- 85 || उत्सर्जी उत्पाद और उनका उन्मूलन - 4",
          "published_date": "09 Mar 2025",
          "video_url": "https://www.youtube.com/embed/v7-IP7tk2g4",
          "hd_video_url": "https://www.youtube.com/embed/v7-IP7tk2g4",
          "thumbnail": "https://i.ytimg.com/vi/v7-IP7tk2g4/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 85 || उत्सर्जी उत्पाद और उनका उन्मूलन - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8bf7bac7-e70b-4dc6-9aaf-2103f8efc4a3.pdf"
            }
          ]
        },
        {
          "serial": 87,
          "title": "व्याख्यान- 86 || उत्सर्जी उत्पाद और उनका उन्मूलन - 5",
          "published_date": "10 Mar 2025",
          "video_url": "https://www.youtube.com/embed/0QTtveG48Qc",
          "hd_video_url": "https://www.youtube.com/embed/0QTtveG48Qc",
          "thumbnail": "https://i.ytimg.com/vi/0QTtveG48Qc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 86 || उत्सर्जी उत्पाद और उनका उन्मूलन - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/fb605d57-664b-4bea-a98c-fee3805531c4.pdf"
            }
          ]
        },
        {
          "serial": 88,
          "title": "व्याख्यान- 87 || उत्सर्जी उत्पाद और उनका उन्मूलन - 6",
          "published_date": "11 Mar 2025",
          "video_url": "https://www.youtube.com/embed/FLyvZdPAxHE",
          "hd_video_url": "https://www.youtube.com/embed/FLyvZdPAxHE",
          "thumbnail": "https://i.ytimg.com/vi/FLyvZdPAxHE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 87 || उत्सर्जी उत्पाद और उनका उन्मूलन - 6",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9e9777cc-3941-4490-a2a1-5dbb8f4b9042.pdf"
            }
          ]
        },
        {
          "serial": 89,
          "title": "व्याख्यान- 88 || गमन एवं संचलन -1",
          "published_date": "12 Mar 2025",
          "video_url": "https://www.youtube.com/embed/qLHHJf-TuVg",
          "hd_video_url": "https://www.youtube.com/embed/qLHHJf-TuVg",
          "thumbnail": "https://i.ytimg.com/vi/qLHHJf-TuVg/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 88 || गमन एवं संचलन -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ca82b780-ec9e-45fc-b32e-fc7fef5521fa.pdf"
            }
          ]
        },
        {
          "serial": 90,
          "title": "व्याख्यान- 89 || गमन एवं संचलन -2",
          "published_date": "17 Mar 2025",
          "video_url": "https://www.youtube.com/embed/1V299_xcb4M",
          "hd_video_url": "https://www.youtube.com/embed/1V299_xcb4M",
          "thumbnail": "https://i.ytimg.com/vi/1V299_xcb4M/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 89 || गमन एवं संचलन -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/39b3a44c-0c6e-459f-aaee-8cb05450c017.pdf"
            }
          ]
        },
        {
          "serial": 91,
          "title": "व्याख्यान- 90 || गमन एवं संचलन -3",
          "published_date": "18 Mar 2025",
          "video_url": "https://www.youtube.com/embed/w5dJ0bDjUR0",
          "hd_video_url": "https://www.youtube.com/embed/w5dJ0bDjUR0",
          "thumbnail": "https://i.ytimg.com/vi/w5dJ0bDjUR0/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 90 || गमन एवं संचलन -3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a61fd539-6f21-43cd-968e-90bac8040566.pdf"
            }
          ]
        },
        {
          "serial": 92,
          "title": "व्याख्यान- 91 || गमन एवं संचलन -4",
          "published_date": "18 Mar 2025",
          "video_url": "https://www.youtube.com/embed/xzNCeedruGc",
          "hd_video_url": "https://www.youtube.com/embed/xzNCeedruGc",
          "thumbnail": "https://i.ytimg.com/vi/xzNCeedruGc/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 91 || गमन एवं संचलन -4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a3d37a65-48cd-49de-9da7-0ffc73d5dec7.pdf"
            }
          ]
        },
        {
          "serial": 93,
          "title": "व्याख्यान- 92 || तंत्रिका नियंत्रण एवं समन्वय- 1",
          "published_date": "19 Mar 2025",
          "video_url": "https://www.youtube.com/embed/d_qwHS5hV04",
          "hd_video_url": "https://www.youtube.com/embed/d_qwHS5hV04",
          "thumbnail": "https://i.ytimg.com/vi/d_qwHS5hV04/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 92 || तंत्रिका नियंत्रण एवं समन्वय- 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/32c09449-db2b-4fbc-a38b-8f15702483b9.pdf"
            }
          ]
        },
        {
          "serial": 94,
          "title": "व्याख्यान- 93 || तंत्रिका नियंत्रण एवं समन्वय- 2",
          "published_date": "19 Mar 2025",
          "video_url": "https://www.youtube.com/embed/kxMkjnKB1-M",
          "hd_video_url": "https://www.youtube.com/embed/kxMkjnKB1-M",
          "thumbnail": "https://i.ytimg.com/vi/kxMkjnKB1-M/default.jpg",
          "notes": [
            {
              "title": "Class Notes  - व्याख्यान- 93 || तंत्रिका नियंत्रण एवं समन्वय- 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/9450b740-2d1b-4b1e-8295-62bd4a10c5ff.pdf"
            }
          ]
        },
        {
          "serial": 95,
          "title": "व्याख्यान- 94 || तंत्रिका नियंत्रण एवं समन्वय- 3",
          "published_date": "20 Mar 2025",
          "video_url": "https://www.youtube.com/embed/3pGHW3sBu_s",
          "hd_video_url": "https://www.youtube.com/embed/3pGHW3sBu_s",
          "thumbnail": "https://i.ytimg.com/vi/3pGHW3sBu_s/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 94 || तंत्रिका नियंत्रण एवं समन्वय- 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/cc8d6417-af2a-4fdf-867b-dd14e0bf1cd5.pdf"
            }
          ]
        },
        {
          "serial": 96,
          "title": "व्याख्यान - 95 || रासायनिक समन्वय एवं एकीकरण - 1",
          "published_date": "21 Mar 2025",
          "video_url": "https://www.youtube.com/embed/8brA9-B5_x4",
          "hd_video_url": "https://www.youtube.com/embed/8brA9-B5_x4",
          "thumbnail": "https://i.ytimg.com/vi/8brA9-B5_x4/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान - 95  रासायनिक समन्वय एवं एकीकरण - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/0e4e48df-84a8-48c3-99e8-aac31de1f1a2.pdf"
            }
          ]
        },
        {
          "serial": 97,
          "title": "व्याख्यान- 96 ||  रासायनिक समन्वय एवं एकीकरण - 2",
          "published_date": "21 Mar 2025",
          "video_url": "https://www.youtube.com/embed/MN9elk8nX7E",
          "hd_video_url": "https://www.youtube.com/embed/MN9elk8nX7E",
          "thumbnail": "https://i.ytimg.com/vi/MN9elk8nX7E/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 96   रासायनिक समन्वय एवं एकीकरण - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/6b9f0515-9d9a-4feb-b252-70d82f4c4ad9.pdf"
            }
          ]
        },
        {
          "serial": 98,
          "title": "व्याख्यान- 97 || रासायनिक समन्वय एवं एकीकरण - 3",
          "published_date": "22 Mar 2025",
          "video_url": "https://www.youtube.com/embed/ttf8NrjoUCs",
          "hd_video_url": "https://www.youtube.com/embed/ttf8NrjoUCs",
          "thumbnail": "https://i.ytimg.com/vi/ttf8NrjoUCs/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 97 || रासायनिक समन्वय एवं एकीकरण - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a7213a1f-36f7-44c8-b561-17a4c3211c02.pdf"
            }
          ]
        },
        {
          "serial": 99,
          "title": "व्याख्यान- 98 || जैव प्रौद्योगिकी: सिद्धांत और प्रक्रियाएं -1",
          "published_date": "22 Mar 2025",
          "video_url": "https://www.youtube.com/embed/of7ZfdIBsmM",
          "hd_video_url": "https://www.youtube.com/embed/of7ZfdIBsmM",
          "thumbnail": "https://i.ytimg.com/vi/of7ZfdIBsmM/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 98 || जैव प्रौद्योगिकी: सिद्धांत और प्रक्रियाएं -1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a359ca64-468b-4f9d-bf92-ca0e5527165c.pdf"
            }
          ]
        },
        {
          "serial": 100,
          "title": "व्याख्यान- 98 || जैव प्रौद्योगिकी: सिद्धांत और प्रक्रियाएं -2",
          "published_date": "23 Mar 2025",
          "video_url": "https://www.youtube.com/embed/QmGc_-wnvx8",
          "hd_video_url": "https://www.youtube.com/embed/QmGc_-wnvx8",
          "thumbnail": "https://i.ytimg.com/vi/QmGc_-wnvx8/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 98  जैव प्रौद्योगिकी: सिद्धांत और प्रक्रियाएं -2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/1a5f7346-dd8d-44cd-a1c6-c139e2fc2f4f.pdf"
            }
          ]
        },
        {
          "serial": 101,
          "title": "व्याख्यान- 100 || जैव प्रौद्योगिकी: सिद्धांत और प्रक्रियाएं - 3",
          "published_date": "24 Mar 2025",
          "video_url": "https://www.youtube.com/embed/839JYqx0q6M",
          "hd_video_url": "https://www.youtube.com/embed/839JYqx0q6M",
          "thumbnail": "https://i.ytimg.com/vi/839JYqx0q6M/default.jpg",
          "notes": [
            {
              "title": "Class Notes व्याख्यान- 100  जैव प्रौद्योगिकी: सिद्धांत और प्रक्रियाएं - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f392e72a-9efb-44ba-9d13-881460dbfe48.pdf"
            }
          ]
        },
        {
          "serial": 102,
          "title": "व्याख्यान- 99 || जैव प्रौद्योगिकी: सिद्धांत और प्रक्रियाएं - 4",
          "published_date": "24 Mar 2025",
          "video_url": "https://www.youtube.com/embed/5Ttehay_TZ8",
          "hd_video_url": "https://www.youtube.com/embed/5Ttehay_TZ8",
          "thumbnail": "https://i.ytimg.com/vi/5Ttehay_TZ8/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 99 || जैव प्रौद्योगिकी: सिद्धांत और प्रक्रियाएं - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/8e0e2396-f444-4bfc-a4df-03a5885f34a1.pdf"
            }
          ]
        },
        {
          "serial": 103,
          "title": "व्याख्यान- 100 || जैव प्रौद्योगिकी: सिद्धांत और प्रक्रियाएं - 5",
          "published_date": "25 Mar 2025",
          "video_url": "https://www.youtube.com/embed/nZdGwvprnB4",
          "hd_video_url": "https://www.youtube.com/embed/nZdGwvprnB4",
          "thumbnail": "https://i.ytimg.com/vi/nZdGwvprnB4/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 100 || जैव प्रौद्योगिकी: सिद्धांत और प्रक्रियाएं - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b371f65b-ca12-4d97-9008-2fe7714d48a9.pdf"
            }
          ]
        },
        {
          "serial": 104,
          "title": "व्याख्यान- 101 || जैव प्रौद्योगिकी और उसके अनुप्रयोग - 1",
          "published_date": "25 Mar 2025",
          "video_url": "https://www.youtube.com/embed/v-UU2yFplXE",
          "hd_video_url": "https://www.youtube.com/embed/v-UU2yFplXE",
          "thumbnail": "https://i.ytimg.com/vi/v-UU2yFplXE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 101 || जैव प्रौद्योगिकी और उसके अनुप्रयोग - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/08873965-da9a-4209-9d7f-c868cba96fc8.pdf"
            }
          ]
        },
        {
          "serial": 105,
          "title": "व्याख्यान- 102 || पारिस्थितिकी तंत्र (पारितंत्र)",
          "published_date": "25 Mar 2025",
          "video_url": "https://www.youtube.com/embed/Wbvo2I7E8z8",
          "hd_video_url": "https://www.youtube.com/embed/Wbvo2I7E8z8",
          "thumbnail": "https://i.ytimg.com/vi/Wbvo2I7E8z8/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 102 || पारिस्थितिकी तंत्र",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/b889ba96-b559-4f9e-ad49-bff6dbb8a25b.pdf"
            }
          ]
        },
        {
          "serial": 106,
          "title": "व्याख्यान- 102 || कोशिका: जीवन की इकाई - 1",
          "published_date": "26 Mar 2025",
          "video_url": "https://www.youtube.com/embed/sd8H6LIgCUo",
          "hd_video_url": "https://www.youtube.com/embed/sd8H6LIgCUo",
          "thumbnail": "https://i.ytimg.com/vi/sd8H6LIgCUo/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 102 || कोशिका: जीवन की इकाई - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/d0001b91-288f-43eb-9486-1e2608e1388c.pdf"
            }
          ]
        },
        {
          "serial": 107,
          "title": "व्याख्यान- 103 || कोशिका: जीवन की इकाई - 2",
          "published_date": "26 Mar 2025",
          "video_url": "https://www.youtube.com/embed/3ZW8ueKQ44k",
          "hd_video_url": "https://www.youtube.com/embed/3ZW8ueKQ44k",
          "thumbnail": "https://i.ytimg.com/vi/3ZW8ueKQ44k/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 103 || कोशिका: जीवन की इकाई - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/a1514d08-79b2-4218-8731-dccb68dd2fd6.pdf"
            }
          ]
        },
        {
          "serial": 108,
          "title": "व्याख्यान- 104 || जैव विविधता संरक्षण",
          "published_date": "26 Mar 2025",
          "video_url": "https://www.youtube.com/embed/05iMSpXhHmM",
          "hd_video_url": "https://www.youtube.com/embed/05iMSpXhHmM",
          "thumbnail": "https://i.ytimg.com/vi/05iMSpXhHmM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 104 || जैव विविधता संरक्षण",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/52b11538-2832-4e64-a67a-47fff47193a9.pdf"
            }
          ]
        },
        {
          "serial": 109,
          "title": "व्याख्यान- 104 || कोशिका: जीवन की इकाई - 3",
          "published_date": "27 Mar 2025",
          "video_url": "https://www.youtube.com/embed/cPYODRV1WiE",
          "hd_video_url": "https://www.youtube.com/embed/cPYODRV1WiE",
          "thumbnail": "https://i.ytimg.com/vi/cPYODRV1WiE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 104 || कोशिका: जीवन की इकाई - 3",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/4befd6c0-73a8-4d72-a466-240eb32097ec.pdf"
            }
          ]
        },
        {
          "serial": 110,
          "title": "व्याख्यान- 106 || कोशिका: जीवन की इकाई - 4",
          "published_date": "27 Mar 2025",
          "video_url": "https://www.youtube.com/embed/jQcDVpljZHM",
          "hd_video_url": "https://www.youtube.com/embed/jQcDVpljZHM",
          "thumbnail": "https://i.ytimg.com/vi/jQcDVpljZHM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 106 || कोशिका: जीवन की इकाई - 4",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/ea03d3da-43fd-412e-ab20-aea5a0ff62a9.pdf"
            }
          ]
        },
        {
          "serial": 111,
          "title": "व्याख्यान- 107 || जीव और समष्टियाँ",
          "published_date": "27 Mar 2025",
          "video_url": "https://www.youtube.com/embed/qDQQpcJJuI4",
          "hd_video_url": "https://www.youtube.com/embed/qDQQpcJJuI4",
          "thumbnail": "https://i.ytimg.com/vi/qDQQpcJJuI4/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 107 || जीव और समष्टियाँ",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c0b3c086-ac8e-4d79-838e-fd135fe381f2.pdf"
            }
          ]
        },
        {
          "serial": 112,
          "title": "व्याख्यान- 108 || कोशिका: जीवन की इकाई - 5",
          "published_date": "28 Mar 2025",
          "video_url": "https://www.youtube.com/embed/_GJbApdBxfU",
          "hd_video_url": "https://www.youtube.com/embed/_GJbApdBxfU",
          "thumbnail": "https://i.ytimg.com/vi/_GJbApdBxfU/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 108 || कोशिका: जीवन की इकाई - 5",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/766fc8c7-9584-4d45-89b1-50cf4bd5f4ab.pdf"
            }
          ]
        },
        {
          "serial": 113,
          "title": "व्याख्यान- 109 || कोशिका चक्र और कोशिका विभाजन - 1",
          "published_date": "28 Mar 2025",
          "video_url": "https://www.youtube.com/embed/LBEA9VMSLxE",
          "hd_video_url": "https://www.youtube.com/embed/LBEA9VMSLxE",
          "thumbnail": "https://i.ytimg.com/vi/LBEA9VMSLxE/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 109 || कोशिका चक्र और कोशिका विभाजन - 1",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/206703d3-dd17-4e4c-8d10-01e68a2d281c.pdf"
            }
          ]
        },
        {
          "serial": 114,
          "title": "व्याख्यान- 110 || कोशिका चक्र और कोशिका विभाजन - 2",
          "published_date": "30 Mar 2025",
          "video_url": "https://www.youtube.com/embed/EwzXuudyi3Y",
          "hd_video_url": "https://www.youtube.com/embed/EwzXuudyi3Y",
          "thumbnail": "https://i.ytimg.com/vi/EwzXuudyi3Y/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 110 || कोशिका चक्र और कोशिका विभाजन - 2",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/f6ea943e-1e64-4fc7-9220-ff55b3534957.pdf"
            }
          ]
        },
        {
          "serial": 115,
          "title": "व्याख्यान- 109 || कोशिका - जीवन की इकाई PYQs Solution",
          "published_date": "02 Apr 2025",
          "video_url": "https://www.youtube.com/embed/QF5TUnMm_qM",
          "hd_video_url": "https://www.youtube.com/embed/QF5TUnMm_qM",
          "thumbnail": "https://i.ytimg.com/vi/QF5TUnMm_qM/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 109 || कोशिका - जीवन की इकाई PYQs Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/852a5fa8-625d-4b01-9776-71be67c74e15.pdf"
            }
          ]
        },
        {
          "serial": 116,
          "title": "व्याख्यान- 110 || कोशिका चक्र एवं कोशिका विभाजन_PYQs Solution",
          "published_date": "03 Apr 2025",
          "video_url": "https://www.youtube.com/embed/7dl5M2HX1aI",
          "hd_video_url": "https://www.youtube.com/embed/7dl5M2HX1aI",
          "thumbnail": "https://i.ytimg.com/vi/7dl5M2HX1aI/default.jpg",
          "notes": [
            {
              "title": "Class Notes - व्याख्यान- 110 || कोशिका चक्र एवं कोशिका विभाजन_PYQs Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/68f39ec5-9804-45bb-aa9c-336ba5683165.pdf"
            }
          ]
        },
        {
          "serial": 117,
          "title": "व्याख्यान- 109 || जैव प्रौद्योगिकी: सिद्धांत और प्रक्रियाएं  PYQs Solution",
          "published_date": "04 Apr 2025",
          "video_url": "https://www.youtube.com/embed/vzOcBpjn73k",
          "hd_video_url": "https://www.youtube.com/embed/vzOcBpjn73k",
          "thumbnail": "https://i.ytimg.com/vi/vzOcBpjn73k/default.jpg",
          "notes": [
            {
              "title": "व्याख्यान- 109 || जैव प्रौद्योगिकी: सिद्धांत और प्रक्रियाएं  PYQs Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/69e5be12-98bc-48ea-af80-47bd7140aa25.pdf"
            }
          ]
        }
      ],
      "notes": []
    },
    {
      "subject_name": "Zoology Supporting Material",
      "subject_id": 3429,
      "video_count": 2,
      "note_count": 2,
      "videos": [
        {
          "serial": 1,
          "title": "मानव जनन || Flashback : Video Solution",
          "published_date": "07 Oct 2024",
          "video_url": "https://www.youtube.com/embed/pFGYVN-jDcE",
          "hd_video_url": "https://www.youtube.com/embed/pFGYVN-jDcE",
          "thumbnail": "",
          "notes": [
            {
              "title": "Class Notes - मानव जनन || Flashback : Video Solution",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/c25dd87e-fbb6-4584-a8b5-5616772af593.pdf"
            }
          ]
        },
        {
          "serial": 2,
          "title": "जनन स्वास्थ्य (Flashback)",
          "published_date": "28 Nov 2024",
          "video_url": "https://www.youtube.com/embed/7Z2HFJdtFnE",
          "hd_video_url": "https://www.youtube.com/embed/7Z2HFJdtFnE",
          "thumbnail": "https://i.ytimg.com/vi/7Z2HFJdtFnE/default.jpg",
          "notes": [
            {
              "title": "Class Notes -जनन स्वास्थ्य (Flashback)",
              "url": "https://kgs.nyc3.digitaloceanspaces.com/pdfs/3a9c5651-e61a-4d93-968b-6ca686e70a14.pdf"
            }
          ]
        }
      ],
      "notes": []
    }
  ]
};